# Carrom Ultra Pro Max — APK Build Steps

1. Install Android Studio (latest stable).
2. Open **android/** (not the outer ZIP folder) in Android Studio.
3. Let Gradle sync/download the Android Gradle Plugin and Gradle 8.10.2.
4. Set **Gradle JDK = 17** in Android Studio settings.
5. Wait until Gradle Sync reports success.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a debug APK.
7. For a release APK: **Build > Generate Signed App Bundle / APK > APK**, create/select a keystore, then build `release`.
8. The unsigned/debug output is normally under `android/app/build/outputs/apk/debug/`.
9. The signed release APK is normally under `android/app/build/outputs/apk/release/`.

## Important
- This ZIP contains the Android wrapper and the web game assets.
- This environment cannot run the Android SDK/Gradle toolchain, so an APK is **not** claimed as built or device-tested here.
- Before publishing, test every Play ground, navigation screen, back button, touch/aim/power input, orientation, audio, and network-dependent feature on a real Android device.
- Production authentication, payments, authoritative multiplayer settlement, and server-side anti-cheat still require their real backend services; the local UI cannot make those systems authoritative by itself.
