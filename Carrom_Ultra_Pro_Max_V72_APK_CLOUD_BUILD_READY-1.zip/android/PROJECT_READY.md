# Android Studio Conversion — V72.20

Converted from the latest Carrom Ultra Pro Max project into a standard Android Studio Gradle structure.

- `settings.gradle`
- root `build.gradle`
- `gradle.properties`
- `gradle/wrapper/gradle-wrapper.properties`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/carrom/ultrapro/max/MainActivity.java`
- `app/src/main/assets/public/` — full web game payload
- release ProGuard file

No gameplay files were intentionally removed from the bundled web payload.
