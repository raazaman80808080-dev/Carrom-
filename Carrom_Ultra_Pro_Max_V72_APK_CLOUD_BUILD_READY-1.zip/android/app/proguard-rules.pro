# Carrom Ultra Pro Max - release rules.
# WebView JavaScript/HTML assets are packaged as Android assets and do not need
# Java/Kotlin keep rules. Add rules here if native libraries are introduced.
