/* V72 Part 20 — Every Play button gets one reliable match-start path. */
(()=>{
 'use strict';
 const modes=new Set(['classic','black','free','pool','practice','time','challenge']);
 const qsa=s=>Array.from(document.querySelectorAll(s));
 function normalize(el){
   if(!el)return;
   if(el.tagName==='BUTTON'&&!el.getAttribute('type'))el.type='button';
   const mode=modes.has(el.dataset.game)?el.dataset.game:'classic';
   el.dataset.game=mode;
   if(!el.dataset.players)el.dataset.players='2';
   el.setAttribute('aria-label',el.getAttribute('aria-label')||('Start '+(mode==='black'?'Black & White':mode==='free'?'Freestyle':mode==='pool'?'Disc Pool':mode==='practice'?'Solo Practice':mode==='time'?'Time Attack':mode==='challenge'?'Challenge':'Classic Carrom')+' match'));
 }
 function health(){
   if(typeof state==='undefined'||state.screen!=='game')return;
   const valid=state.mode&&modes.has(state.mode);
   const board=document.getElementById('board');
   if(!valid||!board)return;
   if(!Array.isArray(window.pieces)||!window.striker)return;
   if(!state.gameOver&&!state.running)state.running=true;
   if(typeof updateHUD==='function')updateHUD();
   if(typeof draw==='function')draw();
 }
 function boot(){
   qsa('[data-game]').forEach(normalize);
   document.addEventListener('click',e=>{
     const b=e.target.closest?.('[data-game]'); if(!b)return;
     normalize(b);
     // game.js owns the authoritative start call. This layer only verifies the match shortly after.
     setTimeout(health,0);setTimeout(health,80);setTimeout(health,350);
   },true);
   const mo=new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes||[]){if(n.nodeType!==1)continue;if(n.matches?.('[data-game]'))normalize(n);n.querySelectorAll?.('[data-game]').forEach(normalize)}});
   mo.observe(document.body,{childList:true,subtree:true});
   document.addEventListener('visibilitychange',()=>{if(!document.hidden)setTimeout(health,60)});
   window.addEventListener('pageshow',()=>setTimeout(health,60));
   setInterval(health,1200);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromPlaygroundQA={version:'72.20',modes:[...modes],check:()=>({screen:state?.screen,mode:state?.mode,players:state?.players,running:!!state?.running,gameOver:!!state?.gameOver,pieces:Array.isArray(window.pieces)?window.pieces.length:0,striker:!!window.striker})};
})();
