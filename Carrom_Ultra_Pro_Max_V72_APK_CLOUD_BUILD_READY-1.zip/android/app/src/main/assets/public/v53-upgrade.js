/* Carrom Ultra Pro Max V53.0 — Reliability + UX polish layer. */
(()=>{
'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function mount(){
 if(document.getElementById('v53Polish')) return;
 const root=document.createElement('aside'); root.id='v53Polish'; root.className='v53-polish'; root.setAttribute('aria-label','V53 reliability status');
 root.innerHTML='<div class="v53-orb" aria-hidden="true"></div><div class="v53-copy"><b>V53 ULTRA CORE</b><span id="v53NetText">LOCAL-FIRST · READY</span></div><button id="v53Net" aria-label="Check server status">CHECK</button>';
 document.body.appendChild(root);
 const check=async()=>{
  const btn=document.getElementById('v53Net'),txt=document.getElementById('v53NetText'); if(!btn||!txt)return;
  btn.disabled=true; txt.textContent='CHECKING AUTHORITY…';
  try{const base=(window.CarromBackend&&window.CarromBackend.baseUrl)||''; const r=await fetch((base||'')+'/health',{cache:'no-store'}); if(!r.ok)throw 0; const d=await r.json(); txt.textContent='SERVER ONLINE · V'+esc(d.version||'53'); root.dataset.online='1';}
  catch(_){txt.textContent='LOCAL-FIRST · OFFLINE SAFE'; root.dataset.online='0';}
  finally{btn.disabled=false;}
 };
 document.getElementById('v53Net').onclick=check;
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
