/* Carrom Ultra Pro Max V59.0 — Ultra Game Feel 3.0 / Sharpness / Result Presentation. */
(()=>{
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const root=document.body;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const haptic=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(_) {}};
let prev={score:'',shot:'',power:'',spin:'',pocket:'',foul:'',status:''};
let resultTimer=0;
function pulse(kind,d=620){if(reduced())return;root.classList.remove('v59-'+kind);void root.offsetWidth;root.classList.add('v59-'+kind);clearTimeout(root.__v59p);root.__v59p=setTimeout(()=>root.classList.remove('v59-'+kind),d)}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show','v59-toast');clearTimeout(window.__v59toast);window.__v59toast=setTimeout(()=>t.classList.remove('show','v59-toast'),1900)}
function setText(id,v){const e=$('#'+id);if(e)e.textContent=v}
function mount(){
 if($('#v59Engine'))return;
 root.classList.add('v59-engine');
 const top=$('.top');if(top){const rail=document.createElement('div');rail.id='v59Engine';rail.className='v59-rail';rail.innerHTML='<i></i><b>ULTRA GAME FEEL 3.0</b><span>PRECISION READY</span>';top.appendChild(rail)}
 const wrap=$('.board-wrap');
 if(wrap){
  wrap.classList.add('v59-board-stage');
  const reticle=document.createElement('div');reticle.className='v59-reticle';reticle.setAttribute('aria-hidden','true');wrap.appendChild(reticle);
  const shot=document.createElement('div');shot.id='v59ShotFX';shot.className='v59-shot-fx';shot.setAttribute('aria-hidden','true');wrap.appendChild(shot);
 }
 const hud=$('.pro-hud');
 if(hud){const meter=document.createElement('div');meter.className='v59-readout';meter.innerHTML='<span>FEEL</span><b id="v59Feel">READY</b>';hud.appendChild(meter)}
 const sync=()=>{
  const score=($('#gameScore')?.textContent||'').trim(),shot=($('#shotCountHUD')?.textContent||'').trim(),power=($('#powerHUD')?.textContent||'').trim(),spin=($('#spinHUD')?.textContent||'').trim(),pocket=($('#pocketHUD')?.textContent||'').trim(),foul=($('#foulHUD')?.textContent||'').trim(),status=($('#hudStatus')?.textContent||'').trim();
  const feel=$('#v59Feel'); if(feel) feel.textContent=status||'READY';
  if(score&&prev.score&&score!==prev.score){pulse('score',500);haptic(6);animateNumber('#gameScore')}
  if(shot&&prev.shot&&shot!==prev.shot){pulse('shot',430);setShotFX('SHOT '+shot);haptic(5)}
  if(power&&prev.power&&power!==prev.power)pulse('power',280);
  if(spin&&prev.spin&&spin!==prev.spin)pulse('spin',280);
  if(pocket!==prev.pocket&&prev.pocket!==''&&pocket!=='0'){pulse('pocket',650);setShotFX('POCKET +1');haptic(14)}
  if(foul!==prev.foul&&prev.foul!==''&&foul!=='0'){pulse('foul',650);setShotFX('FOUL');haptic([12,35,12])}
  if(status&&prev.status&&status!==prev.status&&/ready|turn|play/i.test(status))pulse('status',400);
  prev={score,shot,power,spin,pocket,foul,status};
 };
 ['#gameScore','#shotCountHUD','#powerHUD','#spinHUD','#pocketHUD','#foulHUD','#hudStatus','#turnName','#turnTimer','#queenStatus'].forEach(sel=>{const e=$(sel);if(e)new MutationObserver(sync).observe(e,{subtree:true,childList:true,characterData:true,attributes:true})});sync();
 function setShotFX(text){const e=$('#v59ShotFX');if(!e)return;e.textContent=text;e.classList.remove('show');void e.offsetWidth;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),720)}
 function animateNumber(sel){const e=$(sel);if(!e||reduced())return;e.classList.remove('v59-number');void e.offsetWidth;e.classList.add('v59-number');setTimeout(()=>e.classList.remove('v59-number'),520)}
 const board=$('#board');
 if(board){
  board.addEventListener('pointerdown',()=>{pulse('aim',260);haptic(3)},{passive:true});
  board.addEventListener('pointerup',()=>{pulse('release',430);haptic(7)},{passive:true});
 }
 // Result modal enhancement: only decorates the existing game result, never changes outcome or rewards.
 const modal=$('#modal');
 if(modal){new MutationObserver(()=>{if(!modal.classList.contains('show'))return;const content=$('#modalContent');if(!content||content.dataset.v59==='1')return;const title=content.querySelector('h2')?.textContent||'';if(!/YOU WIN|MATCH DRAW|MATCH COMPLETE/i.test(title))return;content.dataset.v59='1';modal.classList.add(/YOU WIN/i.test(title)?'v59-win':/DRAW/i.test(title)?'v59-draw':'v59-complete');clearTimeout(resultTimer);resultTimer=setTimeout(()=>modal.classList.add('v59-result-settle'),40);setTimeout(()=>modal.classList.remove('v59-win','v59-draw','v59-complete','v59-result-settle'),3600);haptic(/YOU WIN/i.test(title)?[18,45,18]:12);}).observe(modal,{subtree:true,childList:true,attributes:true});}
 // Premium press feedback, keyboard focus and safe mobile interaction.
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip');if(!b)return;b.classList.add('v59-press')},{passive:true});
 root.addEventListener('pointerup',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip');if(b)b.classList.remove('v59-press')},{passive:true});
 root.addEventListener('pointercancel',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip');if(b)b.classList.remove('v59-press')},{passive:true});
 document.addEventListener('keydown',e=>{if(e.key==='Enter'&&document.activeElement?.matches('button,.nav'))pulse('key',260)},{passive:true});
 document.addEventListener('visibilitychange',()=>root.classList.toggle('v59-hidden',document.hidden));
 root.classList.add('v59-boot');requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.remove('v59-boot')));
 try{if(localStorage.getItem('carrom_v59_intro')!=='1'){localStorage.setItem('carrom_v59_intro','1');setTimeout(()=>toast('✦ V59 Ultra Game Feel ready'),900)}}catch(_){}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
window.CarromV59={version:'59.0.0',feel:'ultra-game-feel-3'};
})();
