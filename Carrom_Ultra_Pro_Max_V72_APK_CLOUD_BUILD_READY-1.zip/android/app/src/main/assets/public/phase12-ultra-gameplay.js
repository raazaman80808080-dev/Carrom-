/* V72 Phase 12 — Ultra Gameplay Control + Resilience Layer (additive) */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 let installed=false, lastInput=0, aiTimer=null;
 const now=()=>performance.now();
 const canPlay=()=>typeof state!=='undefined' && state.screen==='game' && state.running && !state.gameOver && !(typeof moving==='function'&&moving());
 function set(id,v){const e=$('#'+id);if(e)e.textContent=v}
 function sync(){
   if(typeof state==='undefined'||state.screen!=='game')return;
   const cpu=state.players===2&&state.turn===1&&!state.practice;
   set('u12Turn',state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED':cpu?'CPU TURN':state.players>2?'PLAYER '+(state.turn+1):'YOUR TURN');
   set('u12Power',Math.round(state.power||0)+'%');
   set('u12Coins',String(state.turnCoins||0));
   set('u12Pieces',String(pieces?.filter(p=>p.type==='coin').length??0));
   const meter=$('#u12Meter'); if(meter)meter.style.setProperty('--u12-p',Math.max(0,Math.min(100,state.power||0))+'%');
   const hint=$('#u12Hint'); if(hint){
     hint.textContent=state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED — press P to resume':cpu?'CPU IS CALCULATING…':moving()?'SHOT IN PLAY…':state.turnPocket?'NICE! YOU MAY SHOOT AGAIN':'DRAG FROM STRIKER TO AIM';
   }
 }
 function center(){if(!canPlay()||state.turn!==0&&state.players===2)return;striker.x=350;striker.y=590;striker.vx=striker.vy=0;state.drag=null;if(typeof draw==='function')draw();if(typeof toast==='function')toast('◎ Striker centered')}
 function nudgeSafe(d){if(!canPlay())return;if(state.players===2&&state.turn!==0)return;if(typeof nudge==='function')nudge(d)}
 function setPower(v){if(!canPlay()||state.players===2&&state.turn!==0)return;state.power=Math.max(10,Math.min(100,+v||55));const r=$('#powerRange');if(r)r.value=state.power;sync();if(typeof draw==='function')draw()}
 function pause(){if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return;if(typeof tool==='function')tool('pause');sync()}
 function install(){
   if(installed||!$('#game'))return; installed=true;
   const game=$('#game');
   const hud=document.createElement('section');hud.id='u12Hud';hud.className='u12-hud';hud.setAttribute('aria-label','Live match controls');
   hud.innerHTML='<div class="u12-top"><div class="u12-turn"><i></i><b id="u12Turn">YOUR TURN</b></div><span id="u12Hint">DRAG FROM STRIKER TO AIM</span><button type="button" data-u12="pause" aria-label="Pause or resume match">Ⅱ</button></div><div class="u12-grid"><div><small>POWER</small><strong id="u12Power">55%</strong><i id="u12Meter"><em></em></i></div><div><small>TURN POCKETS</small><strong id="u12Coins">0</strong></div><div><small>BOARD LEFT</small><strong id="u12Pieces">0</strong></div></div><div class="u12-actions"><button type="button" data-u12="25">25</button><button type="button" data-u12="50">50</button><button type="button" data-u12="75">75</button><button type="button" data-u12="100">MAX</button><button type="button" data-u12="left">◀</button><button type="button" data-u12="center">CENTER</button><button type="button" data-u12="right">▶</button></div>';
   const bar=game.querySelector('.gamebar'); if(bar)bar.parentNode.insertBefore(hud,bar); else game.prepend(hud);
   hud.addEventListener('click',e=>{const b=e.target.closest('[data-u12]');if(!b)return;const a=b.dataset.u12;if(a==='pause')pause();else if(a==='center')center();else if(a==='left')nudgeSafe(-1);else if(a==='right')nudgeSafe(1);else setPower(a)});
   document.addEventListener('keydown',e=>{
     if(e.target.matches('input,textarea,select'))return;
     if(typeof state==='undefined'||state.screen!=='game')return;
     if(e.key===' '||e.key.toLowerCase()==='p'){e.preventDefault();pause();return}
     if(e.key==='Home'){e.preventDefault();center();return}
     if(e.key==='ArrowLeft'){e.preventDefault();nudgeSafe(-1);return}
     if(e.key==='ArrowRight'){e.preventDefault();nudgeSafe(1);return}
     if(e.key==='1')setPower(25); else if(e.key==='2')setPower(50); else if(e.key==='3')setPower(75); else if(e.key==='4')setPower(100);
   },{passive:false});
   // Prevent a second pointer release from firing two shots on slow mobile browsers.
   const board=$('#board'); if(board)board.addEventListener('pointerdown',()=>{lastInput=now()},{passive:true});
   sync();
 }
 function guard(){
   if(typeof state!=='undefined'&&state.screen==='game'){
     // Never allow an AI shot timer to survive a pause, mode switch or match completion.
     if((!state.running||state.gameOver||state.turn!==1)&&aiTimer){clearTimeout(aiTimer);aiTimer=null;state.aiBusy=false}
     // Recover a striker that somehow leaves the playable lane after a collision/pocket.
     if(typeof striker!=='undefined' && Number.isFinite(striker.x)&&Number.isFinite(striker.y) && (striker.x<80||striker.x>620||striker.y<80||striker.y>620) && !moving()){
       striker.x=350;striker.y=590;striker.vx=striker.vy=0;
     }
     sync();
   }
   requestAnimationFrame(guard);
 }
 // Add a final validation wrapper around shots without changing the existing physics contract.
 if(typeof window.shoot==='function'&&!window.__u12ShootGuard){
   const original=window.shoot;
   window.shoot=function(a,p,s){
     if(typeof state==='undefined'||state.gameOver||!state.running||state.aiBusy||moving())return;
     if(state.players===2&&state.turn!==0)return;
     if(!Number.isFinite(a)||!Number.isFinite(p))return;
     p=Math.max(10,Math.min(100,p)); s=Number.isFinite(s)?Math.max(-100,Math.min(100,s)):0;
     return original.call(this,a,p,s);
   };
   window.__u12ShootGuard=true;
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 requestAnimationFrame(guard);
 window.CarromPhase12={version:'12.0',center,nudge:nudgeSafe,setPower,pause};
})();
