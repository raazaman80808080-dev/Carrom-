/* Carrom Ultra Pro Max V58.0 — Ultra Presentation / Sharpness / Match Feedback polish. */
(()=>{
'use strict';
const q=s=>document.querySelector(s), qa=s=>[...document.querySelectorAll(s)];
const root=document.body;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const vibrate=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(e){}};
let lastScore='',lastTurn='',lastMsg='',lastPocket='';
function flash(kind){if(reduced())return;root.classList.remove('v58-'+kind);void root.offsetWidth;root.classList.add('v58-'+kind);setTimeout(()=>root.classList.remove('v58-'+kind),700)}
function toast(msg){const t=q('#toast');if(!t)return;t.textContent=msg;t.classList.add('show','v58-toast');clearTimeout(window.__v58toast);window.__v58toast=setTimeout(()=>t.classList.remove('show','v58-toast'),1900)}
function mount(){
 if(q('#v58Engine'))return;
 root.classList.add('v58-engine');
 const top=q('.top');if(top){const rail=document.createElement('div');rail.id='v58Engine';rail.className='v58-rail';rail.innerHTML='<i></i><b>ULTRA PRESENTATION 2.0</b><span id="v58RailState">READY</span>';top.appendChild(rail)}
 const wrap=q('.board-wrap');if(wrap){wrap.classList.add('v58-board-stage');const glass=document.createElement('div');glass.className='v58-board-glass';glass.setAttribute('aria-hidden','true');wrap.appendChild(glass);const label=document.createElement('div');label.className='v58-shot-label';label.id='v58ShotLabel';label.textContent='READY';wrap.appendChild(label)}
 const syncOnline=()=>{const online=navigator.onLine!==false,s=q('#v58RailState');if(s)s.textContent=online?'ONLINE READY':'LOCAL CORE';const l=q('#liveNet');if(l)l.textContent=online?'ONLINE READY':'LOCAL CORE';};addEventListener('online',syncOnline);addEventListener('offline',syncOnline);syncOnline();
 const sync=()=>{
  const score=(q('#gameScore')?.textContent||'').trim();const turn=(q('#turnName')?.textContent||'').trim();const msg=(q('#gameMessage')?.textContent||'').trim();const pockets=(q('#pocketHUD')?.textContent||'').trim();
  const title=(q('#gameTitle')?.textContent||'CLASSIC CARROM').trim();const lab=q('#v58ShotLabel');if(lab)lab.textContent=turn||title;
  if(score&&lastScore&&score!==lastScore)flash('score');
  if(turn&&lastTurn&&turn!==lastTurn){flash(/your turn/i.test(turn)?'yourturn':'turn');vibrate(7)}
  if(pockets!==lastPocket&&lastPocket!==''&&pockets!=='0'){flash('pocket');vibrate(10);if(lab){lab.textContent='POCKET +1';setTimeout(()=>{if(q('#v58ShotLabel'))q('#v58ShotLabel').textContent=q('#turnName')?.textContent||title},650)}}
  if(msg&&lastMsg&&msg!==lastMsg){flash('impact')}
  lastScore=score;lastTurn=turn;lastMsg=msg;lastPocket=pockets;
 };
 const mo=new MutationObserver(sync);['#gameScore','#turnName','#gameMessage','#pocketHUD','#hudStatus','#turnTimer','#queenStatus'].forEach(s=>{const e=q(s);if(e)mo.observe(e,{subtree:true,childList:true,characterData:true,attributes:true})});sync();
 // Game screen choreography: preserve game logic, enhance only presentation classes.
 qa('.screen').forEach(s=>new MutationObserver(()=>{if(s.classList.contains('active')&&s.id==='game'){root.classList.remove('v58-match-in');void root.offsetWidth;root.classList.add('v58-match-in')}}).observe(s,{attributes:true,attributeFilter:['class']}));
 // Premium focus/press feedback, scoped to actionable UI.
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip');if(!b)return;b.classList.add('v58-press');vibrate(3)},{passive:true});
 ['pointerup','pointercancel','pointerleave'].forEach(ev=>root.addEventListener(ev,e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip');if(b)b.classList.remove('v58-press')},{passive:true}));
 // Keep long-press / double-tap from zooming the game board on mobile without disabling normal page zoom.
 const board=q('#board');if(board){board.style.touchAction='none';board.addEventListener('contextmenu',e=>e.preventDefault())}
 // Sharp rendering hint for canvas without touching the game's drawing implementation.
 if(board){const sharpen=()=>{board.style.imageRendering='auto';board.setAttribute('data-v58-sharp','true')};sharpen();addEventListener('resize',sharpen)}
 root.classList.add('v58-boot');requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.remove('v58-boot')));
 // Visibility-aware animation budget.
 document.addEventListener('visibilitychange',()=>root.classList.toggle('v58-hidden',document.hidden));
 // Initial product toast only once per install/version.
 try{if(localStorage.getItem('carrom_v58_intro')!=='1'){localStorage.setItem('carrom_v58_intro','1');setTimeout(()=>toast('✦ V58 Ultra Presentation ready'),1050)}}catch(e){}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
window.CarromV58={version:'58.0.0',presentation:'ultra'};
})();
