/* PART 13 — Performance + PWA + Accessibility Ultra Pro Max. Additive only. */
(() => {
  'use strict';
  if (window.__CARROM_PART13__) return;
  const root = document.documentElement;
  const state = { reduced:false, saveData:false, online:navigator.onLine, fps:0, longTasks:0 };
  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  state.reduced = mq.matches;
  state.saveData = !!(conn && (conn.saveData || /^(slow-)?2g$/.test(conn.effectiveType || '')));
  const setMode = () => {
    root.dataset.p13Motion = mq.matches ? 'reduced' : 'full';
    root.dataset.p13Network = state.saveData ? 'conservative' : 'normal';
    root.dataset.p13Online = navigator.onLine ? 'online' : 'offline';
    state.reduced = mq.matches; state.online = navigator.onLine;
  };
  setMode();
  mq.addEventListener?.('change', setMode);
  window.addEventListener('online', setMode, {passive:true});
  window.addEventListener('offline', setMode, {passive:true});

  // One lightweight FPS sampler; it never drives gameplay and pauses when hidden.
  let frames=0, last=performance.now();
  const fpsTick = now => {
    if (!document.hidden) {
      frames++;
      if (now-last >= 1000) { state.fps=Math.round(frames*1000/(now-last)); frames=0; last=now; root.dataset.p13Fps=String(state.fps); }
    } else { frames=0; last=now; }
    requestAnimationFrame(fpsTick);
  };
  requestAnimationFrame(fpsTick);

  if ('PerformanceObserver' in window) {
    try {
      const po = new PerformanceObserver(list => { state.longTasks += list.getEntries().length; root.dataset.p13LongTasks=String(state.longTasks); });
      po.observe({type:'longtask', buffered:true});
    } catch (_) {}
  }

  // Accessibility: keyboard focus visibility, landmark helpers and live feedback without replacing existing UI.
  const bootA11y = () => {
    document.body.classList.add('p13-ready');
    const main = document.querySelector('main');
    if (main && !main.id) main.id='main-content';
    if (main && !document.querySelector('.p13-skip')) {
      const skip=document.createElement('a'); skip.className='p13-skip'; skip.href='#main-content'; skip.textContent='Skip to main content'; document.body.prepend(skip);
    }
    const toast=document.getElementById('toast');
    if (toast) { toast.setAttribute('role','status'); toast.setAttribute('aria-live','polite'); toast.setAttribute('aria-atomic','true'); }
    const modal=document.getElementById('modal');
    if (modal) modal.setAttribute('aria-label','Game dialog');
    const board=document.getElementById('board');
    if (board) { board.setAttribute('role','img'); board.setAttribute('aria-label','Carrom game board. Use touch, pointer, or keyboard controls to aim.'); }
    document.querySelectorAll('button:not([type])').forEach(b=>b.type='button');
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootA11y, {once:true}); else bootA11y();

  // PWA registration: reuse existing installPWA when available; otherwise register safely.
  const register = () => { if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{}); };
  if ('requestIdleCallback' in window) requestIdleCallback(register, {timeout:2500}); else setTimeout(register, 1200);

  window.CarromPart13 = Object.freeze({
    version:'13.0.0',
    getStatus:()=>({fps:state.fps, longTasks:state.longTasks, online:navigator.onLine, reducedMotion:mq.matches, saveData:state.saveData}),
    refresh:()=>{setMode(); bootA11y();}
  });
  window.__CARROM_PART13__ = true;
})();
