
/* V70.0 — Ultra Pro Max UI Signature Finish 14.0 */
(() => {
  "use strict";
  const VERSION = "70.0.0";
  const root = document.documentElement;
  root.classList.add("v70-signature");

  const add = (el, ...classes) => {
    if (!el) return;
    classes.forEach(c => el.classList.add(c));
  };

  // Preserve existing markup and layer interaction/focus polish onto actionable UI.
  document.querySelectorAll("button,a,[role='button'],input,select,textarea").forEach(el => {
    add(el, "v70-interactive", "v70-focus");
  });

  // Cards receive consistent depth without changing their content or click behavior.
  const cardSelectors = [
    ".card",".panel",".feature-card",".shop-card",".player-card",
    ".tournament-card",".stat-card",".quick-card",".match-card"
  ];
  document.querySelectorAll(cardSelectors.join(",")).forEach(el => add(el, "v70-surface"));

  // Add safe-area class to primary application shells.
  document.querySelectorAll("body,#app,.app,.main,.dashboard,.game-screen").forEach(el => add(el,"v70-safe"));

  // Keep long feature/shop/language/navigation strips usable on narrow Android screens.
  document.querySelectorAll(".fc-tabs,.fc-filters,.shop-menu,.language-grid,.feature-grid,.nav-list").forEach(el => {
    add(el,"v70-scroll-x");
  });

  // Small premium press/haptic feedback, guarded for mobile/browser support.
  let lastTap = 0;
  document.addEventListener("pointerup", e => {
    const el = e.target.closest("button,a,[role='button']");
    if (!el) return;
    const now = Date.now();
    if (now - lastTap < 45) return;
    lastTap = now;
    el.classList.add("v70-pressed");
    setTimeout(() => el.classList.remove("v70-pressed"), 110);
    if (navigator.vibrate && matchMedia("(pointer: coarse)").matches) {
      try { navigator.vibrate(7); } catch (_) {}
    }
  }, {passive:true});

  // Avoid expensive visual work while the page is hidden.
  document.addEventListener("visibilitychange", () => {
    root.classList.toggle("v70-hidden", document.hidden);
  });

  // Dynamic status metadata for diagnostics; does not claim backend connectivity.
  window.CarromV70 = {
    version: VERSION,
    presentation: "ui-signature-finish-14",
    mobile: "adaptive",
    preservesExistingSystems: true
  };
})();
