/* V72 Phase 7 — Ultra playable systems + premium game UX. Additive/defensive. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 let lastState='', lastShot=0;
 const cssEscape=s=>String(s).replace(/[^a-z0-9_-]/gi,'');
 function install(){
  const game=$('#game'); if(!game||$('#u7ControlDeck'))return;
  const deck=document.createElement('div'); deck.id='u7ControlDeck'; deck.className='u7-deck';
  deck.innerHTML='<div class="u7-head"><span><i></i> MATCH CONTROL</span><b id="u7State">READY</b></div><div class="u7-meter"><div><span>POWER</span><strong id="u7Power">55%</strong></div><div class="u7-track"><i id="u7Fill"></i></div><div><span>TURN</span><strong id="u7Turn">YOU</strong></div></div><div class="u7-actions"><button data-u7="center">CENTER</button><button data-u7="cancel">CANCEL AIM</button><button data-u7="pause">PAUSE</button></div>';
  game.appendChild(deck);
  deck.addEventListener('click',e=>{const b=e.target.closest('[data-u7]');if(!b)return;const a=b.dataset.u7;
   if(a==='center'&&typeof striker!=='undefined'&&!moving()){striker.x=350;striker.y=590; if(typeof draw==='function')draw();toastSafe('Striker centered')}
   if(a==='cancel'){if(typeof state!=='undefined'&&state.drag){state.drag=null;$('.board-wrap')?.classList.remove('focus');if(typeof draw==='function')draw();toastSafe('Aim cancelled')}}
   if(a==='pause'&&typeof tool==='function')tool('pause');
  });
 }
 function toastSafe(t){if(typeof toast==='function')toast(t)}
 function sync(){
  try{
   if(typeof state==='undefined'||state.screen!=='game')return;
   const playing=!!state.running&&!state.gameOver, cpu=state.players===2&&state.turn===1;
   const status=state.gameOver?'MATCH OVER':playing?(cpu?'CPU TURN':'YOUR TURN'):'PAUSED';
   const power=Math.round(state.power||0);
   const s=$('#u7State'),p=$('#u7Power'),f=$('#u7Fill'),t=$('#u7Turn');
   if(s)s.textContent=status;if(p)p.textContent=power+'%';if(f)f.style.width=Math.min(100,Math.max(0,power))+'%';if(t)t.textContent=cpu?'CPU':'YOU';
   const deck=$('#u7ControlDeck');if(deck)deck.classList.toggle('is-paused',!playing);
   const hint=$('#shotHint');if(hint&&playing&&!state.drag)hint.textContent=cpu?'CPU IS AIMING…':'DRAG BACK FROM STRIKER TO SHOOT';
   const range=$('#powerRange');if(range&&document.activeElement!==range)range.value=power;
   if(state.gameOver&&lastState!=='MATCH OVER')toastSafe('Match complete');
   if(status!==lastState){lastState=status; if(typeof draw==='function')draw()}
  }catch(_){ }
 }
 function bindRange(){const r=$('#powerRange');if(!r||r.__u7)return;r.__u7=true;r.addEventListener('input',()=>{if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return;state.power=+r.value;if(typeof draw==='function')draw()})}
 function boot(){install();bindRange();sync();setInterval(()=>{bindRange();sync()},250);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromUltraPlayable={version:'72.7',physics:'responsive-friction',controls:'deck+touch+keyboard'};
})();
