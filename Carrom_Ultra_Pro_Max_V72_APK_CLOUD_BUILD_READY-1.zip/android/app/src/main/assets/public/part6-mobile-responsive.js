/* PART 6 — Mobile & Responsive Ultra Pro Max. Additive only. */
(()=>{
 'use strict';
 const root=document.documentElement, game=()=>document.querySelector('#game'), board=()=>document.querySelector('#board'), wrap=()=>document.querySelector('.board-wrap');
 let raf=0;
 function metrics(){
   const g=game(), b=board(), w=wrap(); if(!g||!b||!w)return;
   const vv=window.visualViewport, vw=vv?.width||innerWidth, vh=vv?.height||innerHeight;
   const portrait=vw<=vh, coarse=matchMedia('(pointer:coarse)').matches;
   root.classList.toggle('p6-portrait',portrait); root.classList.toggle('p6-landscape',!portrait); root.classList.toggle('p6-coarse',coarse);
   const top=(document.querySelector('.top')?.getBoundingClientRect().height||0), bar=(g.querySelector('.screenbar')?.getBoundingClientRect().height||25);
   const info=(g.querySelector('.match-info')?.getBoundingClientRect().height||0), hud=(g.querySelector('.pro-hud')?.getBoundingClientRect().height||0), gamebar=(g.querySelector('.gamebar')?.getBoundingClientRect().height||0), controls=(g.querySelector('.mobile-controls')?.getBoundingClientRect().height||0);
   const side=document.querySelector('.side'); const sideW=side?.getBoundingClientRect().width||0;
   const availableW=Math.max(220,vw-sideW-16);
   const chrome=top+bar+info+hud+gamebar+controls+42;
   const availableH=Math.max(220,vh-chrome);
   const size=Math.max(220,Math.min(700,availableW,availableH));
   root.style.setProperty('--p6-board-size',Math.round(size)+'px');
   b.style.width=size+'px'; b.style.height=size+'px';
   w.style.width=size+'px'; w.style.maxWidth='100%';
   g.dataset.p6Viewport=(Math.round(vw)+'x'+Math.round(vh));
 }
 function schedule(){cancelAnimationFrame(raf);raf=requestAnimationFrame(metrics)}
 function init(){
   document.documentElement.classList.add('part6-responsive-ready');
   const b=board(); if(b){b.setAttribute('aria-label','Responsive carrom board');b.style.maxWidth='100%';}
   const range=document.querySelector('#powerRange'); if(range){range.setAttribute('aria-label','Shot power');}
   const controls=document.querySelector('.mobile-controls'); if(controls){controls.setAttribute('aria-label','Mobile shot controls');}
   schedule();
   addEventListener('resize',schedule,{passive:true}); addEventListener('orientationchange',()=>setTimeout(schedule,80),{passive:true});
   visualViewport?.addEventListener('resize',schedule,{passive:true}); visualViewport?.addEventListener('scroll',schedule,{passive:true});
   document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule()},{passive:true});
   new MutationObserver(schedule).observe(document.body,{subtree:true,childList:true});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
 window.CarromPart6Responsive={version:'6.0.0',refresh:schedule};
})();
