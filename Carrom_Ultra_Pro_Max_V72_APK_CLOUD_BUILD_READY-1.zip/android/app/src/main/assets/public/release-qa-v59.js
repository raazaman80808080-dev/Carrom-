const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname;
const js=fs.readdirSync(root).filter(f=>f.endsWith('.js'));
for(const f of js){try{cp.execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'ignore'})}catch(e){throw new Error('JS syntax failed: '+f)}}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
if(dup.length)throw new Error('Duplicate IDs: '+[...new Set(dup)].join(','));
for(const f of ['v55-upgrade.js','v56-upgrade.js','v57-upgrade.js','v58-upgrade.js','v59-upgrade.js'])if(!fs.existsSync(path.join(root,f)))throw new Error('Missing upgrade: '+f);
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));if(manifest.version!=='59.0.0')throw new Error('Manifest mismatch');
if(!html.includes('v57-upgrade.js')||!html.includes('v58-upgrade.js')||!html.includes('v59-upgrade.js'))throw new Error('Upgrade chain missing');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');for(const t of ['v59-engine','v59-board-stage','v59-shot-fx','v59-reticle','v59-win'])if(!css.includes(t))throw new Error('Missing CSS '+t);
const js59=fs.readFileSync(path.join(root,'v59-upgrade.js'),'utf8');for(const t of ['ULTRA GAME FEEL 3.0','v59-result-settle','visibilitychange','prefers-reduced-motion'])if(!js59.includes(t))throw new Error('Missing V59 feature '+t);
console.log('V59.0 QA PASS');console.log('source files:',js.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs:',dup.length?'FAIL':'NONE');console.log('manifest:',manifest.version);console.log('V55/V56/V57/V58/V59 upgrade chain: PASS');console.log('V59 feature tokens: PASS');
