/* V72 Phase 17 — Match Reliability + UI Systems. Additive only. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s), clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 let lastFrame=performance.now(), stableFrames=0;
 const isGame=()=>typeof state!=='undefined'&&state.screen==='game';
 const canHuman=()=>isGame()&&!state.gameOver&&state.running&&!state.aiBusy&&!(state.players===2&&state.turn===1)&&!(typeof moving==='function'&&moving());
 function syncControls(){
   if(!isGame())return;
   const power=clamp(Number(state.power)||55,10,100), range=$('#powerRange');
   if(range && document.activeElement!==range) range.value=power;
   const deck=$('#p17Deck'); if(deck){deck.classList.toggle('disabled',!canHuman()); deck.dataset.turn=String(state.turn);}
   const badge=$('#p17Readiness');
   if(badge) badge.textContent=state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED':state.aiBusy?'CPU THINKING':(state.players===2&&state.turn===1)?'CPU TURN':moving()?'SHOT IN PLAY':'READY TO AIM';
 }
 function install(){
   const g=$('#game'); if(!g||$('#p17Deck'))return;
   const d=document.createElement('section');d.id='p17Deck';d.className='p17-deck';d.setAttribute('aria-label','Precision match controls');
   d.innerHTML='<div class="p17-read"><i></i><b id="p17Readiness">READY TO AIM</b><small>Precision control</small></div><div class="p17-power"><span>POWER</span><strong id="p17Power">55%</strong><input id="p17Range" type="range" min="10" max="100" value="55" aria-label="Shot power"><div class="p17-presets"><button data-p17-power="25">25</button><button data-p17-power="50">50</button><button data-p17-power="75">75</button><button data-p17-power="100">MAX</button></div></div><div class="p17-actions"><button data-p17="center">CENTER</button><button data-p17="pause">PAUSE</button><button data-p17="new">NEW MATCH</button></div>';
   (g.querySelector('.gamebar')?.parentNode||g).insertBefore(d,g.querySelector('.gamebar')||g.firstChild);
   const range=$('#p17Range'); range.oninput=()=>{if(!canHuman())return;state.power=clamp(+range.value,10,100);const old=$('#powerRange');if(old)old.value=state.power;const h=$('#p17Power');if(h)h.textContent=Math.round(state.power)+'%';if(typeof draw==='function')draw()};
   d.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
     if(b.dataset.p17Power&&canHuman()){state.power=+b.dataset.p17Power;range.value=state.power;const old=$('#powerRange');if(old)old.value=state.power;const h=$('#p17Power');if(h)h.textContent=state.power+'%';if(typeof draw==='function')draw();return;}
     if(b.dataset.p17==='center'&&canHuman()&&typeof nudge==='function'){while(striker&&striker.x<350)nudge(1);while(striker&&striker.x>350)nudge(-1);return;}
     if(b.dataset.p17==='pause'&&isGame()&&!state.gameOver&&typeof tool==='function'){tool('pause');syncControls();return;}
     if(b.dataset.p17==='new'&&typeof startGame==='function'){startGame(state.mode||'classic',state.players||2);}
   });
 }
 // Prevent stale touch state after a canceled gesture or screen change.
 document.addEventListener('pointercancel',()=>{if(typeof state!=='undefined')state.drag=null},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&isGame()){lastFrame=performance.now();stableFrames=0;if(typeof draw==='function')draw();}});
 function tick(now){
   const gap=now-lastFrame;lastFrame=now;
   if(isGame()&&gap>500&&state.running&&!state.gameOver&&Number.isFinite(state.turnStart)) state.turnStart+=gap-100;
   if(isGame()){
     install();syncControls();
     if(state.running&&!state.gameOver)stableFrames++;
     if(stableFrames>8&&typeof striker!=='undefined'&&striker){striker.x=clamp(striker.x,INNER.min+striker.r,INNER.max-striker.r);striker.y=clamp(striker.y,INNER.min+striker.r,INNER.max-striker.r);}
   }else stableFrames=0;
   requestAnimationFrame(tick);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>requestAnimationFrame(tick),{once:true});else requestAnimationFrame(tick);
 window.CarromPhase17={version:'72.17',ready:canHuman};
})();
