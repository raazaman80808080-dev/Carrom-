/* Carrom Ultra Pro Max V62.0 — Ultra Board Physics Presentation / Precision 6.0 / Sharpness. */
(()=>{
'use strict';
const $=s=>document.querySelector(s), root=document.body;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const haptic=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(_) {}};
let mounted=false, last={score:'',turn:'',shot:'',pocket:'',queen:'',foul:'',power:'',spin:''}, combo=0;
function pulse(k,d=600){if(reduced())return;root.classList.remove('v62-'+k);void root.offsetWidth;root.classList.add('v62-'+k);clearTimeout(root['__v62_'+k]);root['__v62_'+k]=setTimeout(()=>root.classList.remove('v62-'+k),d)}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show','v62-toast');clearTimeout(window.__v62toast);window.__v62toast=setTimeout(()=>t.classList.remove('show','v62-toast'),1800)}
function impact(label,kind='hit'){const w=$('.board-wrap');if(!w||reduced())return;const e=document.createElement('div');e.className='v62-impact '+kind;e.textContent=label;e.setAttribute('aria-hidden','true');w.appendChild(e);requestAnimationFrame(()=>e.classList.add('show'));setTimeout(()=>e.remove(),1050)}
function mount(){
 if(mounted)return;mounted=true;root.classList.add('v62-engine');
 const top=$('.top');if(top&&!$('#v62Rail')){const r=document.createElement('div');r.id='v62Rail';r.className='v62-rail';r.innerHTML='<i></i><b>ULTRA PRECISION 6.0</b><span>BOARD PHYSICS</span>';top.appendChild(r)}
 const wrap=$('.board-wrap');
 if(wrap&&!$('#v62BoardBadge')){const b=document.createElement('div');b.id='v62BoardBadge';b.className='v62-board-badge';b.innerHTML='<span>●</span> PRECISION BOARD <b>LIVE</b>';wrap.appendChild(b);wrap.addEventListener('pointerdown',()=>{pulse('board',260);haptic(3)},{passive:true})}
 const hud=$('.pro-hud');if(hud&&!$('#v62Combo')){const c=document.createElement('div');c.id='v62Combo';c.className='v62-combo';c.innerHTML='<span>COMBO</span><b>0</b>';hud.appendChild(c)}
 const read=()=>({score:($('#gameScore')?.textContent||'').trim(),turn:($('#turnName')?.textContent||'').trim(),shot:($('#shotCountHUD')?.textContent||'').trim(),pocket:($('#pocketHUD')?.textContent||'').trim(),queen:($('#queenStatus')?.textContent||'').trim(),foul:($('#foulHUD')?.textContent||'').trim(),power:($('#powerHUD')?.textContent||'').trim(),spin:($('#spinHUD')?.textContent||'').trim()});
 const sync=()=>{const n=read();
  if(n.shot&&last.shot&&n.shot!==last.shot){pulse('shot',300);impact('SHOT','hit');haptic(4)}
  if(n.pocket&&last.pocket&&n.pocket!==last.pocket&&n.pocket!=='0'){combo++;if($('#v62Combo'))$('#v62Combo b').textContent=String(combo);pulse('pocket',500);impact(combo>1?'COMBO ×'+combo:'POCKET +1','pocket');haptic(combo>1?[8,24,8]:10)}
  if(n.foul&&last.foul&&n.foul!==last.foul&&n.foul!=='0'){combo=0;if($('#v62Combo'))$('#v62Combo b').textContent='0';pulse('foul',480);impact('FOUL','foul');haptic([10,30,10])}
  if(n.queen!==last.queen&&last.queen&&/queen/i.test(n.queen)){pulse('queen',760);impact('QUEEN','queen');haptic([8,24,8,24,12])}
  if(n.score&&last.score&&n.score!==last.score){pulse('score',380)}
  if(n.turn&&last.turn&&n.turn!==last.turn){pulse('turn',360);haptic(5)}
  if(n.power&&last.power&&n.power!==last.power){pulse('power',260)}
  if(n.spin&&last.spin&&n.spin!==last.spin){pulse('spin',260)}
  last=n;
 };
 ['#gameScore','#turnName','#shotCountHUD','#pocketHUD','#queenStatus','#foulHUD','#powerHUD','#spinHUD','#turnTimer'].forEach(sel=>{const e=$(sel);if(e)new MutationObserver(sync).observe(e,{subtree:true,childList:true,characterData:true,attributes:true})});sync();
 const modal=$('#modal');if(modal)new MutationObserver(()=>{if(!modal.classList.contains('show'))return;const c=$('#modalContent');const text=c?.textContent||'';if(!/YOU WIN|MATCH DRAW|MATCH COMPLETE|VICTORY|DEFEAT/i.test(text))return;pulse('finish',850);setTimeout(()=>{if(/YOU WIN|VICTORY/i.test(text))impact('VICTORY','win');else if(/DRAW/i.test(text))impact('DRAW','draw')},180);haptic(/YOU WIN|VICTORY/i.test(text)?[18,45,18]:12)}).observe(modal,{subtree:true,childList:true,attributes:true});
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.add('v62-press')},{passive:true});
 ['pointerup','pointercancel','pointerleave'].forEach(ev=>root.addEventListener(ev,e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.remove('v62-press')},{passive:true}));
 document.addEventListener('visibilitychange',()=>root.classList.toggle('v62-hidden',document.hidden));
 const board=$('#board');if(board){board.setAttribute('data-v62-sharp','true');board.style.transform='translateZ(0)';}
 root.classList.add('v62-boot');requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.remove('v62-boot')));
 try{if(localStorage.getItem('carrom_v62_intro')!=='1'){localStorage.setItem('carrom_v62_intro','1');setTimeout(()=>toast('✦ V62 Precision Board ready'),850)}}catch(_){ }
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
window.CarromV62={version:'62.0.0',presentation:'ultra-board-physics-presentation-6'};
})();
