/* PART 1 — Core Gameplay Polish / Publish Track
   Additive reliability layer. Preserves existing gameplay and systems.
*/
(()=>{
 'use strict';
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const finite=(v,f)=>Number.isFinite(Number(v))?Number(v):f;
 const gameActive=()=>typeof state!=='undefined'&&state.screen==='game';
 const canShoot=()=>gameActive()&&!state.gameOver&&state.running&&!state.aiBusy&&!(state.players===2&&state.turn===1)&&!(typeof moving==='function'&&moving());
 function normalizeCore(){
   if(typeof state==='undefined')return;
   state.power=clamp(finite(state.power,55),10,100);
   state.spin=clamp(finite(state.spin,0),-100,100);
   state.timer=state.practice?999:Math.max(0,finite(state.timer,30));
   state.shotCount=Math.max(0,Math.floor(finite(state.shotCount,0)));
   if(!Array.isArray(state.score)||state.score.length!==state.players) state.score=Array(Math.max(2,Math.min(4,state.players||2))).fill(0);
   if(typeof striker!=='undefined'&&striker){
     striker.x=clamp(finite(striker.x,350),INNER.min+striker.r,INNER.max-striker.r);
     striker.y=clamp(finite(striker.y,590),INNER.min+striker.r,INNER.max-striker.r);
     striker.vx=finite(striker.vx,0); striker.vy=finite(striker.vy,0); striker.spin=finite(striker.spin,0);
   }
 }
 function sync(){
   if(!gameActive())return;
   normalizeCore();
   const r=document.getElementById('powerRange'); if(r&&document.activeElement!==r)r.value=state.power;
   const s=document.getElementById('spinRange'); if(s&&document.activeElement!==s)s.value=state.spin;
   const core=document.getElementById('p1CoreStatus'); if(core)core.textContent=state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED':state.aiBusy?'CPU THINKING':(state.players===2&&state.turn===1)?'CPU TURN':(typeof moving==='function'&&moving())?'SHOT IN PLAY':'READY';
   const msg=document.getElementById('gameMessage');
   if(msg&&!state.drag){
     if(state.gameOver)msg.textContent='Match complete';
     else if(!state.running)msg.textContent='Match paused';
     else if(state.players===2&&state.turn===1)msg.textContent=state.aiBusy?'CPU is calculating…':'CPU turn…';
     else if(typeof moving==='function'&&moving())msg.textContent='Shot in play…';
     else msg.textContent=state.turn===0?'Your turn — drag from the striker':'Player '+(state.turn+1)+' turn — drag from the striker';
   }
 }
 // Wrap lifecycle methods after all existing game code has loaded.
 const originalStart=window.startGame;
 if(typeof originalStart==='function')window.startGame=function(mode,players){
   const result=originalStart.apply(this,arguments);
   try{state.running=true;state.gameOver=false;normalizeCore();if(typeof draw==='function')draw();}catch(_){ }
   return result;
 };
 const originalReset=window.resetGame;
 if(typeof originalReset==='function')window.resetGame=function(){
   const result=originalReset.apply(this,arguments);
   try{state.running=true;state.gameOver=false;state.aiBusy=false;state.drag=null;normalizeCore();if(typeof draw==='function')draw();}catch(_){ }
   return result;
 };
 // Guarantee that a direct Game-screen navigation has a real board state.
 const originalShow=window.show;
 if(typeof originalShow==='function')window.show=function(id){
   const result=originalShow.apply(this,arguments);
   if(id==='game'){
     try{
       if(typeof striker==='undefined'||!striker||!Array.isArray(pieces)||!pieces.length) originalReset&&originalReset();
       state.running=!state.gameOver; state.drag=null; normalizeCore(); if(typeof draw==='function')draw();
     }catch(_){ }
   }
   return result;
 };
 // Input hardening: one pointer gesture = one shot, with safe cancellation.
 const board=document.getElementById('board');
 if(board){
   board.addEventListener('pointerdown',e=>{if(e.button!==undefined&&e.button!==0)return;if(!canShoot())return;if(state.drag)return;try{if(typeof pos!=='function')return;const p=pos(e);if(Math.hypot(p.x-striker.x,p.y-striker.y)<38){state.drag=p;state.aimAngle=Math.atan2(striker.y-p.y,striker.x-p.x);if(board.setPointerCapture)board.setPointerCapture(e.pointerId);e.preventDefault();}}catch(_){state.drag=null;}},{passive:false});
   board.addEventListener('pointerup',e=>{if(!state.drag)return;try{const p=typeof pos==='function'?pos(e):state.drag;const dx=striker.x-p.x,dy=striker.y-p.y,len=Math.hypot(dx,dy);state.drag=null;const power=clamp(len/2,10,100);if(len>=5&&canShoot())shoot(Math.atan2(dy,dx),power,state.spin);else if(typeof draw==='function')draw();}finally{try{if(board.hasPointerCapture?.(e.pointerId))board.releasePointerCapture(e.pointerId)}catch(_){}}},{passive:false});
   board.addEventListener('pointercancel',()=>{state.drag=null;if(typeof draw==='function')draw()},{passive:true});
 }
 let last=performance.now();
 function frame(now){
   const gap=now-last;last=now;
   if(gameActive()&&gap>1000&&state.running&&!state.gameOver){
     // Don't let a background tab consume the whole turn timer.
     if(Number.isFinite(state.turnStart))state.turnStart+=Math.min(gap-100,5000);
     state.last=now;
   }
   sync();
   requestAnimationFrame(frame);
 }
 requestAnimationFrame(frame);
 window.CarromPart1={version:'72.P1',name:'Core Gameplay Polish',canShoot,normalizeCore};
})();
