const fs=require('fs'), path=require('path'), vm=require('vm');
const root=__dirname; const must=['index.html','style.css','game.js','backend-bridge.js','v55-upgrade.js','v56-upgrade.js','v57-upgrade.js','manifest.json','server/server.js','server/physics.js','server/repository.js'];
for(const f of must){if(!fs.existsSync(path.join(root,f)))throw new Error('missing '+f)}
const js=['game.js','feature-center.js','quick-hub.js','product-release.js','backend-bridge.js','product-qa.js','v51-upgrade.js','v52-upgrade.js','v53-upgrade.js','v54-upgrade.js','v55-upgrade.js','v56-upgrade.js','v57-upgrade.js','release-qa.js','release-qa-v54.js','release-qa-v57.js'];
for(const f of js){new vm.Script(fs.readFileSync(path.join(root,f),'utf8'),{filename:f})}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/id="([^"]+)"/g)].map(x=>x[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);if(dup.length)throw new Error('duplicate ids '+dup.join(','));
const man=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));if(man.version!=='57.0.0')throw new Error('manifest version mismatch');
if(!html.includes('v57-upgrade.js')||!html.includes('v55-upgrade.js'))throw new Error('upgrade scripts missing');
console.log('V57.0 QA PASS');console.log('source files:',must.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs: NONE');console.log('manifest:',man.version);console.log('V55/V56/V57 upgrade chain: PASS');
