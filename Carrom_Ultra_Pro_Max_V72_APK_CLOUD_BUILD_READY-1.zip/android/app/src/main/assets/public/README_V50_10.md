# Carrom Ultra Pro Max — V50.10 Ultra Pro Max Upgrade

V50.10 is a hardening/reliability release built on V50.9 while preserving the V1–V50 product surface and reference visual language.

## Upgrade highlights
- Production configuration guardrails
- Refresh-token identifier hashing at rest
- One-time short-lived WebSocket tickets
- WebSocket packet-rate protection
- Authenticated match-state endpoint
- Authenticated payment-order status endpoint
- Expired-session/webhook/match cleanup
- Stronger refresh request validation
- Mobile/reference UI preserved
- Existing V1–V50 systems retained

## QA
Run `node release-qa.js` for static release checks. Runtime API checks require installing the server dependencies and running the server in a controlled environment.


V70.0 — Ultra Pro Max UI Signature Finish 14.0: layered component surfaces, interaction states, safe-area/mobile polish, responsive grid normalization, focus accessibility, horizontal strip handling, and visibility-aware feedback. Existing systems preserved.
