/* PART 7 — Audio & Haptics Ultra Pro Max
   Additive sensory polish: no gameplay authority is changed. */
(() => {
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const STORE = 'carrom-part7-audio';
  const defaults = { volume: 0.72, haptics: true, cues: true };
  let pref = defaults;
  try { pref = Object.assign({}, defaults, JSON.parse(localStorage.getItem(STORE) || '{}')); } catch (_) {}
  let ctx = null, master = null, lastMessage = '', lastStatus = '', lastCue = 0;

  function ensureAudio() {
    if (!pref.cues || pref.volume <= 0) return null;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      master = master || ctx.createGain();
      master.gain.value = pref.volume;
      if (!master._connected) { master.connect(ctx.destination); master._connected = true; }
      return ctx;
    } catch (_) { return null; }
  }
  function tone(freq=440, duration=.055, type='sine', gain=.045, when=0) {
    const ac = ensureAudio(); if (!ac) return;
    try {
      const now = ac.currentTime + when;
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = type; o.frequency.setValueAtTime(freq, now);
      g.gain.setValueAtTime(.0001, now);
      g.gain.exponentialRampToValueAtTime(Math.max(.0002, gain), now + .008);
      g.gain.exponentialRampToValueAtTime(.0001, now + duration);
      o.connect(g); g.connect(master); o.start(now); o.stop(now + duration + .012);
    } catch (_) {}
  }
  const patterns = {
    tap: [7], aim: [5, 5], pocket: [10, 18], queen: [12, 25, 12], foul: [28, 12, 28],
    win: [12, 18, 28], lose: [24, 18], pause: [10], resume: [7, 7]
  };
  function haptic(name='tap') {
    if (!pref.haptics || !navigator.vibrate) return;
    try { navigator.vibrate(patterns[name] || patterns.tap); } catch (_) {}
  }
  function cue(name) {
    const now = performance.now();
    if (now - lastCue < 70) return;
    lastCue = now;
    const map = {
      tap: [[520,.035,'sine',.025]], aim: [[330,.025,'sine',.018]],
      pocket: [[520,.045,'triangle',.032],[720,.06,'triangle',.026,.045]],
      queen: [[620,.06,'triangle',.035],[820,.08,'triangle',.032,.07]],
      foul: [[180,.09,'sawtooth',.028],[120,.11,'sawtooth',.024,.09]],
      win: [[520,.06,'triangle',.03],[660,.07,'triangle',.032,.07],[840,.11,'triangle',.038,.15]],
      lose: [[360,.09,'sine',.025],[240,.13,'sine',.022,.1]], pause: [[260,.05,'sine',.022]], resume: [[440,.045,'sine',.022],[620,.05,'sine',.02,.06]]
    };
    (map[name] || map.tap).forEach(x => tone(...x));
    haptic(name);
  }
  function persist() { try { localStorage.setItem(STORE, JSON.stringify(pref)); } catch (_) {} }
  function wireSettings() {
    $$('.toggle[data-setting]').forEach(t => {
      if (!t.hasAttribute('role')) t.setAttribute('role','switch');
      t.setAttribute('aria-checked', t.classList.contains('on') ? 'true' : 'false');
      if (t.dataset.setting === 'vibration' || t.dataset.setting === 'sound' || t.dataset.setting === 'music') {
        t.addEventListener('click', () => {
          t.setAttribute('aria-checked', t.classList.contains('on') ? 'true' : 'false');
          cue('tap');
        }, {passive:true});
      }
    });
  }
  function installVolumeUI() {
    const panel = $('#settingsRows');
    if (!panel || $('#part7AudioControls')) return;
    const wrap = document.createElement('div');
    wrap.id = 'part7AudioControls';
    wrap.className = 'part7-audio-controls';
    wrap.innerHTML = '<div class="part7-audio-head"><span>Audio & Haptics</span><b id="part7VolumeValue">72%</b></div><label class="part7-range-label" for="part7Volume">Master volume</label><input id="part7Volume" type="range" min="0" max="100" value="72" step="1" aria-label="Master volume"><label class="part7-check"><input id="part7Cues" type="checkbox" checked> Enhanced sound cues</label><label class="part7-check"><input id="part7Haptics" type="checkbox" checked> Haptic feedback</label>';
    panel.appendChild(wrap);
    const range = $('#part7Volume'), value = $('#part7VolumeValue'), cuesBox = $('#part7Cues'), hapBox = $('#part7Haptics');
    range.value = String(Math.round(pref.volume * 100)); cuesBox.checked = !!pref.cues; hapBox.checked = !!pref.haptics;
    const sync = () => { pref.volume = Number(range.value)/100; pref.cues = cuesBox.checked; pref.haptics = hapBox.checked; value.textContent = range.value + '%'; persist(); if (pref.cues) { ensureAudio(); cue('tap'); } };
    range.addEventListener('input', sync); cuesBox.addEventListener('change', sync); hapBox.addEventListener('change', sync);
  }
  function observeFeedback() {
    const message = $('#gameMessage'), status = $('#hudStatus');
    const obs = new MutationObserver(() => {
      const m = (message?.textContent || '').trim();
      const s = (status?.textContent || '').trim().toUpperCase();
      if (m && m !== lastMessage) {
        lastMessage = m;
        const low = m.toLowerCase();
        if (low.includes('foul') || low.includes('penalty')) cue('foul');
        else if (low.includes('queen')) cue('queen');
        else if (low.includes('pocket')) cue('pocket');
      }
      if (s && s !== lastStatus) {
        lastStatus = s;
        if (s.includes('PAUSE')) cue('pause');
        else if (s.includes('YOUR TURN') || s === 'READY') cue('resume');
        else if (s.includes('COMPLETE')) cue('win');
      }
    });
    if (message) obs.observe(message, {childList:true, characterData:true, subtree:true});
    if (status) obs.observe(status, {childList:true, characterData:true, subtree:true});
  }
  document.addEventListener('pointerdown', e => {
    const target = e.target.closest?.('button,[role="button"],input[type="range"]');
    if (target) ensureAudio();
  }, {passive:true, capture:true});
  document.addEventListener('keydown', e => { if (e.key === ' ' || e.key === 'Enter') ensureAudio(); }, {passive:true});
  document.addEventListener('visibilitychange', () => {
    if (!ctx) return;
    if (document.hidden) { if (ctx.state === 'running') ctx.suspend().catch(() => {}); }
    else if (pref.cues && ctx.state === 'suspended') ctx.resume().catch(() => {});
  });
  const boot = () => { wireSettings(); installVolumeUI(); observeFeedback(); window.CarromPart7Audio = { cue, haptic, ensureAudio, preferences: pref }; document.documentElement.classList.add('part7-audio-ready'); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true}); else boot();
})();
