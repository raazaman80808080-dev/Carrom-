/* PART 16 — Functional UI polish. No gameplay state mutation. */
(function(){'use strict';
  const $=s=>document.querySelector(s);
  const game=$('#game'), board=$('#board');
  function safeAttr(el,name,value){if(el&&!el.getAttribute(name))el.setAttribute(name,value);}
  function syncGameLabels(){
    if(!game)return;
    const ids=['gameTitle','gameScore','turnName','turnTimer','queenStatus','modeBadge','oppName','oppScore','yourScore','shotCountHUD','powerHUD','spinHUD','bankHUD','pocketHUD','foulHUD','hudStatus','gameMessage'];
    ids.forEach(id=>{const el=document.getElementById(id);if(el) safeAttr(el,'aria-label',el.textContent.trim()||id);});
    const timer=$('#turnTimer'); if(timer){timer.setAttribute('role','timer');timer.setAttribute('aria-live','polite');}
    const status=$('#hudStatus'); if(status){status.setAttribute('role','status');status.setAttribute('aria-live','polite');}
    const msg=$('#gameMessage'); if(msg){msg.setAttribute('role','status');msg.setAttribute('aria-live','polite');}
  }
  function wirePress(){
    document.querySelectorAll('button').forEach(btn=>{
      if(btn.dataset.p16Bound)return; btn.dataset.p16Bound='1';
      btn.addEventListener('pointerdown',()=>btn.classList.add('p16-pressed'),{passive:true});
      const clear=()=>btn.classList.remove('p16-pressed');
      btn.addEventListener('pointerup',clear,{passive:true});btn.addEventListener('pointercancel',clear,{passive:true});btn.addEventListener('blur',clear,{passive:true});
    });
  }
  function keepViewport(){
    const vv=window.visualViewport;if(!vv)return;
    document.documentElement.style.setProperty('--p16-vh',vv.height+'px');
    document.documentElement.style.setProperty('--p16-vw',vv.width+'px');
  }
  function init(){
    safeAttr(game,'aria-label','Carrom game screen');
    safeAttr(board,'role','img');
    safeAttr(board,'aria-label','Interactive carrom board. Drag from the striker to aim and release to shoot.');
    const power=$('#powerRange'); if(power){safeAttr(power,'aria-label','Shot power');power.setAttribute('inputmode','none');}
    ['#leftNudge','#rightNudge','#undo','#reset','#gameRules'].forEach(s=>{const el=$(s);if(el)el.setAttribute('type','button');});
    syncGameLabels();wirePress();keepViewport();
    window.CarromPart16UI={version:'16.0.0',refresh:function(){syncGameLabels();wirePress();keepViewport();}};
  }
  addEventListener('resize',keepViewport,{passive:true});
  if(window.visualViewport)visualViewport.addEventListener('resize',keepViewport,{passive:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
