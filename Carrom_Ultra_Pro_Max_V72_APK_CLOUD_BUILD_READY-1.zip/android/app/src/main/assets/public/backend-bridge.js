(function(){'use strict';
const KEY='carrom_v50_8_backend';
const cfg=Object.assign({enabled:false,baseUrl:'http://localhost:8080',wsUrl:'ws://localhost:8080/ws',provider:'disabled'},JSON.parse(localStorage.getItem(KEY)||'{}'));
function save(){localStorage.setItem(KEY,JSON.stringify(cfg));}
async function health(){if(!cfg.enabled)return {ok:false,mode:'LOCAL',reason:'backend-disabled'};try{const r=await fetch(cfg.baseUrl+'/health');const j=await r.json();return {ok:!!j.ok,mode:'REMOTE',data:j}}catch(e){return {ok:false,mode:'REMOTE',reason:e.message}}}
function setConfig(next){Object.assign(cfg,next||{});save();render();}
async function render(){const el=document.querySelector('[data-backend-status]');if(!el)return;el.textContent='CHECKING…';const h=await health();el.textContent=h.ok?'ONLINE AUTHORITY':'LOCAL / OFFLINE';el.dataset.ok=h.ok?'1':'0';}
async function request(path,options={}){if(!cfg.enabled)throw new Error('BACKEND_DISABLED');const token=localStorage.getItem('carrom_access_token')||'';const headers=Object.assign({'Content-Type':'application/json'},options.headers||{},token?{'Authorization':'Bearer '+token}:{});const r=await fetch(cfg.baseUrl+path,Object.assign({},options,{headers}));const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||('HTTP_'+r.status));return j}
async function register(email,password){const j=await request('/api/auth/register',{method:'POST',body:JSON.stringify({email,password})});localStorage.setItem('carrom_access_token',j.accessToken);localStorage.setItem('carrom_refresh_token',j.refreshToken);return j}
async function login(email,password){const j=await request('/api/auth/login',{method:'POST',body:JSON.stringify({email,password})});localStorage.setItem('carrom_access_token',j.accessToken);localStorage.setItem('carrom_refresh_token',j.refreshToken);return j}
async function refresh(){const rt=localStorage.getItem('carrom_refresh_token');if(!rt)throw new Error('NO_REFRESH_TOKEN');const j=await request('/api/auth/refresh',{method:'POST',body:JSON.stringify({refreshToken:rt}),headers:{}});localStorage.setItem('carrom_access_token',j.accessToken);localStorage.setItem('carrom_refresh_token',j.refreshToken);return j}
function clearAuth(){localStorage.removeItem('carrom_access_token');localStorage.removeItem('carrom_refresh_token')}
window.CarromBackend={cfg,health,setConfig,render,request,register,login,refresh,clearAuth};
window.addEventListener('DOMContentLoaded',render);
})();

// V52.0 authority controls: safe configuration + diagnostics, never stores provider secrets in the client.
(function(){'use strict';
  function open(){
    let o=document.getElementById('backendAuthorityOverlay');
    if(!o){o=document.createElement('div');o.id='backendAuthorityOverlay';o.className='pr-overlay';o.innerHTML='<div class="pr-shell"><header><div><span>CARROM ULTIMATE</span><b>V52.0 ONLINE AUTHORITY</b></div><button data-bx>×</button></header><div class="pr-hero"><div><small>SECURE CLIENT BRIDGE</small><h2>Online / Offline control</h2><p>Only endpoint settings live here. Payment secrets, JWT secrets and provider credentials stay on the server.</p></div><div class="pr-health"><b data-bh>—</b><small>STATUS</small></div></div><div class="pr-audit"><label>API base URL<input data-bu></label><label>WebSocket URL<input data-bw></label><label><input type="checkbox" data-be> Enable remote authority</label></div><div class="pr-actions"><button data-bs>SAVE & CHECK</button><button data-bc>LOCAL MODE</button></div></div>';document.body.appendChild(o)}
    o.classList.add('show'); const api=window.CarromBackend; const cfg=api.cfg; o.querySelector('[data-bu]').value=cfg.baseUrl; o.querySelector('[data-bw]').value=cfg.wsUrl; o.querySelector('[data-be]').checked=!!cfg.enabled;
    o.querySelector('[data-bx]').onclick=()=>o.classList.remove('show'); o.querySelector('[data-bc]').onclick=()=>{api.setConfig({enabled:false});o.classList.remove('show')};
    o.querySelector('[data-bs]').onclick=async()=>{api.setConfig({enabled:o.querySelector('[data-be]').checked,baseUrl:o.querySelector('[data-bu]').value.replace(/\/$/,''),wsUrl:o.querySelector('[data-bw]').value.trim()});const h=await api.health();o.querySelector('[data-bh]').textContent=h.ok?'ONLINE':'OFFLINE'};
    api.health().then(h=>{const e=o.querySelector('[data-bh]');if(e)e.textContent=h.ok?'ONLINE':'OFFLINE'});
  }
  document.addEventListener('click',e=>{if(e.target.closest('[data-backend-open]'))open()});
})();
