const fs=require('fs'),path=require('path');
const root=__dirname;
const js=fs.readdirSync(root).filter(f=>f.endsWith('.js'));
for(const f of js){try{require('child_process').execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'ignore'})}catch(e){throw new Error('JS syntax failed: '+f)}}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
if(dup.length)throw new Error('Duplicate IDs: '+[...new Set(dup)].join(','));
for(const f of ['v55-upgrade.js','v56-upgrade.js','v57-upgrade.js','v58-upgrade.js'])if(!fs.existsSync(path.join(root,f)))throw new Error('Missing upgrade: '+f);
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
if(manifest.version!=='58.0.0')throw new Error('Manifest version mismatch');
if(!html.includes('v57-upgrade.js')||!html.includes('v58-upgrade.js'))throw new Error('Upgrade chain missing');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');
for(const token of ['v58-engine','v58-board-stage','v58-press','v58-match-in'])if(!css.includes(token))throw new Error('Missing CSS token '+token);
console.log('V58.0 QA PASS');console.log('source files:',js.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs:',dup.length?'FAIL':'NONE');console.log('manifest:',manifest.version);console.log('V55/V56/V57/V58 upgrade chain: PASS');
