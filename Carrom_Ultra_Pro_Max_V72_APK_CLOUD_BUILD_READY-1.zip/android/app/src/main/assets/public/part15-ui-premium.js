/* PART 15 — UI composition/runtime polish. Additive and gameplay-safe. */
(function(){'use strict';
 const root=document.documentElement;
 function fit(){
   const vv=window.visualViewport;
   if(vv){root.style.setProperty('--viewport-h',vv.height+'px');root.style.setProperty('--viewport-w',vv.width+'px');}
   document.body.classList.toggle('p15-narrow',innerWidth<621);
 }
 function decorate(){
   document.querySelectorAll('button').forEach(b=>{if(!b.getAttribute('type'))b.setAttribute('type','button'); if(!b.getAttribute('aria-label') && !b.textContent.trim()) b.setAttribute('aria-label','Action');});
   document.querySelectorAll('.screen').forEach(s=>{if(!s.getAttribute('tabindex'))s.setAttribute('tabindex','-1');});
   const board=document.getElementById('board'); if(board){board.setAttribute('role','img');board.setAttribute('aria-label','Interactive carrom board. Drag from the striker to aim and release to shoot.');}
 }
 function announce(){
   const toast=document.getElementById('toast');
   if(toast && !toast.getAttribute('role')){toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');toast.setAttribute('aria-atomic','true');}
 }
 addEventListener('resize',fit,{passive:true}); addEventListener('orientationchange',fit,{passive:true}); document.addEventListener('DOMContentLoaded',()=>{fit();decorate();announce();});
 if(window.visualViewport){visualViewport.addEventListener('resize',fit,{passive:true});visualViewport.addEventListener('scroll',fit,{passive:true});}
 window.CarromPart15UI={version:'15.0.0',refresh:function(){fit();decorate();announce();}};
})();
