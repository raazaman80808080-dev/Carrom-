/* V72 Phase 10 — Ultra Master Playability + HUD telemetry. Additive only. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 let mounted=false,lastShot=0;
 const safe=(fn)=>{try{return fn()}catch(_){return null}};
 function install(){
  const game=$('#game'); if(!game||$('#u10MasterHud')) return;
  const el=document.createElement('aside'); el.id='u10MasterHud'; el.className='u10-master-hud';
  el.innerHTML='<div class="u10-top"><span class="u10-dot"></span><b>MASTER PLAY HUD</b><strong id="u10State">READY</strong></div><div class="u10-grid"><div><small>TURN</small><b id="u10Turn">—</b></div><div><small>TIME</small><b id="u10Time">—</b></div><div><small>POWER</small><b id="u10Power">55%</b></div><div><small>COINS</small><b id="u10Coins">0</b></div></div><div class="u10-meter"><i id="u10Meter"></i></div><div class="u10-tip" id="u10Tip">Drag from the striker and release to shoot.</div></aside>';
  game.appendChild(el); mounted=true;
 }
 function tip(){
  if(typeof state==='undefined')return 'Start a match to play.';
  if(state.gameOver)return 'Match complete · Play Again to start a fresh round.';
  if(!state.running)return 'Match paused · Resume when ready.';
  if(state.players===2&&state.turn===1)return 'CPU is calculating the next shot…';
  if(state.queenPending)return 'Queen captured · pocket your own coin to cover it.';
  if(state.turnPocket)return 'Pocket made · you may continue your turn.';
  return 'Drag from the striker · aim carefully · release to shoot.';
 }
 function sync(){
  if(!mounted||typeof state==='undefined')return;
  const game=state.screen==='game'; const active=game&&!state.gameOver&&state.running;
  const cpu=game&&state.players===2&&state.turn===1;
  const movingNow=safe(()=>typeof moving==='function'&&moving())||false;
  const status=state.gameOver?'MATCH COMPLETE':!game?'READY':!state.running?'PAUSED':movingNow?'SHOT IN PLAY':cpu?'CPU TURN':'YOUR TURN';
  const set=(id,v)=>{const e=$('#'+id);if(e)e.textContent=v};
  set('u10State',status); set('u10Turn',game?(cpu?'CPU':'P'+(state.turn+1)):'—');
  set('u10Power',Math.round(state.power||0)+'%'); set('u10Coins',Math.max(0,state.coins||0).toLocaleString());
  set('u10Time',game&&Number.isFinite(state.timer)?Math.ceil(state.timer)+'s':'—');
  const meter=$('#u10Meter'); if(meter)meter.style.width=Math.max(0,Math.min(100,(state.power||0)))+'%';
  const t=$('#u10Tip');if(t)t.textContent=tip();
  const hud=$('#u10MasterHud');if(hud)hud.classList.toggle('u10-live',active);
 }
 function lifecycle(){
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync()},{passive:true});
  document.addEventListener('keydown',e=>{
   if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return;
   if(e.key==='Home'&&state.running&&!safe(()=>moving())){e.preventDefault();if(typeof nudge==='function')nudge(-1)}
   if(e.key==='End'&&state.running&&!safe(()=>moving())){e.preventDefault();if(typeof nudge==='function')nudge(1)}
  });
 }
 function boot(){install();lifecycle();sync();setInterval(sync,200)}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromUltraMaster={version:'72.10',telemetryHUD:true,playability:true};
})();
