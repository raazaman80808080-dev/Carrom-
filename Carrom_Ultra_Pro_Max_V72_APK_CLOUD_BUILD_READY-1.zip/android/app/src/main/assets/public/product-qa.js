(()=>{'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function toast(t){if(window.toast)window.toast(t);else{const e=$('#toast');if(e){e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1800)}}}
function run(){
 const navIds=$$('.nav[data-go]').map(x=>x.dataset.go); const routes=['home','play','tournament','profile','shop','global','systems','settings'];
 const missingRoutes=routes.filter(x=>!navIds.includes(x));
 const ids=$$('[id]').map(x=>x.id), dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
 const catalog=window.CarromFeatureCenter?.catalog||[];
 const featureCount=catalog.reduce((n,s)=>n+s.features.length,0);
 const checks=[
  ['Primary navigation',missingRoutes.length===0,missingRoutes.length?missingRoutes.join(', '):'8/8 routes'],
  ['V1–V50 catalog',catalog.length===50,'50 systems indexed'],
  ['Feature coverage',featureCount>300,featureCount+' features indexed'],
  ['Daily / Free / Spin',typeof window.CarromQuickHub?.open==='function','quick reward hub ready'],
  ['Gameplay engine',typeof window.startGame==='function','local gameplay entry ready'],
  ['Persistence',typeof window.save==='function','save layer ready'],
  ['Replay engine',typeof window.v16Ensure==='function','replay hook ready'],
  ['Competitive engine',typeof window.v7Ensure==='function','ranked hook ready'],
  ['Duplicate DOM ids',dup.length===0,dup.length?'duplicates: '+[...new Set(dup)].slice(0,5).join(', '):'none detected'],
  ['Responsive shell',!!document.querySelector('meta[name="viewport"]'),'viewport configured']
 ];
 const pass=checks.filter(x=>x[1]).length;
 let o=$('#productQAOverlay');if(!o){o=document.createElement('div');o.id='productQAOverlay';o.className='pr-overlay';document.body.appendChild(o)}
 o.innerHTML=`<div class="pr-shell"><header><div><span>CARROM ULTIMATE</span><b>V56.0 PRODUCT QA</b></div><button data-qa-close>×</button></header><div class="pr-hero"><div><small>LOCAL BUILD HEALTH</small><h2>${pass}/${checks.length} checks passing</h2><p>Client-side smoke checks for navigation, feature coverage, persistence and core entry points.</p></div><div class="pr-health"><b>${catalog.length}/50</b><small>SYSTEMS</small><b>${featureCount}</b><small>FEATURES</small></div></div><div class="pr-audit">${checks.map(x=>`<div><span class="${x[1]?'ok':'warn'}">${x[1]?'✓':'!'}</span><b>${x[0]}</b><small>${x[2]}</small></div>`).join('')}</div><p class="pr-note">This is a client smoke test. Remote server authority, payment processing and real online networking still require their production services.</p><button class="pr-primary" data-qa-recheck>↻ RUN AGAIN</button></div>`;
 o.classList.add('show');
 o.querySelector('[data-qa-close]').onclick=()=>o.classList.remove('show');
 o.querySelector('[data-qa-recheck]').onclick=run;
 o.onclick=e=>{if(e.target===o)o.classList.remove('show')};
}
if(typeof window!=='undefined') window.CarromProductQA={run};
if(typeof module!=='undefined'&&module.exports) module.exports={run};
})();
