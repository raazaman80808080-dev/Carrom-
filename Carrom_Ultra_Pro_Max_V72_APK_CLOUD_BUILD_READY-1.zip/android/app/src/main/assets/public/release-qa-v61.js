const fs=require('fs'), path=require('path'), assert=require('assert');
const root=__dirname;
const files=fs.readdirSync(root);
const src=files.filter(f=>/\.(js|html|css|json)$/.test(f));
for(const f of src){const s=fs.readFileSync(path.join(root,f),'utf8'); if(f.endsWith('.js')){try{require('child_process').execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'pipe'})}catch(e){throw new Error('JS syntax failed: '+f)}}}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
assert(html.includes('v60-upgrade.js')&&html.includes('v61-upgrade.js'),'upgrade chain missing');
assert(html.includes('V61.0 READY')&&html.includes('PRODUCT V61.0'),'version UI missing');
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);assert(!dup.length,'duplicate DOM IDs: '+[...new Set(dup)].join(','));
const v61=fs.readFileSync(path.join(root,'v61-upgrade.js'),'utf8');for(const token of ['v61-engine','v61Finish','v61Streak','QUEEN','MATCH COMPLETE','reduced-motion'])assert(v61.includes(token),'V61 token missing: '+token);
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));assert(manifest.version==='61.0.0','manifest version mismatch');
console.log('V61.0 QA PASS');console.log('source files:',src.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs:',dup.length?'FOUND '+[...new Set(dup)].join(','):'NONE');console.log('manifest:',manifest.version);console.log('V55/V56/V57/V58/V59/V60/V61 upgrade chain: PASS');
