/* V72 Phase 8 — Ultra systems + playable recovery + precision UX. Additive/defensive. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s), KEY='carrom_ultra_active_match_v72';
 let checkpointTimer=0, restored=false;
 const safe=(fn)=>{try{return fn()}catch(_){return null}};
 function install(){
  const game=$('#game'); if(!game||$('#u8Overlay'))return;
  const overlay=document.createElement('div'); overlay.id='u8Overlay'; overlay.className='u8-overlay';
  overlay.innerHTML='<div class="u8-panel"><span class="u8-live"><i></i> MATCH ENGINE</span><strong id="u8Status">READY</strong><small id="u8Hint">Precision controls active</small><div class="u8-row"><span>AIM</span><b>DRAG</b><span>POWER</span><b id="u8Power">55%</b><span>SPIN</span><b id="u8Spin">0</b></div></div>';
  game.appendChild(overlay);
  document.addEventListener('pointerdown',e=>{
   const board=e.target.closest?.('#board'); if(!board||typeof state==='undefined')return;
   if(state.screen!=='game'||state.gameOver||!state.running||typeof moving==='function'&&moving()) return;
   if(e.pointerType==='touch') board.style.touchAction='none';
  },{capture:true,passive:true});
 }
 function checkpoint(){
  if(typeof state==='undefined'||typeof striker==='undefined'||!Array.isArray(pieces))return;
  if(state.screen!=='game'||state.gameOver)return;
  safe(()=>sessionStorage.setItem(KEY,JSON.stringify({v:1,at:Date.now(),s:striker,p:pieces,score:state.score,turn:state.turn,queen:state.queen,queenPending:state.queenPending,queenCapturedBy:state.queenCapturedBy,coins:state.coins,gems:state.gems,shotCount:state.shotCount,mode:state.mode,players:state.players,power:state.power,spin:state.spin,timer:state.timer,difficulty:state.difficulty})));
 }
 function clearCheckpoint(){safe(()=>sessionStorage.removeItem(KEY))}
 function restore(){
  if(restored||typeof state==='undefined')return; restored=true;
  const raw=safe(()=>sessionStorage.getItem(KEY)); if(!raw)return;
  const d=safe(()=>JSON.parse(raw)); if(!d||Date.now()-d.at>10*60*1000||!Array.isArray(d.p)||!d.s)return;
  if(!confirm('Resume your interrupted match?')){clearCheckpoint();return;}
  try{
   striker=d.s; pieces=d.p; state.score=d.score||[0,0]; state.turn=d.turn||0; state.queen=d.queen!==false; state.queenPending=!!d.queenPending; state.queenCapturedBy=d.queenCapturedBy??null; state.coins=d.coins??state.coins; state.gems=d.gems??state.gems; state.shotCount=d.shotCount||0; state.mode=d.mode||'classic'; state.players=d.players||2; state.power=d.power||55; state.spin=d.spin||0; state.timer=d.timer||30; state.gameOver=false; state.running=true; state.lastShotAt=0; state.aiBusy=false;
   if(typeof show==='function')show('game'); if(typeof updateHUD==='function')updateHUD(); if(typeof draw==='function')draw(); if(typeof toast==='function')toast('↻ Match restored safely');
  }catch(_){clearCheckpoint()}
 }
 function bindLifecycle(){
  const start=window.startGame;
  if(typeof start==='function'&&!start.__u8){window.startGame=function(){clearCheckpoint();return start.apply(this,arguments)};window.startGame.__u8=true}
  const reset=window.resetGame;
  if(typeof reset==='function'&&!reset.__u8){window.resetGame=function(){clearCheckpoint();return reset.apply(this,arguments)};window.resetGame.__u8=true}
  window.addEventListener('pagehide',checkpoint,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)checkpoint()},{passive:true});
 }
 function sync(){
  try{
   if(typeof state==='undefined'||state.screen!=='game')return;
   const cpu=state.players===2&&state.turn===1, active=state.running&&!state.gameOver;
   const status=state.gameOver?'MATCH COMPLETE':!active?'PAUSED':cpu?'CPU TURN':'YOUR TURN';
   const s=$('#u8Status'),p=$('#u8Power'),sp=$('#u8Spin'),h=$('#u8Hint');
   if(s)s.textContent=status;if(p)p.textContent=Math.round(state.power||0)+'%';if(sp)sp.textContent=Math.round(state.spin||0);
   if(h)h.textContent=cpu?'CPU is calculating the best angle…':!active?'Resume when ready':'Drag from striker · release to shoot';
   const o=$('#u8Overlay');if(o)o.classList.toggle('u8-paused',!active);
  }catch(_){ }
 }
 function boot(){install();bindLifecycle();restore();checkpointTimer=setInterval(()=>{checkpoint();sync()},1500);sync()}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromUltraPlayableV8={version:'72.8',recovery:'session-checkpoint',precisionUX:true};
})();
