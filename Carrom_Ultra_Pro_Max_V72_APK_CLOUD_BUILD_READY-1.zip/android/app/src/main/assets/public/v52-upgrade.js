/* V52 — production data/economy operations bridge. Keeps local-first UX while surfacing real server state. */
(()=>{
  'use strict';
  const api=window.CarromBackend;if(!api)return;
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  function mount(){
    if(document.getElementById('v52Ops'))return;
    const host=document.querySelector('[data-global-panel="account"]');if(!host)return;
    const box=document.createElement('div');box.id='v52Ops';box.className='v52-ops';box.innerHTML='<div class="v52-head"><div><span>V53 PRODUCTION DATA LAYER</span><h4>ECONOMY & OPERATIONS</h4></div><button id="v52Refresh">REFRESH</button></div><div id="v52Body"><div class="v52-skeleton">Checking authority…</div></div>';
    host.appendChild(box);
    document.getElementById('v52Refresh').onclick=refresh;refresh();
  }
  async function refresh(){
    const body=document.getElementById('v52Body');if(!body)return;
    try{const r=await api.request('/api/ops/repository');const m=await api.request('/api/ops/metrics');body.innerHTML='<div class="v52-grid"><div><b>'+esc(r.adapter.toUpperCase())+'</b><small>DATA ADAPTER</small></div><div><b>'+esc(r.transactional?'ON':'DEV')+'</b><small>TRANSACTIONS</small></div><div><b>'+esc(m.counts.users)+'</b><small>ACCOUNTS</small></div><div><b>'+esc(m.counts.matches)+'</b><small>MATCHES</small></div><div><b>'+esc(m.counts.orders)+'</b><small>ORDERS</small></div><div><b>'+esc(m.counts.pendingSettlements)+'</b><small>PENDING SETTLEMENTS</small></div></div><p class="v52-note">V52 separates local development persistence from the transactional production repository contract. Payment fulfillment remains webhook-verified and idempotent.</p>'}
    catch(e){body.innerHTML='<div class="v52-offline"><b>LOCAL / OFFLINE MODE</b><span>Production operations are available after authenticated server deployment.</span></div>'}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
