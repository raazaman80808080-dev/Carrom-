/* PART 4 · Controls & Input Ultra Pro Max — additive control reliability layer */
(()=>{
'use strict';
const $=s=>document.querySelector(s);
const board=$('#board'); if(!board)return;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
board.style.touchAction='none'; board.style.webkitTapHighlightColor='transparent';
board.setAttribute('aria-label','Carrom board — drag from striker to aim and release to shoot');
const range=(id,label)=>{const el=$('#'+id); if(el){el.setAttribute('aria-label',label);el.setAttribute('inputmode','none');el.style.touchAction='none';}return el};
range('powerRange','Shot power'); range('spinRange','Shot spin');
let activePointer=null, startAt=0, cancelled=false;
const originalSetPointerCapture=board.setPointerCapture?.bind(board);
board.addEventListener('pointerdown',e=>{
  if(activePointer!==null)return;
  if(e.pointerType==='mouse' && e.button!==0)return;
  activePointer=e.pointerId; startAt=performance.now(); cancelled=false;
  if(originalSetPointerCapture){try{originalSetPointerCapture(e.pointerId)}catch(_) {}}
},{capture:true,passive:false});
board.addEventListener('pointerup',e=>{if(e.pointerId===activePointer){activePointer=null;startAt=0;}},{capture:true,passive:true});
board.addEventListener('pointercancel',e=>{if(e.pointerId===activePointer){cancelled=true;activePointer=null;startAt=0;}},{capture:true,passive:true});
board.addEventListener('lostpointercapture',()=>{activePointer=null;startAt=0;});
board.addEventListener('contextmenu',e=>e.preventDefault());
['gesturestart','gesturechange','gestureend'].forEach(t=>board.addEventListener(t,e=>e.preventDefault(),{passive:false}));
// Prevent accidental browser scrolling/zooming only while interacting with the board.
['touchstart','touchmove'].forEach(t=>board.addEventListener(t,e=>{if(e.touches?.length>1)e.preventDefault();},{passive:false}));
// Keep control ranges synchronized with live state without stealing focus.
const sync=()=>{const p=$('#powerRange'),s=$('#spinRange'); if(p&&typeof state!=='undefined')p.value=clamp(Number(state.power)||55,10,100);if(s&&typeof state!=='undefined')s.value=clamp(Number(state.spin)||0,-100,100);};
window.addEventListener('visibilitychange',()=>{if(document.hidden){activePointer=null;cancelled=true;}else sync();},{passive:true});
window.addEventListener('resize',sync,{passive:true});
// Keyboard controls are conservative: never trigger while typing.
document.addEventListener('keydown',e=>{
 const tag=(e.target?.tagName||'').toLowerCase(); if(tag==='input'||tag==='textarea'||tag==='select'||e.target?.isContentEditable)return;
 if(e.key==='ArrowLeft' || e.key==='ArrowRight'){
   const el=$('#leftNudge')||$('#rightNudge'); if(el){const target=e.key==='ArrowLeft'?$('#leftNudge'):$('#rightNudge');target?.click();e.preventDefault();}
 }
 if(e.key===' '){const pause=document.querySelector('[data-tool="pause"]'); if(pause){pause.click();e.preventDefault();}}
 if(e.key==='Escape' && typeof state!=='undefined' && state.drag){state.drag=null;document.querySelector('.board-wrap')?.classList.remove('focus');e.preventDefault();}
},{capture:true});
// Make existing nudge controls safer and more precise.
['leftNudge','rightNudge'].forEach(id=>{const b=$('#'+id);if(b){b.setAttribute('aria-label',id==='leftNudge'?'Move striker left':'Move striker right');b.setAttribute('type','button');b.style.touchAction='manipulation';}});
// Crisp rendering hints; no feature replacement.
document.documentElement.classList.add('part4-controls-ready');
window.CarromPart4Controls={version:'1.0.0',clamp, sync};
})();
