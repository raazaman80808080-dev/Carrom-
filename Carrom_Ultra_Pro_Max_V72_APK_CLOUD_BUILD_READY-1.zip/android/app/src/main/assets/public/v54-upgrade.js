/* Carrom Ultra Pro Max V54.0 — Precision UI / performance polish layer. */
(()=>{
'use strict';
const q=s=>document.querySelector(s), qa=s=>[...document.querySelectorAll(s)];
function mount(){
 if(document.getElementById('v54Core'))return;
 const top=q('.top'), badge=q('.product-chip');
 if(badge){badge.textContent='V54.0 ULTRA';badge.setAttribute('title','V54.0 Precision UI');}
 const line=document.createElement('div');line.id='v54Core';line.className='v54-core-line';line.innerHTML='<i></i><span>ULTRA CORE</span><b id="v54Fps">60 FPS TARGET</b><em id="v54Mode">LOCAL-FIRST</em>';
 top?.appendChild(line);
 qa('button').forEach((b)=>{
   if(!b.getAttribute('aria-label') && !b.textContent.trim()) b.setAttribute('aria-label','Action');
   b.addEventListener('pointerdown',()=>b.dataset.press='1',{passive:true});
   ['pointerup','pointercancel','pointerleave'].forEach(ev=>b.addEventListener(ev,()=>delete b.dataset.press,{passive:true}));
   b.addEventListener('click',e=>{const r=b.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;if(!Number.isFinite(x)||!Number.isFinite(y))return;const s=document.createElement('i');s.className='v54-ripple';s.style.left=x+'px';s.style.top=y+'px';b.appendChild(s);setTimeout(()=>s.remove(),560);},{passive:true});
 });
 qa('.nav').forEach((b,i)=>b.style.setProperty('--nav-i',i));
 let frames=0,last=performance.now(),fps=60;
 function tick(now){frames++;if(now-last>=1000){fps=Math.round(frames*1000/(now-last));frames=0;last=now;const el=q('#v54Fps');if(el)el.textContent=Math.max(1,Math.min(120,fps))+' FPS';}requestAnimationFrame(tick)}
 requestAnimationFrame(tick);
 const online=()=>{const el=q('#v54Mode');if(el)el.textContent=navigator.onLine?'ONLINE READY':'LOCAL-FIRST';line.dataset.online=navigator.onLine?'1':'0'};
 addEventListener('online',online);addEventListener('offline',online);online();
 if('serviceWorker' in navigator) navigator.serviceWorker.ready.then(()=>line.dataset.cache='1').catch(()=>{});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
