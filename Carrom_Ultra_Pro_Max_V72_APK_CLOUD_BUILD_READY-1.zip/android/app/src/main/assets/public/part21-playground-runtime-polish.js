/* V72 Part 21 — Playground runtime resilience. Never replaces authoritative gameplay. */
(()=>{
 'use strict';
 const VALID=new Set(['classic','black','free','pool','practice','time','challenge']);
 const $=s=>document.querySelector(s);
 const $$=s=>Array.from(document.querySelectorAll(s));
 const label=m=>({classic:'Classic Carrom',black:'Black & White',free:'Freestyle',pool:'Disc Pool',practice:'Solo Practice',time:'Time Attack',challenge:'Challenge'})[m]||'Carrom';
 function hardenPlayButton(b){
   if(!b)return;
   b.type='button';
   const mode=VALID.has(b.dataset.game)?b.dataset.game:'classic';
   b.dataset.game=mode;
   if(!b.dataset.players)b.dataset.players='2';
   b.classList.add('playground-ready');
   b.setAttribute('aria-label',b.getAttribute('aria-label')||`Start ${label(mode)}${b.dataset.players==='4'?' · 4 Player':''} match`);
 }
 function stateHealthy(){
   if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return true;
   const board=$('#board');
   if(!board||!VALID.has(state.mode)||!window.striker||!Array.isArray(window.pieces))return false;
   if(!Number.isFinite(state.turn)||state.turn<0||state.turn>=state.players)return false;
   return true;
 }
 function sync(){
   if(typeof state==='undefined')return;
   const game=$('#game'); if(game)game.dataset.matchState=state.screen==='game'?(state.gameOver?'finished':state.running?'running':'paused'):'idle';
   const title=$('#gameTitle');
   if(title&&state.screen==='game'&&VALID.has(state.mode))title.textContent=label(state.mode).toUpperCase();
   const badge=$('#modeBadge');
   if(badge&&state.screen==='game'&&VALID.has(state.mode))badge.textContent=label(state.mode).toUpperCase();
 }
 function recover(){
   if(!stateHealthy()){
     if(typeof state!=='undefined'&&state.screen==='game'&&typeof resetGame==='function'&&!state.gameOver){
       try{resetGame();sync();return true}catch(_){return false}
     }
     return false;
   }
   sync(); return true;
 }
 function boot(){
   $$('[data-game]').forEach(hardenPlayButton);
   document.addEventListener('click',e=>{
     const b=e.target.closest?.('[data-game]'); if(!b)return;
     hardenPlayButton(b);
     b.setAttribute('aria-busy','true');
     setTimeout(()=>{b.removeAttribute('aria-busy');recover()},120);
     setTimeout(recover,500);
   },true);
   const mo=new MutationObserver(ms=>ms.forEach(m=>Array.from(m.addedNodes||[]).forEach(n=>{
     if(n.nodeType!==1)return;
     if(n.matches?.('[data-game]'))hardenPlayButton(n);
     n.querySelectorAll?.('[data-game]').forEach(hardenPlayButton);
   })));
   mo.observe(document.body,{childList:true,subtree:true});
   document.addEventListener('visibilitychange',()=>{if(!document.hidden)setTimeout(recover,80)});
   window.addEventListener('pageshow',()=>setTimeout(recover,80));
   window.addEventListener('resize',()=>{if(typeof state!=='undefined'&&state.screen==='game'&&typeof draw==='function')requestAnimationFrame(()=>draw())},{passive:true});
   setInterval(()=>{if(!document.hidden)recover()},1500);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromPlaygroundRuntime={version:'72.21',check:()=>({screen:state?.screen,mode:state?.mode,players:state?.players,turn:state?.turn,running:!!state?.running,gameOver:!!state?.gameOver,pieces:Array.isArray(window.pieces)?window.pieces.length:0,striker:!!window.striker,healthy:stateHealthy()})};
})();
