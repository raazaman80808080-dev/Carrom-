/* V72 Phase 5 — Playable Core + Match UX. Additive, defensive, offline-first. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 let raf=0,last=0,acc=0;
 const STEP=16.6667;
 function frame(now){
   if(!last) last=now;
   let elapsed=Math.min(80,Math.max(0,now-last)); last=now;
   if(typeof state!=='undefined' && state.screen==='game' && state.running && !document.hidden){
     acc+=elapsed;
     let guard=0;
     while(acc>=STEP && guard++<4){ if(typeof fixedStep==='function') fixedStep(STEP/16.6667); acc-=STEP; }
     if(typeof draw==='function') draw();
   } else acc=Math.min(acc,STEP);
   raf=requestAnimationFrame(frame);
 }
 raf=requestAnimationFrame(frame);

 // Make the game immediately understandable on touch + keyboard.
 function hint(){
   const h=$('#shotHint'); if(!h)return;
   if(typeof state!=='undefined' && state.screen==='game' && state.running && !state.gameOver){
     h.textContent=(state.players===2&&state.turn===1)?'CPU IS AIMING…':'DRAG FROM STRIKER · RELEASE TO SHOOT';
   }
 }
 setInterval(hint,450);
 document.addEventListener('keydown',e=>{
   if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return;
   if(e.key==='Escape'){ e.preventDefault(); if(typeof closeModal==='function')closeModal(); else if(typeof show==='function')show('home'); return; }
   if(state.running && !moving()){
     if(e.key==='ArrowLeft'){e.preventDefault(); if(typeof nudge==='function')nudge(-1)}
     if(e.key==='ArrowRight'){e.preventDefault(); if(typeof nudge==='function')nudge(1)}
     if(e.key==='ArrowUp'){e.preventDefault(); state.power=Math.min(100,(state.power||55)+5); const r=$('#powerRange');if(r)r.value=state.power; if(typeof draw==='function')draw()}
     if(e.key==='ArrowDown'){e.preventDefault(); state.power=Math.max(10,(state.power||55)-5); const r=$('#powerRange');if(r)r.value=state.power; if(typeof draw==='function')draw()}
     if(e.key.toLowerCase()==='p' && typeof tool==='function')tool('pause');
   }
 });

 // Keep accidental double-submit / stale AI timers from producing impossible shots.
 const originalStart=window.startGame, originalReset=window.resetGame;
 if(typeof originalStart==='function'){
   window.startGame=function(mode,players){
     try{sessionStorage.removeItem('carrom_active_match')}catch(_){ }
     return originalStart.apply(this,arguments);
   };
 }
 if(typeof originalReset==='function'){
   window.resetGame=function(){ const r=originalReset.apply(this,arguments); if(typeof draw==='function')draw(); return r; };
 }

 // Small in-game status panel; no feature replacement.
 function install(){
   const game=$('#game'); if(!game||$('#playableAssist'))return;
   const panel=document.createElement('div'); panel.id='playableAssist'; panel.className='playable-assist';
   panel.innerHTML='<span class="assist-live"><i></i> LIVE PHYSICS</span><span>← → STRIKER</span><span>↑ ↓ POWER</span><span>P PAUSE</span>';
   game.appendChild(panel);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 window.CarromPlayableCore={version:'72.5',step:'fixed-60hz',running:true};
})();
