/* Carrom Ultra Pro Max V56.0 — Apex Game Feel / UI polish layer. */
(()=>{
'use strict';
const q=s=>document.querySelector(s), qa=s=>[...document.querySelectorAll(s)];
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
function vibrate(ms=8){try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(e){}}
function mount(){
 if(document.getElementById('v56Apex'))return;
 const root=document.body; root.id=root.id||'appRoot'; root.classList.add('v56-apex');
 const chip=q('.product-chip'); if(chip){chip.textContent='V56.0 APEX';chip.title='V56.0 Apex Game Feel';}
 const top=q('.top');
 if(top){const status=document.createElement('div');status.id='v56Apex';status.className='v56-apex-status';status.innerHTML='<i></i><span id="v56NetText">LOCAL CORE</span><b id="v56Perf">APEX</b>';top.appendChild(status)}
 // Smooth screen transitions without changing navigation semantics.
 qa('.nav').forEach(btn=>btn.addEventListener('click',()=>{if(reduced())return;root.classList.remove('v56-screen-pulse');void root.offsetWidth;root.classList.add('v56-screen-pulse');vibrate(6)},{passive:true}));
 // Premium press feedback + haptics, delegated to avoid duplicate listeners.
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,[role="button"],.nav');if(!b)return;b.classList.add('v56-press');vibrate(5)},{passive:true});
 ['pointerup','pointercancel','pointerleave'].forEach(ev=>root.addEventListener(ev,e=>{const b=e.target.closest('button,[role="button"],.nav');if(b)b.classList.remove('v56-press')},{passive:true}));
 // Keyboard accessibility for common interactive cards.
 qa('[role="button"]').forEach(el=>{if(el.dataset.v56Key)return;el.dataset.v56Key='1';el.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&!e.defaultPrevented){e.preventDefault();el.click()}})});
 // Escape closes product modals where the existing close action is available.
 addEventListener('keydown',e=>{if(e.key==='Escape'){const m=q('.modal.show')||q('.modal:not([hidden])');const c=m?.querySelector('.close');if(c)c.click()}},{passive:true});
 // Online state is explicit; do not pretend remote authority exists.
 const sync=()=>{const on=navigator.onLine!==false;const text=q('#v56NetText'),s=q('#v56Apex');if(text)text.textContent=on?'ONLINE READY':'LOCAL CORE';if(s)s.dataset.online=on?'1':'0'};addEventListener('online',sync);addEventListener('offline',sync);sync();
 // Lightweight performance meter that pauses while hidden.
 let frames=0,last=performance.now(),active=true;document.addEventListener('visibilitychange',()=>{active=!document.hidden});
 const loop=now=>{if(active){frames++;if(now-last>=1000){const fps=Math.round(frames*1000/(now-last));const el=q('#v56Perf');if(el)el.textContent=(fps>=55?'APEX':fps>=45?'SMOOTH':'POWER')+' · '+Math.max(1,Math.min(120,fps))+' FPS';frames=0;last=now}}else{last=now;frames=0}requestAnimationFrame(loop)};requestAnimationFrame(loop);
 // Add a subtle focus ring class only after keyboard navigation.
 let keyboard=false;addEventListener('keydown',e=>{if(e.key==='Tab')keyboard=true},{passive:true});addEventListener('pointerdown',()=>keyboard=false,{passive:true});addEventListener('focusin',e=>{if(keyboard)e.target.classList?.add('v56-key-focus')},{passive:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
