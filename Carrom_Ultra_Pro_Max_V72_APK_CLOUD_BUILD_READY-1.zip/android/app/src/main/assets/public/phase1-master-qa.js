const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname;
const fail=[]; const ok=[];
function assert(c,m){(c?ok:fail).push(m)}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
assert(manifest.version==='72.0.0','manifest version 72.0.0');
assert(pkg.version==='72.0.0','package version 72.0.0');
assert(pkg.main==='server/server.js','package main points to server');
assert(pkg.scripts?.start==='node server/server.js','start script points to server');
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(x=>x[1]);
const dup=[...new Set(ids.filter((x,i)=>ids.indexOf(x)!==i))]; assert(!dup.length,'duplicate DOM IDs absent');
const scripts=[...html.matchAll(/<script[^>]+src=["']([^"']+)["']/gi)].map(x=>x[1]);
const styles=[...html.matchAll(/<link[^>]+href=["']([^"']+)["']/gi)].map(x=>x[1]).filter(x=>x.endsWith('.css'));
for(const f of [...scripts,...styles,'manifest.json']) assert(fs.existsSync(path.join(root,f)),`asset exists: ${f}`);
for(const f of scripts.filter(x=>x.endsWith('.js'))){try{cp.execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'ignore'});assert(true,`JS syntax: ${f}`)}catch(e){assert(false,`JS syntax: ${f}`)}}
for(const f of ['server/server.js','server/repository.js','server/physics.js']){try{cp.execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'ignore'});assert(true,`server syntax: ${f}`)}catch(e){assert(false,`server syntax: ${f}`)}}
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
assert(sw.includes('carrom-product-v72-1-phase1'),'service worker cache version');
for(const f of scripts.filter(x=>x.endsWith('.js'))) assert(sw.includes('./'+f),`SW caches: ${f}`);
for(const f of styles) assert(sw.includes('./'+f),`SW caches: ${f}`);
const buttons=[...html.matchAll(/<button\b/gi)].length; const inputs=[...html.matchAll(/<input\b/gi)].length;
assert(buttons>0,`interactive buttons discovered (${buttons})`); assert(inputs>0,`inputs discovered (${inputs})`);
console.log(`PHASE1 MASTER QA ${fail.length?'FAIL':'PASS'}`);
console.log(`- JS entry scripts: ${scripts.filter(x=>x.endsWith('.js')).length}`);
console.log(`- CSS entry styles: ${styles.length}`);
console.log(`- DOM ids: ${ids.length} unique`);
console.log(`- buttons: ${buttons}, inputs: ${inputs}`);
console.log(`- checks passed: ${ok.length}, failed: ${fail.length}`);
if(fail.length){for(const x of fail) console.error('FAIL:',x);process.exit(1)}
