const fs=require('fs'),path=require('path');
const root=__dirname;
const files=[];(function walk(d){for(const n of fs.readdirSync(d)){if(['node_modules','.git'].includes(n))continue;const p=path.join(d,n),st=fs.statSync(p);if(st.isDirectory())walk(p);else if(/\.js$/.test(n))files.push(p)}})(root);
for(const f of files){require('child_process').execFileSync(process.execPath,['--check',f],{stdio:'ignore'})}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/id=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
if(dup.length)throw Error('duplicate DOM IDs: '+[...new Set(dup)].join(','));
if(manifest.version!=='68.0.0')throw Error('manifest version mismatch');
if(!html.includes('v67-upgrade.js')||!html.includes('v68-upgrade.js'))throw Error('upgrade chain missing');
if(!fs.existsSync(path.join(root,'v68-upgrade.js')))throw Error('v68 upgrade missing');
console.log('V68.0 QA PASS');
console.log('source files:',files.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs: NONE');console.log('manifest:',manifest.version);console.log('V67→V68 UI upgrade chain: PASS');
