/* V72 Phase 3 — production performance guard. Non-destructive/additive. */
(() => {
  'use strict';
  const root = document.documentElement;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  const lowPower = !!(connection && (connection.saveData || /2g/.test(connection.effectiveType || '')));

  root.dataset.v72Performance = lowPower ? 'conservative' : 'high';
  if (reduced.matches) root.dataset.v72Motion = 'reduced';

  const decodeImages = () => {
    const images = document.images;
    for (const img of images) {
      if (!img.complete && typeof img.decode === 'function') img.decode().catch(() => {});
    }
  };

  const idle = window.requestIdleCallback || ((cb) => setTimeout(cb, 1));
  idle(decodeImages);

  // Keep expensive visual work paused when the tab is hidden.
  document.addEventListener('visibilitychange', () => {
    root.dataset.v72Visibility = document.hidden ? 'hidden' : 'visible';
  }, { passive: true });

  // Avoid accidental double-init if the script is ever injected twice.
  if (window.__V72_PHASE3__) return;
  window.__V72_PHASE3__ = Object.freeze({
    version: '72.3.0',
    reducedMotion: () => reduced.matches,
    lowPower
  });
})();
