/* Carrom Ultra Pro Max V57.0 — Premium Visual Engine 2.0 / Match Presentation / Mobile polish. */
(()=>{
'use strict';
const q=s=>document.querySelector(s), qa=s=>[...document.querySelectorAll(s)];
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const vibrate=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(e){}};
function toast(msg){const t=q('#toast');if(!t)return;t.textContent=msg;t.classList.add('show','v57-toast');clearTimeout(window.__v57toast);window.__v57toast=setTimeout(()=>t.classList.remove('show','v57-toast'),1900)}
function mount(){
 if(document.getElementById('v57Engine'))return;
 const root=document.body; root.id=root.id||'appRoot'; root.classList.add('v57-engine');
 const chip=q('.product-chip'); if(chip){chip.textContent='V57.0 ULTRA';chip.title='V57.0 Premium Visual Engine 2.0'}
 // Premium top rail: presentation state only; never claims remote authority.
 const top=q('.top');
 if(top){const rail=document.createElement('div');rail.id='v57Engine';rail.className='v57-rail';rail.innerHTML='<i></i><b>VISUAL ENGINE 2.0</b><span id="v57RailState">READY</span>';top.appendChild(rail)}
 // Board presentation layer: subtle framing + live turn pulse.
 const board=q('#board'); const wrap=board?.closest('.board-wrap'); if(wrap){wrap.classList.add('v57-board-stage');const badge=document.createElement('div');badge.className='v57-board-badge';badge.innerHTML='<span>LIVE BOARD</span><b id="v57BoardMode">CLASSIC</b>';wrap.appendChild(badge)}
 const sync=()=>{const online=navigator.onLine!==false;const s=q('#v57RailState');if(s)s.textContent=online?'ONLINE READY':'LOCAL CORE';const rail=q('#v57Engine');if(rail)rail.dataset.online=online?'1':'0';};addEventListener('online',sync);addEventListener('offline',sync);sync();
 // Score/turn presentation updates without modifying game authority.
 const update=()=>{const title=q('#gameTitle'),mode=q('#modeBadge'),bm=q('#v57BoardMode');if(bm)bm.textContent=(mode?.textContent||title?.textContent||'CLASSIC').trim().slice(0,18);const turn=q('#turnName'),status=q('#hudStatus');root.classList.toggle('v57-your-turn',/your turn|aim ready/i.test((turn?.textContent||'')+' '+(status?.textContent||'')));};
 const mo=new MutationObserver(update);[q('#turnName'),q('#hudStatus'),q('#gameTitle'),q('#modeBadge'),q('#gameScore')].filter(Boolean).forEach(el=>mo.observe(el,{subtree:true,childList:true,characterData:true}));update();
 // Match intro/outro: triggered by real screen changes only.
 const screens=qa('.screen');const screenObs=new MutationObserver(()=>{const active=q('.screen.active');if(!active)return;root.classList.remove('v57-screen-enter');if(reduced())return;void root.offsetWidth;root.classList.add('v57-screen-enter');});screens.forEach(s=>screenObs.observe(s,{attributes:true,attributeFilter:['class']}));
 // Reward/achievement celebration hooks based on existing toast/confetti surface.
 const conf=q('#confetti'); if(conf){const confObs=new MutationObserver(m=>{if(m.some(x=>x.addedNodes?.length)){root.classList.add('v57-celebrate');vibrate(12);setTimeout(()=>root.classList.remove('v57-celebrate'),700)}});confObs.observe(conf,{childList:true,subtree:true});}
 // Loading skeleton state: only during initial paint and removed after first stable frame.
 root.classList.add('v57-boot');requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.remove('v57-boot')));
 // Notification polish: existing toast gets a premium entrance; no new fake notifications.
 const t=q('#toast');if(t){new MutationObserver(()=>{if((t.textContent||'').trim()){t.classList.remove('v57-toast-pop');void t.offsetWidth;t.classList.add('v57-toast-pop')}}).observe(t,{childList:true,characterData:true,subtree:true});}
 // Touch affordance for horizontal scrollers; prevent accidental page drag only inside known strips.
 qa('.fc-tabs,.fc-filters,.shop-menu,.language-grid').forEach(el=>el.addEventListener('wheel',e=>{if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){el.scrollLeft+=e.deltaY;e.preventDefault()}},{passive:false}));
 // Precision touch feedback.
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system');if(!b)return;b.classList.add('v57-touch');vibrate(4)},{passive:true});
 ['pointerup','pointercancel'].forEach(ev=>root.addEventListener(ev,e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system');if(b)b.classList.remove('v57-touch')},{passive:true}));
 // Low-power adaptation for mobile/hidden pages.
 let timer;const settle=()=>{clearTimeout(timer);timer=setTimeout(()=>root.classList.add('v57-idle'),1800)};['pointerdown','keydown','touchstart'].forEach(ev=>addEventListener(ev,()=>{root.classList.remove('v57-idle');settle()},{passive:true}));settle();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
