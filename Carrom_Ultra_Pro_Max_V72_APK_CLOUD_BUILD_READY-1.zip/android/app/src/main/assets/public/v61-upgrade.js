/* Carrom Ultra Pro Max V61.0 — Ultra Cinematic Match Finish / Competitive Presentation 5.0 / Sharpness. */
(()=>{
'use strict';
const $=s=>document.querySelector(s), root=document.body;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const haptic=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(_) {}};
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
let mounted=false, prev={shot:'',pocket:'',foul:'',queen:'',score:'',status:'',turn:''};
function pulse(k,d=700){if(reduced())return;root.classList.remove('v61-'+k);void root.offsetWidth;root.classList.add('v61-'+k);clearTimeout(root.__v61pulse);root.__v61pulse=setTimeout(()=>root.classList.remove('v61-'+k),d)}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show','v61-toast');clearTimeout(window.__v61toast);window.__v61toast=setTimeout(()=>t.classList.remove('show','v61-toast'),1900)}
function burst(label,kind='impact'){
 const wrap=$('.board-wrap');if(!wrap)return;
 const e=document.createElement('div');e.className='v61-burst '+kind;e.textContent=label;e.setAttribute('aria-hidden','true');wrap.appendChild(e);
 requestAnimationFrame(()=>e.classList.add('show'));setTimeout(()=>e.remove(),1100);
}
function setFinish(title,sub){const o=$('#v61Finish');if(!o)return;o.querySelector('b').textContent=title;o.querySelector('span').textContent=sub;o.classList.remove('show');void o.offsetWidth;o.classList.add('show');setTimeout(()=>o.classList.remove('show'),1800)}
function mount(){
 if(mounted)return;mounted=true;root.classList.add('v61-engine');
 const top=$('.top');if(top&&!$('#v61Rail')){const r=document.createElement('div');r.id='v61Rail';r.className='v61-rail';r.innerHTML='<i></i><b>ULTRA CINEMATIC 5.0</b><span>GAME FINISH</span>';top.appendChild(r)}
 const wrap=$('.board-wrap');
 if(wrap&&!$('#v61Finish')){const o=document.createElement('div');o.id='v61Finish';o.className='v61-finish';o.setAttribute('aria-hidden','true');o.innerHTML='<b>PERFECT SHOT</b><span>PRECISION LOCK</span>';wrap.appendChild(o);wrap.addEventListener('pointerdown',()=>{pulse('board-press',220);haptic(3)},{passive:true})}
 const hud=$('.pro-hud');if(hud&&!$('#v61Streak')){const s=document.createElement('div');s.id='v61Streak';s.className='v61-streak';s.innerHTML='<span>STREAK</span><b>0</b>';hud.appendChild(s)}
 let streak=0;
 const sync=()=>{
  const now={shot:($('#shotCountHUD')?.textContent||'').trim(),pocket:($('#pocketHUD')?.textContent||'').trim(),foul:($('#foulHUD')?.textContent||'').trim(),queen:($('#queenStatus')?.textContent||'').trim(),score:($('#gameScore')?.textContent||'').trim(),status:($('#hudStatus')?.textContent||'').trim(),turn:($('#turnName')?.textContent||'').trim()};
  if(now.shot&&prev.shot&&now.shot!==prev.shot){pulse('shot',360);haptic(4);}
  if(now.pocket!==prev.pocket&&prev.pocket!==''&&now.pocket!=='0'){streak++;if($('#v61Streak'))$('#v61Streak b').textContent=String(streak);pulse('pocket',620);burst(streak>1?'POCKET STREAK ×'+streak:'POCKET +1','pocket');haptic(streak>1?[10,28,10]:12)}
  if(now.foul!==prev.foul&&prev.foul!==''&&now.foul!=='0'){streak=0;if($('#v61Streak'))$('#v61Streak b').textContent='0';pulse('foul',520);burst('FOUL','foul');haptic([12,35,12])}
  if(now.queen!==prev.queen&&prev.queen&&/queen/i.test(now.queen)){pulse('queen',820);burst('QUEEN','queen');haptic([8,25,8,25,12]);setFinish('QUEEN PLAY','PRECISION CONTROL')}
  if(now.score&&prev.score&&now.score!==prev.score){pulse('score',480)}
  if(now.turn&&prev.turn&&now.turn!==prev.turn&&/your/i.test(now.turn)){pulse('your-turn',430);haptic(7)}
  prev=now;
 };
 ['#shotCountHUD','#pocketHUD','#foulHUD','#queenStatus','#gameScore','#hudStatus','#turnName','#turnTimer'].forEach(sel=>{const e=$(sel);if(e)new MutationObserver(sync).observe(e,{subtree:true,childList:true,characterData:true,attributes:true})});sync();
 const modal=$('#modal');if(modal)new MutationObserver(()=>{
   if(!modal.classList.contains('show'))return;const c=$('#modalContent');if(!c)return;const text=c.textContent||'';
   if(!/YOU WIN|MATCH DRAW|MATCH COMPLETE|VICTORY|DEFEAT/i.test(text))return;
   const type=/YOU WIN|VICTORY/i.test(text)?'win':/DRAW/i.test(text)?'draw':'complete';
   modal.classList.remove('v61-win','v61-draw','v61-complete');modal.classList.add('v61-'+type);pulse('finish',900);haptic(type==='win'?[18,45,18]:12);
   if(type==='win')setFinish('VICTORY','MATCH COMPLETE');
   else if(type==='draw')setFinish('DRAW','MATCH COMPLETE');
   setTimeout(()=>modal.classList.remove('v61-win','v61-draw','v61-complete'),4200);
 }).observe(modal,{subtree:true,childList:true,attributes:true});
 // Precision press/focus without changing gameplay.
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.add('v61-press')},{passive:true});
 ['pointerup','pointercancel','pointerleave'].forEach(ev=>root.addEventListener(ev,e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.remove('v61-press')},{passive:true}));
 document.addEventListener('keydown',e=>{if(e.key==='Enter'&&document.activeElement?.matches('button,.nav'))pulse('key',240)},{passive:true});
 document.addEventListener('visibilitychange',()=>root.classList.toggle('v61-hidden',document.hidden));
 const board=$('#board');if(board){board.setAttribute('data-v61-sharp','true');board.style.imageRendering='auto';board.style.transform='translateZ(0)';}
 root.classList.add('v61-boot');requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.remove('v61-boot')));
 try{if(localStorage.getItem('carrom_v61_intro')!=='1'){localStorage.setItem('carrom_v61_intro','1');setTimeout(()=>toast('✦ V61 Cinematic Finish ready'),950)}}catch(_){}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
window.CarromV61={version:'61.0.0',presentation:'ultra-cinematic-match-finish-5'};
})();
