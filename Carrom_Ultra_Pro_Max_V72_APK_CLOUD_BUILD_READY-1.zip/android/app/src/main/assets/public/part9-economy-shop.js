(()=>{'use strict';
const $=s=>document.querySelector(s); const $$=s=>Array.from(document.querySelectorAll(s));
function money(){return {coins:Math.max(0,Number((window.state?.coins ?? document.querySelector('#coins')?.textContent?.replace(/,/g,'') ?? 0))),gems:Math.max(0,Number((window.state?.gems ?? document.querySelector('#gems')?.textContent?.replace(/,/g,'') ?? 0)))}}
function decorate(){const shop=document.querySelector('#shop'); if(!shop||shop.dataset.part9)return; shop.dataset.part9='1';
 const menu=shop.querySelector('.shop-menu'); if(menu){menu.setAttribute('role','tablist'); menu.querySelectorAll('button').forEach((b,i)=>{b.setAttribute('role','tab');b.setAttribute('aria-selected',String(b.classList.contains('active')));b.addEventListener('click',()=>{menu.querySelectorAll('button').forEach(x=>x.setAttribute('aria-selected',String(x===b)))})})}
 const content=$('#shopContent'); if(content){const head=document.createElement('div');head.className='p9-shop-toolbar';head.innerHTML='<div><span class="p9-eyebrow">ECONOMY CONTROL · V72</span><strong>SHOP • LOADOUT • VALUE</strong></div><div class="p9-wallet"><span>🪙 <b id="p9Coins">0</b></span><span>💎 <b id="p9Gems">0</b></span></div>';content.parentNode.insertBefore(head,content);}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-shopbuy]');if(!b)return; setTimeout(()=>{refresh();pulse(b)},30)});
 refresh();
}
function refresh(){const m=money();const c=$('#p9Coins'),g=$('#p9Gems');if(c)c.textContent=m.coins.toLocaleString();if(g)g.textContent=m.gems.toLocaleString();
 const top=$('#coins'),tg=$('#gems');[top,tg].forEach(x=>{if(x)x.closest('.money')?.classList.add('p9-wallet-live')});
 $$('#shopContent [data-shopbuy]').forEach(b=>{b.classList.add('p9-shop-item');b.setAttribute('aria-label',b.innerText.replace(/\s+/g,' ').trim());});
}
function pulse(b){b.classList.remove('p9-purchased');void b.offsetWidth;b.classList.add('p9-purchased');setTimeout(()=>b.classList.remove('p9-purchased'),500)}
function observe(){const shop=$('#shop');if(!shop)return;const mo=new MutationObserver(()=>{refresh();$$('#shopContent [data-shopbuy]').forEach(b=>b.classList.add('p9-shop-item'))});mo.observe(shop,{subtree:true,childList:true});}
function init(){decorate();observe(); window.addEventListener('storage',refresh); document.addEventListener('visibilitychange',refresh); window.CarromPart9Economy={refresh};}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
