/* Carrom Ultra Pro Max V56.0 — Cinematic UI / Game Feel / HUD 2.0 layer. */
(()=>{
'use strict';
const q=s=>document.querySelector(s), qa=s=>[...document.querySelectorAll(s)];
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const settings={sound:()=>localStorage.getItem('cup_setting_sound')!=='off',vib:()=>localStorage.getItem('cup_setting_vibration')!=='off',shake:()=>localStorage.getItem('cup_setting_shake')!=='off'};
let audioCtx=null;
function tone(freq=520,dur=.045,type='sine',gain=.018){if(!settings.sound())return;try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(gain,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+dur);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+dur)}catch(e){}}
function vibrate(ms=7){try{if(settings.vib()&&navigator.vibrate)navigator.vibrate(ms)}catch(e){}}
function pulse(){const r=document.body;if(reduced()||!settings.shake())return;r.classList.remove('v56-impact');void r.offsetWidth;r.classList.add('v56-impact');setTimeout(()=>r.classList.remove('v56-impact'),260)}
function mount(){
 if(document.getElementById('v56Cinematic'))return;
 const root=document.body;root.classList.add('v56-cinematic');
 // Cinematic status rail
 const top=q('.top');if(top){const el=document.createElement('div');el.id='v56Cinematic';el.className='v56-cine-status';el.innerHTML='<span class="v56-dot"></span><b>ULTRA CORE</b><em id="v56Mode">READY</em>';top.appendChild(el)}
 // Global toast-like transition flash; does not alter navigation behavior.
 qa('.nav, [data-action], [data-queue], [data-event], [data-social], [data-graphics]').forEach(el=>{el.addEventListener('click',()=>{tone(620,.035,'triangle',.012);vibrate(5)}, {passive:true})});
 // Game action feedback and cinematic impact.
 ['#undo','#reset','#gameRules','#leftNudge','#rightNudge'].forEach(sel=>q(sel)?.addEventListener('click',()=>{tone(390,.05,'square',.014);vibrate(8)}));
 q('#powerRange')?.addEventListener('input',()=>{tone(260+Number(q('#powerRange').value)*2,.018,'sine',.008)});
 // Dynamic match HUD status, keeping existing IDs intact.
 const sync=()=>{const online=navigator.onLine!==false;const mode=q('#v56Mode');if(mode)mode.textContent=online?'ONLINE READY':'LOCAL CORE';const live=q('#liveNet');if(live&&!live.textContent.includes('SERVER'))live.textContent=online?'ONLINE READY':'LOCAL CORE'};
 addEventListener('online',sync);addEventListener('offline',sync);sync();
 // HUD 2.0: derive lightweight shot telemetry from existing visible values.
 const updateHUD=()=>{const power=q('#powerRange'),hud=q('#powerHUD');if(power&&hud)hud.textContent=Number(power.value)+'%';const msg=q('#gameMessage');const hs=q('#hudStatus');if(hs&&msg){const t=msg.textContent||'';hs.textContent=/your turn|aim/i.test(t)?'AIM READY':'READY'}};q('#powerRange')?.addEventListener('input',updateHUD);setInterval(updateHUD,900);
 // Sound/haptic hooks for successful-looking game events without faking authority.
 const observer=new MutationObserver(muts=>{for(const m of muts){if(m.type==='characterData'||m.type==='childList'){const t=(m.target?.textContent||'').toLowerCase();if(/pocket|queen|foul|goal|win|success/.test(t)){tone(740,.07,'sine',.02);vibrate(10);pulse();break}}}});
 const gm=q('#gameMessage');if(gm)observer.observe(gm,{subtree:true,childList:true,characterData:true});
 // First interaction unlocks WebAudio on mobile browsers.
 const unlock=()=>{try{if(audioCtx?.state==='suspended')audioCtx.resume()}catch(e){}};addEventListener('pointerdown',unlock,{once:true,passive:true});
 // Loading polish: show a tiny ready state after app paints.
 requestAnimationFrame(()=>{root.classList.add('v56-ready');setTimeout(()=>root.classList.add('v56-settled'),450)});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
