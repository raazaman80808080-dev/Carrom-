/* V72 Phase 4 — interaction polish. Defensive + additive. */
(()=>{
 'use strict';
 const reduce=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
 document.addEventListener('pointerdown',e=>{
   const b=e.target.closest('button,[role="button"]'); if(!b||b.disabled||reduce()) return;
   const r=b.getBoundingClientRect(), s=Math.max(r.width,r.height)*.08;
   const x=e.clientX-r.left, y=e.clientY-r.top;
   const dot=document.createElement('i'); dot.className='u4-ripple'; dot.style.left=x+'px'; dot.style.top=y+'px'; dot.style.width=s+'px'; dot.style.height=s+'px';
   b.appendChild(dot); dot.addEventListener('animationend',()=>dot.remove(),{once:true});
 },{passive:true});
 const markScreen=()=>{const active=document.querySelector('.screen.active'); if(active&&!reduce()){active.classList.remove('u4-screen-enter'); requestAnimationFrame(()=>active.classList.add('u4-screen-enter'));}};
 document.addEventListener('click',e=>{if(e.target.closest('[data-go],[data-game],.nav')) setTimeout(markScreen,0);},{passive:true});
 const setSafe=(el,k,v)=>{try{el.dataset[k]=v}catch(_){}};
 document.addEventListener('pointerover',e=>{const card=e.target.closest('.dash-panel,.sys-card,.panel,.global-panel'); if(card) setSafe(card,'u4Hover','1')},{passive:true});
 document.addEventListener('pointerout',e=>{const card=e.target.closest('.dash-panel,.sys-card,.panel,.global-panel'); if(card) setSafe(card,'u4Hover','0')},{passive:true});
 window.CarromUltraUI4={version:'72.4',reducedMotion:reduce};
})();
