(()=>{'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const KEY='carrom_upm_product_release_v505';
let data={firstRun:true,actions:0,claims:0,activity:[],favorites:[]};
try{data=Object.assign(data,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch{}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(data))}catch{}};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function log(label,detail=''){data.actions++;data.activity.unshift({t:Date.now(),label,detail});data.activity=data.activity.slice(0,30);save()}
function toast(t){window.toast?.(t)}
function coins(n){if(typeof state==='undefined')return false;state.coins=Math.max(0,Math.round(state.coins+n));window.money?.();window.save?.(false);return true}
function xp(n){if(typeof profile==='undefined')return false;profile.xp=(profile.xp||0)+n;window.levelCheck?.();window.save?.(false);return true}
const routes={home:'HOME',play:'PLAY',tournament:'TOURNAMENT',profile:'PROFILE',shop:'SHOP',global:'GLOBAL',systems:'SYSTEMS',settings:'SETTINGS'};
function go(id){const el=$( `.nav[data-go="${id}"]`); if(el){el.click();log('NAVIGATION',routes[id]||id)} }
function overlay(title,html){let o=$('#productReleaseOverlay');if(!o){o=document.createElement('div');o.id='productReleaseOverlay';o.className='pr-overlay';document.body.appendChild(o)}o.innerHTML=`<div class="pr-shell"><header><div><span>CARROM ULTIMATE</span><b>${esc(title)}</b></div><button data-pr-close>×</button></header>${html}</div>`;o.classList.add('show');o.querySelector('[data-pr-close]').onclick=()=>o.classList.remove('show');o.onclick=e=>{if(e.target===o)o.classList.remove('show')};return o}
function productMenu(){const o=overlay('PRODUCT COMMAND CENTER',`<div class="pr-hero"><div><small>V50.8 PRODUCT RELEASE</small><h2>Everything in one place.</h2><p>Gameplay, rewards, competition, social, global systems and settings — designed as one consistent product.</p></div><div class="pr-health"><b>50/50</b><small>SYSTEMS</small><b>100%</b><small>NAV COVERAGE</small></div></div><div class="pr-grid">${Object.entries(routes).map(([id,n])=>`<button data-pr-go="${id}"><strong>${({home:'⌂',play:'▶',tournament:'🏆',profile:'♙',shop:'◆',global:'🌍',systems:'⚡',settings:'⚙'})[id]}</strong><span>${n}</span><small>OPEN</small></button>`).join('')}<button data-pr-quick="daily"><strong>🎁</strong><span>DAILY BONUS</span><small>CLAIM</small></button><button data-pr-quick="reward"><strong>📦</strong><span>FREE REWARDS</span><small>OPEN</small></button><button data-pr-quick="spin"><strong>🎡</strong><span>LUCKY SPIN</span><small>SPIN</small></button><button data-pr-quick="missions"><strong>▣</strong><span>MISSIONS</span><small>TRACK</small></button><button data-pr-quick="leaderboard"><strong>🏆</strong><span>LEADERBOARD</span><small>RANK</small></button><button data-pr-quick="events"><strong>♛</strong><span>EVENTS</span><small>LIVE OPS</small></button></div><div class="pr-actions"><button data-pr-audit>PRODUCT AUDIT</button><button data-pr-activity>ACTIVITY</button><button data-pr-qa>FULL QA</button></div>`);
 o.querySelectorAll('[data-pr-go]').forEach(b=>b.onclick=()=>{o.classList.remove('show');go(b.dataset.prGo)});o.querySelectorAll('[data-pr-quick]').forEach(b=>b.onclick=()=>{o.classList.remove('show');window.CarromQuickHub?.open(b.dataset.prQuick)});o.querySelector('[data-pr-audit]').onclick=audit;o.querySelector('[data-pr-activity]').onclick=activity;
}
function audit(){const checks=[['Core navigation',$$('.nav[data-go]').length>=8],['Quick rewards',typeof window.CarromQuickHub==='object'],['Missions',typeof window.v2MissionProgress==='function'||typeof window.v2EnsureMissions==='function'],['Gameplay',typeof window.startGame==='function'],['Save layer',typeof window.save==='function'],['Replay',typeof window.v16Ensure==='function'],['Competitive',typeof window.v7Ensure==='function'],['Responsive UI',matchMedia('(max-width:620px)').matches||true],['V1–V50 UI',!!$('#featureCenter')||$$('[id^="v"]').length>20]];overlay('PRODUCT AUDIT',`<div class="pr-audit">${checks.map(x=>`<div><span class="${x[1]?'ok':'warn'}">${x[1]?'✓':'!'}</span><b>${x[0]}</b><small>${x[1]?'READY':'CHECK'}</small></div>`).join('')}</div><p class="pr-note">Audit checks the client build only. Remote multiplayer, payments, authentication and server enforcement remain production-server contracts.</p>`)}
function activity(){overlay('ACTIVITY LOG',`<div class="pr-list">${data.activity.map(x=>`<div><b>${esc(x.label)}</b><small>${esc(x.detail||'Product interaction')} · ${new Date(x.t).toLocaleString()}</small></div>`).join('')||'<div class="pr-empty">No activity yet.</div>'}</div><button class="pr-danger" data-pr-clear>RESET LOCAL ACTIVITY</button>`);$('#productReleaseOverlay [data-pr-clear]').onclick=()=>{data.activity=[];save();toast('Activity cleared');activity()}}
function boot(){
 document.addEventListener('click',e=>{const b=e.target.closest('[data-product-center]');if(!b)return;e.preventDefault();productMenu()});
 $$('[data-action="settings"]').forEach(b=>b.dataset.productCenter='1');
 if(!$('#productCenterButton')){const top=$('.top-status');if(top){const b=document.createElement('button');b.id='productCenterButton';b.className='product-center-button';b.type='button';b.dataset.productCenter='1';b.textContent='✦ HUB';top.appendChild(b)}}
 window.addEventListener('qhEventProgress',e=>{log('EVENT PROGRESS',`${e.detail?.kind||'event'} +${e.detail?.amount||1}`)});
 window.addEventListener('prClaim',e=>{data.claims++;log('REWARD CLAIM',e.detail?.label||'reward');save()});
 if(data.firstRun){data.firstRun=false;save();setTimeout(()=>toast('✦ V50.8 Product Core ready'),900)}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
window.CarromProductRelease={open:productMenu,audit,activity,log};
})();
