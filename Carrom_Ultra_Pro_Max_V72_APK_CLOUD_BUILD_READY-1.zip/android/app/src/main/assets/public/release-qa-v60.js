const fs=require('fs'),path=require('path'),html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8');
const js=fs.readFileSync(path.join(__dirname,'v60-upgrade.js'),'utf8');
function assert(x,m){if(!x)throw new Error(m)}
assert(/v59-upgrade\.js/.test(html)&&/v60-upgrade\.js/.test(html),'upgrade chain');
assert(/V60\.0 READY/.test(html)&&/PRODUCT V60\.0/.test(html),'version ui');
assert(JSON.parse(fs.readFileSync(path.join(__dirname,'manifest.json'),'utf8')).version==='60.0.0','manifest');
assert(/CarromV60/.test(js)&&/trajectory/.test(js)&&/v60Perf/.test(js),'V60 features');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]); const dup=ids.filter((x,i)=>ids.indexOf(x)!==i); assert(!dup.length,'duplicate IDs: '+[...new Set(dup)].join(','));
console.log('V60.0 QA PASS'); console.log('duplicate DOM IDs:',dup.length?'FAIL':'NONE'); console.log('V59/V60 upgrade chain: PASS'); console.log('V60 features: PASS');
