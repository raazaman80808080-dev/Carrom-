/* V72 Phase 15 — Runtime Match Reliability + Playable UX. Additive only. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 const qsa=s=>Array.from(document.querySelectorAll(s));
 const now=()=>performance.now();
 let lastFrame=now(), lastScreen='';
 function isGame(){return typeof state!=='undefined'&&state.screen==='game';}
 function hasMatch(){return isGame()&&typeof pieces!=='undefined'&&Array.isArray(pieces)&&pieces.length>0&&typeof striker!=='undefined'&&!!striker;}
 function human(){return isGame()&&!state.gameOver&&state.running&&!(state.players===2&&state.turn!==0)&&!state.aiBusy&&(typeof moving!=='function'||!moving());}
 function safeStart(mode='classic',players=2){
   if(typeof window.startGame==='function'){window.startGame(mode,players);return true}
   return false;
 }
 function ensureMatch(){
   if(!isGame())return;
   // If the Game screen was opened directly, initialize a real board instead of leaving an empty arena.
   if(!hasMatch()&&!state.gameOver&&typeof window.resetGame==='function'){
     window.resetGame();
     if(typeof updateHUD==='function')updateHUD();
     if(typeof draw==='function')draw();
   }
   if(typeof state!=='undefined'&&!state.running&&!state.gameOver&&hasMatch()){
     // A fresh game must always be playable after entering the Game screen.
     state.running=true;
     state.turnStart=now();
   }
 }
 function restart(){
   if(typeof window.startGame==='function')window.startGame(state?.mode||'classic',state?.players||2);
 }
 function install(){
   if($('#p15PlayBar'))return;
   const g=$('#game');if(!g)return;
   const bar=document.createElement('div');bar.id='p15PlayBar';bar.className='p15-playbar';
   bar.innerHTML='<div><span class="p15-live"><i></i> PLAYABLE MATCH</span><b id="p15Status">READY</b><small id="p15Help">Drag from the striker and release to shoot</small></div><div class="p15-actions"><button class="primary" data-p15="restart">NEW MATCH</button><button data-p15="center">CENTER</button><button data-p15="pause">PAUSE</button></div>';
   const anchor=g.querySelector('.gamebar');
   (anchor?.parentNode||g).insertBefore(bar,anchor||g.firstChild);
   bar.addEventListener('click',e=>{
     const b=e.target.closest('[data-p15]');if(!b)return;
     const a=b.dataset.p15;
     if(a==='restart')restart();
     else if(a==='center'&&typeof CarromPhase14?.center==='function')CarromPhase14.center();
     else if(a==='pause'&&typeof tool==='function'&&!state.gameOver)tool('pause');
   });
 }
 function render(){
   if(!isGame())return;
   const s=$('#p15Status'),h=$('#p15Help');
   if(!s)return;
   const movingNow=typeof moving==='function'&&moving();
   const text=state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED':movingNow?'SHOT IN PLAY':(state.players===2&&state.turn===1)?'CPU TURN':state.turnPocket?'POCKET — SHOOT AGAIN':state.turnFoul?'FOUL — NEXT TURN':'YOUR TURN';
   s.textContent=text;
   if(h)h.textContent=state.gameOver?'Start a new match to play again':!state.running?'Tap PAUSE to resume':'Drag from the striker → aim → release';
 }
 // Recover from a dropped frame without changing game state or physics rules.
 function watchdog(t){
   const gap=t-lastFrame;lastFrame=t;
   if(isGame()&&gap>500&&state.running&&!state.gameOver){
     state.turnStart += Math.max(0,gap-250);
     if(typeof draw==='function')draw();
   }
   if(isGame()){install();ensureMatch();render();}
   else if(lastScreen==='game')lastScreen='';
   if(isGame())lastScreen='game';
   requestAnimationFrame(watchdog);
 }
 // Prevent browser context menus/scroll gestures from hijacking board aiming on touch devices.
 const board=$('#board');
 if(board){board.addEventListener('contextmenu',e=>e.preventDefault());board.style.touchAction='none';}
 document.addEventListener('keydown',e=>{
   if(!isGame()||e.ctrlKey||e.metaKey)return;
   if(e.key==='n'||e.key==='N'){e.preventDefault();restart();}
   if(e.key===' '&&!state.gameOver){e.preventDefault();if(typeof tool==='function')tool('pause');}
 });
 // Public, deterministic smoke check for the current match state.
 window.CarromRuntimeQA={version:'72.15',matchReady:()=>hasMatch()&&state.running&&!state.gameOver,smoke:()=>({screen:state?.screen||'none',running:!!state?.running,gameOver:!!state?.gameOver,pieces:Array.isArray(window.pieces)?window.pieces.length:0,striker:!!window.striker,turn:state?.turn??null})};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 requestAnimationFrame(watchdog);
})();
