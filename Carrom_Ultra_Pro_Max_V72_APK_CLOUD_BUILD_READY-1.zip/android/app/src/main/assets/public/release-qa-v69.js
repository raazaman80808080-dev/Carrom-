const fs=require('fs'),path=require('path');
const root=__dirname; const files=fs.readdirSync(root).filter(f=>f.endsWith('.js') && f!=='sw.js');
for(const f of files){try{require('child_process').execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'ignore'})}catch(e){console.error('JS syntax FAIL:',f);process.exit(1)}}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/id=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
if(dup.length){console.error('duplicate DOM IDs:',[...new Set(dup)].join(','));process.exit(1)}
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
if(manifest.version!=='69.0.0')throw Error('manifest version mismatch');
if(!html.includes('v68-upgrade.js')||!html.includes('v69-upgrade.js'))throw Error('upgrade chain missing');
if(!fs.existsSync(path.join(root,'v69-upgrade.js')))throw Error('v69 upgrade missing');
console.log('V69.0 QA PASS');console.log('source files:',files.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs:',dup.length?'FAIL':'NONE');console.log('manifest:',manifest.version);console.log('V68→V69 UI upgrade chain: PASS');
