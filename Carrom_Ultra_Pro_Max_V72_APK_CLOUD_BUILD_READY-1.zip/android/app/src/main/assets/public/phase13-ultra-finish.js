/* V72 Phase 13 — Ultra Finish / Playability Shield + Premium Match UX (additive) */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s), now=()=>performance.now();
 let lastReady=0, lastScreen='';
 const safe=()=>typeof state!=='undefined'&&state.screen==='game';
 function normalize(){
   if(!safe())return;
   state.power=Math.max(10,Math.min(100,Number.isFinite(+state.power)?+state.power:55));
   state.spin=Math.max(-100,Math.min(100,Number.isFinite(+state.spin)?+state.spin:0));
   state.turnCoins=Number.isFinite(+state.turnCoins)?+state.turnCoins:0;
   state.shotCount=Number.isFinite(+state.shotCount)?+state.shotCount:0;
   state.running=state.gameOver?false:!!state.running;
   const r=$('#powerRange');if(r&&document.activeElement!==r)r.value=state.power;
   const sr=$('#spinRange');if(sr&&document.activeElement!==sr)sr.value=state.spin;
 }
 function status(){
   if(!safe())return;
   normalize();
   const cpu=state.players===2&&state.turn===1&&!state.practice;
   const movingNow=typeof moving==='function'&&moving();
   let label=state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED':movingNow?'SHOT IN PLAY':cpu?'CPU TURN':state.players>2?'PLAYER '+(state.turn+1):'YOUR TURN';
   const e=$('#p13Status');if(e)e.textContent=label;
   const q=$('#p13Power');if(q)q.textContent=Math.round(state.power)+'%';
   const s=$('#p13Spin');if(s)s.textContent=(state.spin>0?'+':'')+Math.round(state.spin);
   const m=$('#p13Meter');if(m)m.style.setProperty('--p13-power',state.power+'%');
   const ready=safe()&&state.running&&!state.gameOver&&!movingNow&&!cpu;
   const deck=$('#p13Deck');if(deck)deck.classList.toggle('ready',ready);
   if(ready&&now()-lastReady>1600){lastReady=now();deck?.classList.add('pulse');setTimeout(()=>deck?.classList.remove('pulse'),500)}
 }
 function center(){if(!safe()||state.gameOver||!state.running||(state.players===2&&state.turn!==0)||(moving&&moving()))return; if(typeof striker==='undefined')return;striker.x=350;striker.y=590;striker.vx=striker.vy=0;state.drag=null;draw?.();toast?.('◎ Striker centered');}
 function setPower(v){if(!safe()||!state.running||state.gameOver||(state.players===2&&state.turn!==0)||(moving&&moving()))return;state.power=Math.max(10,Math.min(100,+v));const r=$('#powerRange');if(r)r.value=state.power;beep?.(240+state.power*3,.025,'sine',.018);draw?.();status()}
 function install(){
   if(!safe()||$('#p13Deck'))return;
   const game=$('#game'); if(!game)return;
   const deck=document.createElement('section');deck.id='p13Deck';deck.className='p13-deck';deck.setAttribute('aria-label','Ultra match control deck');
   deck.innerHTML='<div class="p13-head"><div><span class="p13-live"><i></i> LIVE MATCH</span><b id="p13Status">YOUR TURN</b></div><small>PRECISION CONTROL</small></div><div class="p13-metrics"><div><span>POWER</span><strong id="p13Power">55%</strong><i id="p13Meter"><em></em></i></div><div><span>SPIN</span><strong id="p13Spin">0</strong></div><div><span>POCKETS</span><strong id="p13Pockets">0</strong></div><div><span>SHOT</span><strong id="p13Shot">0</strong></div></div><div class="p13-actions"><button data-p13="25">25%</button><button data-p13="50">50%</button><button data-p13="75">75%</button><button data-p13="100">MAX</button><button data-p13="center">◎ CENTER</button><button data-p13="pause">Ⅱ PAUSE</button></div><div class="p13-foot"><span id="p13Tip">Drag from the striker to aim · release to shoot</span><span>1–4 POWER · SPACE PAUSE · HOME CENTER</span></div>';
   const bar=game.querySelector('.gamebar');(bar?bar.parentNode:game).insertBefore(deck,bar||game.firstChild);
   deck.addEventListener('click',e=>{const b=e.target.closest('[data-p13]');if(!b)return;const a=b.dataset.p13;if(a==='center')center();else if(a==='pause'){if(safe()&&!state.gameOver&&typeof tool==='function')tool('pause')}else setPower(+a)});
   status();
 }
 function tick(){
   if(safe()){
     if(lastScreen!=='game'){lastScreen='game';normalize()}
     const p=$('#p13Pockets'),sh=$('#p13Shot');if(p)p.textContent=String(state.turnCoins||0);if(sh)sh.textContent=String(state.shotCount||0);
     const tip=$('#p13Tip');if(tip){const cpu=state.players===2&&state.turn===1&&!state.practice;tip.textContent=state.gameOver?'Match complete':!state.running?'Paused — press Space or Pause':moving?.()?'Shot in play — controls locked':cpu?'CPU is calculating the next legal shot':'Drag from striker to aim · release to shoot'}
     install();status();
   }else lastScreen='';
   requestAnimationFrame(tick);
 }
 const originalStart=window.startGame;
 if(typeof originalStart==='function'&&!window.__p13Start){window.startGame=function(){const r=originalStart.apply(this,arguments);setTimeout(()=>{if(safe()){normalize();toast?.('🎯 Match ready — aim and release');draw?.()}},0);return r};window.__p13Start=true}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 requestAnimationFrame(tick);
 window.CarromPhase13={version:'13.0',center,setPower,normalize};
})();
