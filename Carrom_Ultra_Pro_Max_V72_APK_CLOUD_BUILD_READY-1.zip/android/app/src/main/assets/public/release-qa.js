/* V56.0 release QA — static integrity checks, safe to run in Node without browser dependencies. */
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname, files=fs.readdirSync(root).filter(x=>x.endsWith('.js')).concat(['index.html','style.css','manifest.json','package.json']);
const failures=[];
for(const f of files){const p=path.join(root,f);if(!fs.existsSync(p))failures.push('missing '+f)}
for(const f of fs.readdirSync(path.join(root,'server')).filter(x=>x.endsWith('.js'))){try{cp.execFileSync(process.execPath,['--check',path.join(root,'server',f)],{stdio:'pipe'})}catch(e){failures.push('syntax '+f)}}
try{JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'))}catch(e){failures.push('invalid manifest.json')}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const id of ['home','play','tournament','profile','shop','global','systems','settings'])if(!html.includes(`data-go="${id}"`))failures.push('missing route '+id);
for(const token of ['Daily Bonus','Free Rewards','Lucky Spin','Missions','Leaderboard','Events','ACCOUNT'])if(!html.includes(token))failures.push('missing quick feature '+token);
const server=fs.readFileSync(path.join(root,'server/server.js'),'utf8');
for(const token of ['helmet','bcrypt','jsonwebtoken','WebSocket','timingSafeEqual','atomicWallet','webhookEvents','physics','canonicalState','stateHash','/api/auth/register','/api/auth/login','/api/auth/refresh','/api/account/security','/api/leaderboards/:scope','/api/matches','/api/store/order','/api/store/webhook/razorpay','/api/store/webhook/stripe','MATCH_RESULT_VERIFIED','/api/settlements/worker/run','/health','/ready','/api/ops/runtime'])if(!server.includes(token))failures.push('missing authority '+token);
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);if(dup.length)failures.push('duplicate DOM ids '+[...new Set(dup)].join(','));
if(failures.length){console.error('V56.0 QA FAILED');failures.forEach(x=>console.error(' - '+x));process.exit(1)}
console.log('V56.0 QA PASS');console.log(' - source files: '+files.length);console.log(' - server syntax: PASS');console.log(' - manifest: PASS');console.log(' - primary routes: 8/8');console.log(' - authority endpoints: PASS');console.log(' - duplicate DOM ids: NONE');
