'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname,fail=[];
for(const f of fs.readdirSync(root).filter(x=>x.endsWith('.js'))){try{cp.execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'pipe'})}catch(e){fail.push('syntax '+f)}}
for(const f of ['index.html','style.css','manifest.json','package.json','v54-upgrade.js','v53-upgrade.js','sw.js'])if(!fs.existsSync(path.join(root,f)))fail.push('missing '+f);
const h=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const t of ['v53-upgrade.js','v54-upgrade.js','product-chip','data-go="home"','data-go="play"','data-go="tournament"','data-go="profile"','data-go="shop"','data-go="global"','data-go="systems"','data-go="settings"'])if(!h.includes(t))fail.push('missing '+t);
const ids=[...h.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);if(dup.length)fail.push('duplicate ids '+[...new Set(dup)].join(','));
if(fail.length){console.error('V54.0 QA FAILED');fail.forEach(x=>console.error(' - '+x));process.exit(1)}
console.log('V54.0 QA PASS');console.log(' - JS syntax: PASS');console.log(' - routes: 8/8');console.log(' - V53/V54 upgrade layers: PASS');console.log(' - duplicate DOM ids: NONE');
