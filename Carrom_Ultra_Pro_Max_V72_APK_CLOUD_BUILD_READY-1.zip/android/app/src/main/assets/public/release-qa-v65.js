const fs=require('fs'),path=require('path'),vm=require('vm');
const root=__dirname; const files=fs.readdirSync(root).filter(f=>f.endsWith('.js'));
for(const f of files){try{new vm.Script(fs.readFileSync(path.join(root,f),'utf8'),{filename:f})}catch(e){console.error('JS FAIL',f,e.message);process.exit(1)}}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
if(dup.length){console.error('DUPLICATE IDS', [...new Set(dup)]);process.exit(1)}
if(!html.includes('v65-upgrade.js')){console.error('V65 SCRIPT MISSING');process.exit(1)}
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));if(manifest.version!=='65.0.0'){console.error('MANIFEST VERSION FAIL',manifest.version);process.exit(1)}
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));if(pkg.version!=='65.0.0'){console.error('PACKAGE VERSION FAIL',pkg.version);process.exit(1)}
const v=fs.readFileSync(path.join(root,'v65-upgrade.js'),'utf8');for(const token of ['v65-master','v65MobileBar','v65-titlebar','v65-meter','prefers-reduced-motion'])if(!v.includes(token)){console.error('TOKEN MISSING',token);process.exit(1)}
console.log('V65.0 QA PASS');console.log('source files:',files.length);console.log('JS syntax: PASS');console.log('duplicate DOM IDs: NONE');console.log('manifest:',manifest.version);console.log('V64→V65 UI upgrade chain: PASS');
