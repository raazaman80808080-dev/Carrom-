
/* V72.0 — Ultra Pro Max UI Component State Master 16.0 */
(()=>{"use strict";
const root=document.documentElement;root.classList.add("v72-master");
const add=(e,...c)=>e&&c.forEach(x=>e.classList.add(x));
const interactive="button,a,[role='button'],input,select,textarea,[tabindex]";
document.querySelectorAll(interactive).forEach(e=>add(e,"v72-component","v72-state"));
document.querySelectorAll(".card,.panel,.feature-card,.shop-card,.player-card,.tournament-card,.stat-card,.quick-card,.match-card,.modal-content,.dashboard-card")
 .forEach(e=>add(e,"v72-component","v72-surface"));
document.querySelectorAll("button:disabled,[aria-disabled='true']").forEach(e=>add(e,"v72-disabled"));
document.querySelectorAll(".fc-tabs,.fc-filters,.shop-menu,.language-grid,.feature-grid,.nav-list,.quick-tabs,.tournament-tabs")
 .forEach(e=>{e.style.scrollbarWidth="none";e.style.overscrollBehaviorX="contain"});
document.addEventListener("pointerup",e=>{
 const a=e.target.closest(interactive);if(!a)return;
 add(a,"v72-pressed");setTimeout(()=>a.classList.remove("v72-pressed"),110);
 if(navigator.vibrate&&matchMedia("(pointer:coarse)").matches){try{navigator.vibrate(5)}catch(_){}}
},{passive:true});
document.addEventListener("keydown",e=>{
 if(e.key==="Enter"||e.key===" "){const a=document.activeElement;if(a&&a.matches(interactive))add(a,"v72-pressed")}
});
document.addEventListener("keyup",()=>document.querySelectorAll(".v72-pressed").forEach(e=>e.classList.remove("v72-pressed")));
document.addEventListener("visibilitychange",()=>root.classList.toggle("v72-hidden",document.hidden));
window.CarromV72={version:"72.0.0",presentation:"ui-component-state-master-16",states:["default","hover","active","selected","disabled","loading","empty","error","success"],nonDestructive:true};
})();
