/* V72 Phase 16 — Ultra Finish / Runtime UX hardening. Additive only. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 const game=()=>typeof state!=='undefined'&&state.screen==='game';
 const human=()=>game()&&!state.gameOver&&state.running&&!(state.players===2&&state.turn===1)&&!state.aiBusy&&!(typeof moving==='function'&&moving());
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function normalize(){
  if(!game())return;
  state.power=clamp(Number.isFinite(+state.power)?+state.power:55,10,100);
  state.spin=clamp(Number.isFinite(+state.spin)?+state.spin:0,-100,100);
  if(typeof striker!=='undefined'&&striker){striker.x=clamp(+striker.x||350,INNER.min+striker.r,INNER.max-striker.r);striker.y=clamp(+striker.y||590,INNER.min+striker.r,INNER.max-striker.r);}
 }
 function status(){
  if(!game())return ['',''];
  if(state.gameOver)return ['MATCH COMPLETE','Tap NEW MATCH to play again'];
  if(!state.running)return ['PAUSED','Resume when you are ready'];
  if(typeof moving==='function'&&moving())return ['SHOT IN PLAY','Watching collision & pocket resolution'];
  if(state.players===2&&state.turn===1&&!state.practice)return ['CPU TURN','CPU is calculating the next shot'];
  if(state.turnPocket)return ['POCKET — SHOOT AGAIN','You pocketed a coin'];
  if(state.turnFoul)return ['FOUL — TURN PASSED','Next turn is being prepared'];
  return ['AIM READY','Drag the striker, aim, then release'];
 }
 function install(){
  const g=$('#game');if(!g||$('#p16Deck'))return;
  const d=document.createElement('section');d.id='p16Deck';d.className='p16-deck';d.setAttribute('aria-label','Ultra match status');
  d.innerHTML='<div class="p16-main"><span class="p16-live"><i></i> LIVE MATCH</span><strong id="p16State">AIM READY</strong><small id="p16Help">Drag the striker, aim, then release</small></div><div class="p16-metrics"><span><b id="p16Score">0 : 0</b><em>SCORE</em></span><span><b id="p16Timer">30s</b><em>TURN</em></span><span><b id="p16Shot">0</b><em>SHOTS</em></span></div><div class="p16-actions"><button data-p16="center">CENTER</button><button data-p16="new" class="primary">NEW MATCH</button></div>';
  (g.querySelector('.gamebar')?.parentNode||g).insertBefore(d,g.querySelector('.gamebar')||g.firstChild);
  d.addEventListener('click',e=>{const b=e.target.closest('[data-p16]');if(!b)return;if(b.dataset.p16==='center'&&human()&&window.CarromPhase14?.center)window.CarromPhase14.center();if(b.dataset.p16==='new'&&typeof startGame==='function')startGame(state.mode||'classic',state.players||2);});
 }
 function render(){
  if(!game())return;normalize();install();
  const [a,b]=status(); const s=$('#p16State'),h=$('#p16Help');if(s)s.textContent=a;if(h)h.textContent=b;
  const score=$('#p16Score');if(score)score.textContent=(state.score||[0,0]).join(' : ');
  const timer=$('#p16Timer');if(timer)timer.textContent=state.practice?'∞':Math.ceil(Math.max(0,state.timer||0))+'s';
  const shot=$('#p16Shot');if(shot)shot.textContent=String(state.shotCount||0);
  const d=$('#p16Deck');if(d)d.classList.toggle('ready',human());
 }
 let last=performance.now();
 function tick(t){
  const gap=t-last;last=t;
  // If the browser was backgrounded, never let a giant frame gap create a visible timer jump.
  if(game()&&gap>350&&state.running&&!state.gameOver&&Number.isFinite(state.turnStart)) state.turnStart+=Math.max(0,gap-80);
  render();requestAnimationFrame(tick);
 }
 document.addEventListener('keydown',e=>{if(!game()||e.ctrlKey||e.metaKey)return;if(e.key==='Home'&&human()&&window.CarromPhase14?.center){e.preventDefault();window.CarromPhase14.center();}});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>requestAnimationFrame(tick),{once:true});else requestAnimationFrame(tick);
 window.CarromPhase16={version:'72.16',status};
})();
