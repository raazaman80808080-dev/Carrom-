/* PART 12 — Security & Fair Play hardening. Additive client-side safety; server remains authoritative. */
(()=>{
'use strict';
const $=(s,r=document)=>r.querySelector(s);
const SAFE_PROTOCOL=/^https?:\/\//i, WS_PROTOCOL=/^wss?:\/\//i;
function endpointSafe(v,ws=false){try{const u=new URL(String(v||''));return (ws?WS_PROTOCOL:SAFE_PROTOCOL).test(u.protocol)&&!!u.hostname&&!/[\s<>"'`]/.test(u.href)}catch{return false}}
function panel(){
 const host=$('[data-global-panel="security"]'); if(!host||$('#part12SecurityPanel'))return;
 const el=document.createElement('section');el.id='part12SecurityPanel';el.className='part12-security-panel panel';el.setAttribute('aria-label','Security and fair play diagnostics');
 el.innerHTML='<div class="p12-head"><div><span class="eyebrow">PART 12 · SECURITY CORE</span><h3>FAIR PLAY GUARD</h3><small>Client safeguards improve resilience; authoritative anti-cheat decisions belong on the server.</small></div><span class="p12-badge" data-p12-overall>READY</span></div><div class="p12-grid"><div><b data-p12-storage>READY</b><small>Storage hygiene</small></div><div><b data-p12-origin>READY</b><small>Origin checks</small></div><div><b data-p12-endpoint>READY</b><small>Endpoint policy</small></div><div><b data-p12-auth>LOCAL</b><small>Auth surface</small></div></div><div class="p12-list"><div><span>Remote secrets</span><b>SERVER ONLY</b></div><div><span>Client authority</span><b>LIMITED</b></div><div><span>Replay evidence</span><b>SERVER VERIFIED</b></div><div><span>Rate limits</span><b>SERVER ENFORCED</b></div></div><div class="p12-actions"><button type="button" data-p12-scan>RUN SAFETY SCAN</button><button type="button" data-p12-clear>REFRESH SESSION STATE</button></div><p data-p12-note>Local safeguards ready. No client-side result can authorize a competitive outcome.</p></section>';
 host.appendChild(el);bind(el);scan();
}
function scan(){
 const api=window.CarromBackend,cfg=api?.cfg||{};let storage='READY',origin='READY',endpoint='READY',auth='LOCAL';
 try{localStorage.setItem('__c12_probe','1');localStorage.removeItem('__c12_probe');}catch{storage='CHECK'}
 if(location.protocol==='file:')origin='LOCAL FILE';
 if(cfg.enabled){auth=localStorage.getItem('carrom_access_token')?'TOKEN PRESENT':'NO TOKEN';endpoint=endpointSafe(cfg.baseUrl)&&endpointSafe(cfg.wsUrl,true)?'VALID':'REVIEW'}
 const set=(s,v)=>{const e=$(s);if(e)e.textContent=v};set('[data-p12-storage]',storage);set('[data-p12-origin]',origin);set('[data-p12-endpoint]',endpoint);set('[data-p12-auth]',auth);
 const ok=storage==='READY'&&endpoint!=='REVIEW';set('[data-p12-overall]',ok?'READY':'REVIEW');const note=$('[data-p12-note]');if(note)note.textContent=cfg.enabled?'Remote mode: credentials are handled as bearer tokens by the existing bridge; keep secrets off the client and enforce validation/rate limits server-side.':'Offline mode: local safety checks are active; competitive authority is unavailable without a trusted server.';
}
function bind(root){root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-p12-scan'))scan();if(b.hasAttribute('data-p12-clear')){try{sessionStorage.clear()}catch{}scan();}})}
function boot(){panel();window.addEventListener('online',scan);window.addEventListener('offline',scan);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
window.CarromPart12Security={version:'12.0',scan,endpointSafe};
})();
