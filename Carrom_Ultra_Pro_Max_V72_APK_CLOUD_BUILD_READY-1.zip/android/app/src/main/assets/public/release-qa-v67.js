#!/usr/bin/env node
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname, files=[];
(function walk(d){for(const n of fs.readdirSync(d)){if(n==='node_modules'||n.startsWith('.'))continue;const p=path.join(d,n),st=fs.statSync(p);if(st.isDirectory())walk(p);else if(p.endsWith('.js'))files.push(p)}})(root);
let fail=[];
for(const f of files){const r=cp.spawnSync(process.execPath,['--check',f],{encoding:'utf8'});if(r.status!==0)fail.push('JS syntax: '+path.relative(root,f)+'\n'+r.stderr)}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/\bid=["']([^"']+)["']/g)].map(x=>x[1]);const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);if(dup.length)fail.push('duplicate DOM IDs: '+[...new Set(dup)].join(', '));
const man=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));if(man.version!=='67.0.0')fail.push('manifest version mismatch');
for(const x of ['v65-upgrade.js','v66-upgrade.js','v67-upgrade.js'])if(!html.includes(x))fail.push('missing script '+x);
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');if(!sw.includes('v66-upgrade.js')||!sw.includes('v67-upgrade.js'))fail.push('service worker upgrade chain incomplete');
if(!fs.readFileSync(path.join(root,'v67-upgrade.js'),'utf8').includes("version:'67.0.0'"))fail.push('V67 runtime version missing');
console.log(fail.length?'V67.0 QA FAIL':'V67.0 QA PASS');
console.log('source files:',files.length);console.log('JS syntax:',fail.some(x=>x.startsWith('JS syntax'))?'FAIL':'PASS');console.log('duplicate DOM IDs:',dup.length?'FOUND':'NONE');console.log('manifest:',man.version);console.log('V65→V66→V67 UI upgrade chain:',fail.length?'CHECK FAILED':'PASS');
if(fail.length){console.error(fail.join('\n'));process.exit(1)}
