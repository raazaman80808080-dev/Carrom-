(()=>{'use strict';
/* PART 18 — interaction hardening. Additive only; never replaces gameplay handlers. */
const q=s=>document.querySelector(s), qa=s=>Array.from(document.querySelectorAll(s));
const api=window.CarromPart18UI={version:'18.0.0'};
function buttons(){
 qa('button').forEach(b=>{
  if(!b.getAttribute('type'))b.type='button';
  if(!b.getAttribute('aria-label')){const t=(b.textContent||'').replace(/\s+/g,' ').trim();if(t)b.setAttribute('aria-label',t.slice(0,120));}
  if(b.dataset.p18Bound)return;b.dataset.p18Bound='1';
  b.addEventListener('pointerdown',()=>b.classList.add('p18-live'),{passive:true});
  const off=()=>b.classList.remove('p18-live');
  ['pointerup','pointercancel','pointerleave','blur'].forEach(x=>b.addEventListener(x,off,{passive:true}));
 });
}
function navState(){
 qa('.nav').forEach(n=>n.setAttribute('aria-current',n.classList.contains('active')?'page':'false'));
}
function guardBoard(){
 const board=q('#board');if(!board||board.dataset.p18Board)return;
 board.dataset.p18Board='1';
 const cancel=()=>{try{if(typeof state!=='undefined'&&state.drag){state.drag=null}}catch(_){} q('.board-wrap')?.classList.remove('focus')};
 window.addEventListener('blur',cancel,{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)cancel()},{passive:true});
 board.addEventListener('pointercancel',cancel,{passive:true});
 board.addEventListener('lostpointercapture',cancel,{passive:true});
}
function safeViewport(){
 const vv=window.visualViewport;
 document.documentElement.style.setProperty('--p18-vw',`${vv?.width||innerWidth}px`);
 document.documentElement.style.setProperty('--p18-vh',`${vv?.height||innerHeight}px`);
}
function announce(text){
 let a=q('#p18Announcer');if(!a){a=document.createElement('div');a.id='p18Announcer';a.setAttribute('aria-live','polite');a.setAttribute('aria-atomic','true');a.style.cssText='position:fixed!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important';document.body.appendChild(a)}a.textContent=text||'';
}
function modalA11y(){
 const m=q('#modal');if(!m)return;
 m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');
 const close=m.querySelector('[data-action="close"],.modal-close,[aria-label*="close" i]');if(close&&!close.getAttribute('aria-label'))close.setAttribute('aria-label','Close dialog');
}
function init(){buttons();navState();guardBoard();safeViewport();modalA11y();
 const mo=new MutationObserver(()=>{buttons();navState();modalA11y()});mo.observe(document.body,{childList:true,subtree:true});
 window.addEventListener('resize',safeViewport,{passive:true});window.addEventListener('orientationchange',()=>setTimeout(safeViewport,80),{passive:true});
 if(window.visualViewport)visualViewport.addEventListener('resize',safeViewport,{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)announce('')},{passive:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
