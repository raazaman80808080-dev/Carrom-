/* V72 Phase 14 — Ultra Playability / Input Guard + Match Feedback (additive) */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 let lastState='';
 const game=()=>typeof state!=='undefined'&&state.screen==='game';
 const humanTurn=()=>game()&&!state.gameOver&&state.running&&!(state.players===2&&state.turn!==0)&&!(typeof moving==='function'&&moving())&&!state.aiBusy;
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function normalize(){
   if(!game())return;
   state.power=clamp(Number.isFinite(+state.power)?+state.power:55,10,100);
   state.spin=clamp(Number.isFinite(+state.spin)?+state.spin:0,-100,100);
   if(typeof striker!=='undefined'&&striker){striker.x=clamp(+striker.x||350,INNER.min+striker.r,INNER.max-striker.r);striker.y=clamp(+striker.y||590,INNER.min+striker.r,INNER.max-striker.r);}
 }
 function feedback(){
   if(!game())return;
   const movingNow=typeof moving==='function'&&moving();
   const cpu=state.players===2&&state.turn===1&&!state.practice;
   let text=state.gameOver?'MATCH COMPLETE':!state.running?'MATCH PAUSED':movingNow?'SHOT IN PLAY':cpu?'CPU TURN':state.turnPocket?'POCKET! SHOOT AGAIN':state.turnFoul?'FOUL — TURN ENDED':'AIM READY';
   const e=$('#p14State');if(e)e.textContent=text;
   const d=$('#p14Deck');if(d)d.classList.toggle('ready',humanTurn());
   const meter=$('#p14Meter');if(meter)meter.style.setProperty('--p14-power',state.power+'%');
   const power=$('#p14Power');if(power)power.textContent=Math.round(state.power)+'%';
   const piecesLeft=$('#p14Pieces');if(piecesLeft)piecesLeft.textContent=String(typeof pieces!=='undefined'?pieces.filter(p=>p.type==='coin').length:0);
   const queen=$('#p14Queen');if(queen)queen.textContent=state.queenPending?'COVER':state.queen?'LIVE':'CAPTURED';
   if(lastState!==text){lastState=text;const live=$('#p14Live');if(live)live.textContent=text;}
 }
 function power(v){if(!humanTurn())return;state.power=clamp(+v,10,100);const r=$('#powerRange');if(r)r.value=state.power;typeof draw==='function'&&draw();feedback();}
 function center(){if(!humanTurn()||typeof striker==='undefined')return;striker.x=350;striker.y=590;striker.vx=striker.vy=0;state.drag=null;typeof draw==='function'&&draw();toast?.('Striker centered');}
 function cancelAim(){if(!game())return;state.drag=null;$('.board-wrap')?.classList.remove('focus');typeof draw==='function'&&draw();}
 function install(){
   const g=$('#game');if(!g||$('#p14Deck'))return;
   const d=document.createElement('section');d.id='p14Deck';d.className='p14-deck';d.setAttribute('aria-label','Ultra gameplay control deck');
   d.innerHTML='<div class="p14-head"><div><span class="p14-kicker"><i></i> MATCH ENGINE</span><b id="p14State">AIM READY</b></div><span id="p14Live">AIM READY</span></div><div class="p14-stats"><div><small>POWER</small><strong id="p14Power">55%</strong><i id="p14Meter"><em></em></i></div><div><small>BOARD LEFT</small><strong id="p14Pieces">0</strong></div><div><small>QUEEN</small><strong id="p14Queen">LIVE</strong></div></div><div class="p14-actions"><button data-p14="25">25%</button><button data-p14="50">50%</button><button data-p14="75">75%</button><button data-p14="100">MAX</button><button data-p14="center">◎ CENTER</button><button data-p14="cancel">× CANCEL AIM</button></div><div class="p14-tip">Drag from striker to aim · release to shoot · use presets for precise power</div>';
   (g.querySelector('.gamebar')?.parentNode||g).insertBefore(d,g.querySelector('.gamebar')||g.firstChild);
   d.addEventListener('click',e=>{const b=e.target.closest('[data-p14]');if(!b)return;const a=b.dataset.p14;if(a==='center')center();else if(a==='cancel')cancelAim();else power(a)});
 }
 document.addEventListener('keydown',e=>{if(!game()||state.gameOver)return;const k=e.key.toLowerCase();if(k==='escape'&&state.drag){e.preventDefault();cancelAim();return;}if((k==='1'||k==='2'||k==='3'||k==='4')&&!e.ctrlKey&&!e.metaKey){e.preventDefault();power([25,50,75,100][+k-1]);}if(k==='c'){e.preventDefault();center();}});
 const oldShoot=window.shoot;
 if(typeof oldShoot==='function'&&!window.__p14Shoot){window.shoot=function(a,p,spin){if(!humanTurn())return false;a=Number(a);p=Number(p);spin=Number(spin)||0;if(!Number.isFinite(a))return false;p=clamp(Number.isFinite(p)?p:55,10,100);spin=clamp(Number.isFinite(spin)?spin:0,-100,100);normalize();const r=oldShoot.call(this,a,p,spin);feedback();return r};window.__p14Shoot=true;}
 const oldStart=window.startGame;
 if(typeof oldStart==='function'&&!window.__p14Start){window.startGame=function(){const r=oldStart.apply(this,arguments);setTimeout(()=>{normalize();feedback()},0);return r};window.__p14Start=true;}
 function tick(){if(game()){normalize();install();feedback();}else lastState='';requestAnimationFrame(tick)}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 requestAnimationFrame(tick);
 window.CarromPhase14={version:'14.0',normalize,center,cancelAim,power};
})();
