/* V72 Phase 9 — Ultra gameplay UX + input safety + match diagnostics. Additive only. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s); let lastPointer=0;
 function toastSafe(t){try{if(typeof toast==='function')toast(t)}catch(_) {}}
 function canControl(){return typeof state!=='undefined'&&state.screen==='game'&&!state.gameOver&&state.running&&!(typeof moving==='function'&&moving())&&!(state.players===2&&state.turn!==0)}
 function setPower(v){if(typeof state==='undefined')return;state.power=Math.max(10,Math.min(100,Math.round(v)));const r=$('#powerRange');if(r)r.value=state.power;if(typeof draw==='function')draw();if(typeof updateHUD==='function')updateHUD()}
 function install(){
  const game=$('#game');if(!game||$('#u9Controls'))return;
  const bar=document.createElement('div');bar.id='u9Controls';bar.className='u9-controls';
  bar.innerHTML='<div class="u9-head"><span><i></i> PRECISION DECK</span><b id="u9Ready">READY</b></div><div class="u9-presets"><button data-u9p="25">25</button><button data-u9p="50">50</button><button data-u9p="75">75</button><button data-u9p="100">MAX</button></div><div class="u9-help"><span>QUICK POWER</span><span>•</span><span>TOUCH / DRAG AIM</span><span>•</span><span>UNDO BETWEEN SHOTS</span></div>';
  game.appendChild(bar);
  bar.addEventListener('click',e=>{const b=e.target.closest('[data-u9p]');if(!b)return;if(!canControl()){toastSafe('Wait for the shot to finish');return}setPower(+b.dataset.u9p);toastSafe('Power set to '+state.power+'%')});
  document.addEventListener('pointerdown',e=>{if(e.target.closest('#u9Controls,.gamebar,.mobile-controls,[data-action],button,input,select'))return;if(e.target.closest('#board'))lastPointer=performance.now()},{passive:true});
  document.addEventListener('keydown',e=>{
   if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return;
   const k=e.key.toLowerCase();
   if(k===' '){e.preventDefault();if(typeof tool==='function')tool('pause');return}
   if(k==='c'){e.preventDefault();if(canControl()&&typeof striker!=='undefined'){striker.x=350;striker.y=590;if(typeof draw==='function')draw();toastSafe('Striker centered')}}
   if(k==='r'){e.preventDefault();if(typeof state!=='undefined'&&state.history?.length&&state.turn===0&&!moving()&&typeof undo==='function')undo()}
   if(k==='1'||k==='2'||k==='3'||k==='4'){if(canControl()){const m={'1':25,'2':50,'3':75,'4':100};setPower(m[k])}}
  });
 }
 function sync(){try{if(typeof state==='undefined'||state.screen!=='game')return;const e=$('#u9Ready'),deck=$('#u9Controls');if(!e||!deck)return;const cpu=state.players===2&&state.turn===1;const ready=state.running&&!state.gameOver&&!cpu&&!moving();e.textContent=state.gameOver?'DONE':!state.running?'PAUSED':cpu?'CPU TURN':ready?'READY':'SHOT IN PLAY';deck.classList.toggle('u9-disabled',!ready)}catch(_) {}}
 function boot(){install();sync();setInterval(sync,250)}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromUltraPlayableV9={version:'72.9',precisionDeck:true,inputSafety:true,keyboardPresets:true};
})();
