/* PART 14 — Full QA + Release Candidate. Additive, diagnostic-only, never authoritative for gameplay. */
(() => {
  'use strict';
  if (window.__CARROM_PART14__) return;

  const state = {
    version: '14.0.0',
    checks: {},
    lastRun: 0,
    running: false
  };
  const root = document.documentElement;
  const criticalIds = ['board','game','toast','modal','powerRange','leftNudge','rightNudge','turnTimer','gameScore','hudStatus','gameMessage'];
  const requiredFiles = ['game.js','sw.js','manifest.json','part14-release-candidate.js','part14-release-candidate.css'];

  const mark = (name, pass, detail='') => { state.checks[name] = { pass: !!pass, detail }; };

  async function runChecks() {
    if (state.running) return window.CarromPart14.getStatus();
    state.running = true;
    try {
      const ids = [...document.querySelectorAll('[id]')].map(el => el.id);
      const unique = new Set(ids);
      mark('dom-ids', ids.length === unique.size, `${ids.length} ids / ${unique.size} unique`);

      const refs = [...document.querySelectorAll('[src], [href]')]
        .map(el => el.getAttribute('src') || el.getAttribute('href'))
        .filter(v => v && !/^(https?:|data:|blob:|#|javascript:|mailto:)/i.test(v));
      const localRefs = [...new Set(refs.map(v => v.split('?')[0].split('#')[0]))];
      const results = await Promise.all(localRefs.map(async url => {
        try { const r = await fetch(url, {method:'HEAD', cache:'no-store'}); return [url, r.ok]; }
        catch (_) { return [url, false]; }
      }));
      const missing = results.filter(([,ok]) => !ok).map(([url]) => url);
      mark('local-assets', missing.length === 0, missing.length ? `Missing/unreachable: ${missing.slice(0,8).join(', ')}` : `${localRefs.length} refs reachable`);

      const board = document.getElementById('board');
      mark('board', !!board && board.tagName === 'CANVAS' && board.width > 0 && board.height > 0, board ? `${board.width}×${board.height} canvas` : 'board missing');
      criticalIds.forEach(id => mark(`id:${id}`, !!document.getElementById(id), document.getElementById(id) ? 'present' : 'missing'));
      mark('game-runtime', typeof window.startGame === 'function' || typeof window.resetGame === 'function', 'core runtime surface');
      mark('service-worker', 'serviceWorker' in navigator, 'browser capability');
      mark('manifest', !!document.querySelector('link[rel="manifest"]'), 'manifest link');
      mark('required-files', requiredFiles.every(name => localRefs.some(ref => ref.endsWith(name))), 'release assets referenced');

      const passed = Object.values(state.checks).filter(x => x.pass).length;
      const total = Object.keys(state.checks).length;
      state.lastRun = Date.now();
      root.dataset.p14Release = passed === total ? 'ready' : 'review';
      root.dataset.p14Checks = `${passed}/${total}`;
      return window.CarromPart14.getStatus();
    } finally { state.running = false; }
  }

  function status() {
    const values = Object.values(state.checks);
    return {
      version: state.version,
      ready: values.length > 0 && values.every(x => x.pass),
      passed: values.filter(x => x.pass).length,
      total: values.length,
      lastRun: state.lastRun,
      checks: {...state.checks}
    };
  }

  window.CarromPart14 = Object.freeze({
    version: state.version,
    runChecks,
    getStatus: status
  });
  window.__CARROM_PART14__ = true;

  const boot = () => {
    document.body.classList.add('p14-ready');
    runChecks().catch(() => { root.dataset.p14Release = 'review'; });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true});
  else boot();
})();
