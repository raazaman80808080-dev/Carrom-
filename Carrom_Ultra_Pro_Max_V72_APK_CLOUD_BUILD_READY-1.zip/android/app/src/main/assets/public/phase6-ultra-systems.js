/* V72 Phase 6 — Ultra systems polish + playable UX. Additive/defensive. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s); const $$=s=>[...document.querySelectorAll(s)];
 let lastShot=0, raf=0;
 const reduce=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
 function install(){
   const game=$('#game'); if(!game||$('#u6Hud'))return;
   const hud=document.createElement('div'); hud.id='u6Hud'; hud.className='u6-hud';
   hud.innerHTML='<div class="u6-turn"><span class="u6-dot"></span><b id="u6Turn">READY</b><i id="u6Timer">--</i></div><div class="u6-stats"><span>COINS <b id="u6Coins">0</b></span><span>SHOT <b id="u6Shot">0</b></span><span>POWER <b id="u6Power">55</b></span></div>';
   game.appendChild(hud);
   const quick=document.createElement('div'); quick.id='u6Quick'; quick.className='u6-quick';
   quick.innerHTML='<button type="button" data-u6="center" aria-label="Center striker">CENTER</button><button type="button" data-u6="fine-left" aria-label="Move striker left">−</button><button type="button" data-u6="fine-right" aria-label="Move striker right">+</button><button type="button" data-u6="pause" aria-label="Pause match">Ⅱ</button>';
   game.appendChild(quick);
   quick.addEventListener('click',e=>{const b=e.target.closest('[data-u6]');if(!b)return; const a=b.dataset.u6;
     if(a==='center'&&typeof striker!=='undefined'&&!moving()){striker.x=350; if(typeof draw==='function')draw(); feedback('STRIKER CENTERED')}
     if(a==='fine-left'&&typeof nudge==='function')nudge(-1);
     if(a==='fine-right'&&typeof nudge==='function')nudge(1);
     if(a==='pause'&&typeof tool==='function')tool('pause');
   });
 }
 function feedback(text,kind='info'){const game=$('#game');if(!game)return;const e=document.createElement('div');e.className='u6-feedback '+kind;e.textContent=text;game.appendChild(e);requestAnimationFrame(()=>e.classList.add('show'));setTimeout(()=>e.remove(),900)}
 function tick(){
   try{
    if(typeof state!=='undefined'&&state.screen==='game'){
      const turn=$('#u6Turn'), timer=$('#u6Timer'), coins=$('#u6Coins'), shot=$('#u6Shot'), power=$('#u6Power');
      const cpu=state.players===2&&state.turn===1; if(turn){turn.textContent=state.gameOver?'MATCH OVER':!state.running?'PAUSED':cpu?'CPU TURN':'YOUR TURN';turn.parentElement.classList.toggle('cpu',cpu);}
      if(timer)timer.textContent=state.practice?'∞':Math.ceil(state.timer||0)+'s';
      if(coins)coins.textContent=String(state.turnCoins||0);
      if(shot)shot.textContent=String(state.shotCount||0);
      if(power)power.textContent=String(Math.round(state.power||0));
    }
   }catch(_){ }
   raf=requestAnimationFrame(tick);
 }
 function bindShotFeedback(){
   if(typeof window.shoot==='function' && !window.__u6ShootWrapped){
     const original=window.shoot; window.shoot=function(a,p,s){const before=state.shotCount||0;const r=original.apply(this,arguments);if((state.shotCount||0)>before){lastShot=Date.now();feedback((Math.round(p))+'% POWER','shot');}return r}; window.__u6ShootWrapped=true;
   }
 }
 function boot(){install();bindShotFeedback();tick();
   document.addEventListener('visibilitychange',()=>{if(document.hidden&&typeof state!=='undefined'&&state.screen==='game'&&state.running){state.running=false;feedback('MATCH PAUSED · TAB HIDDEN','warn');}});
   document.addEventListener('keydown',e=>{if(typeof state==='undefined'||state.screen!=='game'||state.gameOver)return;if(e.key===' '){e.preventDefault();if(typeof tool==='function')tool('pause')}});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromUltraSystems={version:'72.6',ui:'ultra',playable:true};
})();
