/* V72 Phase 11 — Ultra Playable Experience + System Guardrails (additive) */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s);
 const reduce=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
 let lastFrame=performance.now(), watchdog=0;
 function set(id,v){const e=$('#'+id);if(e)e.textContent=v}
 function refresh(){
   if(typeof state==='undefined')return;
   const movingNow=typeof moving==='function'&&moving();
   const turn=state.players>2?`PLAYER ${state.turn+1}`:(state.turn===0?'YOUR TURN':'CPU TURN');
   let status=state.gameOver?'MATCH COMPLETE':!state.running?'PAUSED':movingNow?'SHOT IN PLAY':turn;
   set('u11Status',status); set('u11Timer',Math.ceil(state.timer||0)); set('u11Power',Math.round(state.power||0)+'%');
   const meter=$('#u11Meter'); if(meter)meter.style.setProperty('--u11-p',Math.max(0,Math.min(100,state.power||0))+'%');
   const live=$('#u11Live'); if(live){live.className='u11-live '+(movingNow?'hot':state.gameOver?'done':state.running?'ready':'paused')}
 }
 function guard(){
   if(typeof state==='undefined')return;
   const now=performance.now(); const gap=now-lastFrame; lastFrame=now;
   if(gap>250 && state.running && !state.gameOver && typeof draw==='function') draw();
   if(state.running && !state.gameOver && typeof moving==='function' && !moving() && state.lastShotAt && now-state.lastShotAt>1800){
     state.lastShotAt=0; state.aiBusy=false; if(typeof updateHUD==='function')updateHUD();
   }
   refresh(); watchdog=requestAnimationFrame(guard);
 }
 function cancelAim(){if(typeof state==='undefined'||!state.drag)return;state.drag=null;$('.board-wrap')?.classList.remove('focus');if($('#shotHint'))$('#shotHint').style.opacity=1;if(typeof draw==='function')draw();}
 function center(){if(typeof state==='undefined'||state.gameOver)return; if(typeof moving==='function'&&moving())return; striker.x=350;striker.y=590;striker.vx=striker.vy=0;if(typeof draw==='function')draw();if(typeof toast==='function')toast('◎ Striker centered');}
 function power(p){if(typeof state==='undefined'||state.gameOver)return;if(typeof moving==='function'&&moving())return;state.power=Math.max(10,Math.min(100,p));const r=$('#powerRange');if(r)r.value=state.power;refresh();if(typeof draw==='function')draw();}
 function install(){
   const game=$('#game'); if(!game||$('#u11Deck'))return;
   const deck=document.createElement('div');deck.id='u11Deck';deck.className='u11-deck';deck.innerHTML=`<div class="u11-live ready" id="u11Live"><i></i><span id="u11Status">READY</span></div><div class="u11-meter" id="u11Meter"><span>POWER</span><b id="u11Power">55%</b><i></i></div><div class="u11-stat"><span>TIME</span><b id="u11Timer">30</b></div><button data-u11-power="25">25</button><button data-u11-power="50">50</button><button data-u11-power="75">75</button><button data-u11-power="100">MAX</button><button data-u11-center>◎ CENTER</button><button data-u11-cancel>× AIM</button></div>`;
   const bar=game.querySelector('.gamebar'); if(bar)bar.parentNode.insertBefore(deck,bar);
   deck.querySelectorAll('[data-u11-power]').forEach(b=>b.addEventListener('click',()=>power(+b.dataset.u11Power)));
   deck.querySelector('[data-u11-center]').onclick=center; deck.querySelector('[data-u11-cancel]').onclick=cancelAim;
   document.addEventListener('keydown',e=>{if(e.target.matches('input,textarea,select'))return;if(e.key==='Escape')cancelAim();else if(e.key.toLowerCase()==='c')center();else if(e.key==='1')power(25);else if(e.key==='2')power(50);else if(e.key==='3')power(75);else if(e.key==='4')power(100)});
   const board=$('#board'); if(board)board.addEventListener('contextmenu',e=>e.preventDefault());
   watchdog=requestAnimationFrame(guard);
 }
 const oldStart=window.startGame;
 if(typeof oldStart==='function')window.startGame=function(){const r=oldStart.apply(this,arguments);setTimeout(install,0);return r};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 window.CarromPhase11={version:'11.0',cancelAim,center,power,refresh};
})();
