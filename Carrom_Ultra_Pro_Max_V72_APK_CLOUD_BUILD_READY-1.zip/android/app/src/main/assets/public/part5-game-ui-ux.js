/* PART 5 — Game UI/UX Polish. Additive only. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const root=document.documentElement;
 let lastStatus='';
 const classify=t=>{t=(t||'').toUpperCase(); if(/CPU|CALCULAT|THINK/.test(t))return'cpu'; if(/SHOT|IN PLAY/.test(t))return'shot'; if(/FOUL/.test(t))return'foul'; if(/QUEEN/.test(t))return'queen'; if(/POCKET|SCORED/.test(t))return'pocket'; if(/WIN|VICTORY|COMPLETE|DRAW/.test(t))return'finish'; if(/PAUSE/.test(t))return'paused'; if(/YOUR TURN|AIM|DRAG/.test(t))return'turn'; return'ready'};
 function install(){
   const game=$('#game'); if(!game)return;
   if(!$('#p5StatusRail')){
     const rail=document.createElement('div'); rail.id='p5StatusRail'; rail.className='p5-status-rail'; rail.setAttribute('aria-live','polite');
     rail.innerHTML='<span class="p5-dot"></span><b id="p5State">READY TO AIM</b><small id="p5Sub">Precision match interface</small>';
     const stage=game.querySelector('.game-stage'); if(stage)stage.appendChild(rail);
   }
   if(!$('#p5ShotBadge')){
     const badge=document.createElement('div'); badge.id='p5ShotBadge'; badge.className='p5-shot-badge'; badge.innerHTML='<span>SHOT</span><b id="p5ShotValue">00</b>'; const hud=game.querySelector('.pro-hud'); if(hud)hud.insertBefore(badge,hud.firstChild);
   }
   $$('.gamebar button,.game-tools button,.mobile-controls button').forEach(b=>{b.type='button'; if(!b.getAttribute('aria-label'))b.setAttribute('aria-label',b.textContent.trim());});
   const close=$('.modal .close'); if(close)close.setAttribute('aria-label','Close dialog');
 }
 function sync(){
   const game=$('#game'); if(!game)return;
   const msg=$('#gameMessage')?.textContent||''; const type=classify(msg); const human=typeof state!=='undefined'&&state.screen==='game';
   const labels={cpu:['CPU THINKING','Opponent is calculating'],shot:['SHOT IN PLAY','Board is resolving the shot'],foul:['FOUL','Turn penalty applied'],queen:['QUEEN','Queen state updated'],pocket:['POCKET','Nice pocket — score updated'],finish:['MATCH COMPLETE','Review the final result'],paused:['PAUSED','Resume when you are ready'],turn:['YOUR TURN','Drag from the striker to aim'],ready:['READY TO AIM','Precision match interface']};
   const x=labels[type]||labels.ready, rail=$('#p5StatusRail'), stateEl=$('#p5State'), sub=$('#p5Sub');
   if(rail){rail.className='p5-status-rail p5-'+type;stateEl.textContent=x[0];sub.textContent=x[1];rail.hidden=!human;}
   const shot=$('#p5ShotValue'); if(shot&&typeof state!=='undefined')shot.textContent=String(state.shotCount||0).padStart(2,'0');
   root.classList.toggle('p5-game-active',human); root.dataset.p5State=type;
   const timer=$('#turnTimer'); if(timer){const n=Number(timer.textContent);timer.parentElement?.classList.toggle('p5-timer-low',Number.isFinite(n)&&n<=5&&n>0)}
   if(msg!==lastStatus){lastStatus=msg; if(type==='pocket'||type==='foul'||type==='queen') pulse(type);}
 }
 function pulse(type){const game=$('#game'); if(!game)return; game.classList.remove('p5-event','p5-pocket','p5-foul','p5-queen'); void game.offsetWidth; game.classList.add('p5-event','p5-'+type); setTimeout(()=>game.classList.remove('p5-event','p5-'+type),520);}
 function observe(){['#gameMessage','#hudStatus','#turnName','#turnTimer','#gameScore','#queenStatus'].forEach(sel=>{const e=$(sel);if(e)new MutationObserver(sync).observe(e,{subtree:true,childList:true,characterData:true,attributes:true})}); sync(); setInterval(sync,350);}
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){const m=$('#modal.show');if(m){m.classList.remove('show');return}}});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{install();observe()});else{install();observe()}
 window.CarromPart5UI={version:'5.0',sync,pulse};
})();
