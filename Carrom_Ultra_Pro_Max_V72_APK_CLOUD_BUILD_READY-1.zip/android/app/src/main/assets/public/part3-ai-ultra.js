/* PART 3 — AI ULTRA PRO MAX
   Additive AI hardening: safe planning, difficulty-aware targeting, stale-timer
   protection, deterministic guard rails and live opponent feedback.
*/
(()=>{
'use strict';
const P3={version:'3.0.0',minDelay:420,maxDelay:1150,maxPower:96,minPower:24};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number.isFinite(v)?v:a));
let aiToken=0,aiTimer=null;
const oldAiShot=window.aiShot;
function setAIStatus(text){const ids=['turnName','hudStatus','p1CoreStatus'];ids.forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=text});const m=document.getElementById('gameMessage');if(m&&state.turn===1&&!state.gameOver)m.textContent=text==='CPU THINKING'?'CPU is calculating the best shot…':'CPU ready';}
function clearAI(){aiToken++;if(aiTimer){clearTimeout(aiTimer);aiTimer=null}if(typeof state!=='undefined')state.aiBusy=false}
function validTarget(p){return p&&Number.isFinite(p.x)&&Number.isFinite(p.y)&&Number.isFinite(p.r)&&p.r>0}
function plan(){
 const targets=(typeof legalTargets==='function'?legalTargets():[]).filter(validTarget);
 if(!targets.length)return null;
 const cfg=(typeof difficulty!=='undefined'&&difficulty[state.difficulty])||{error:.18,power:46,depth:1};
 let best=null,bestScore=-Infinity;
 for(const p of targets){
  for(const po of (typeof pockets!=='undefined'&&pockets.length?pockets:[])){
   if(!Array.isArray(po)||po.length<2||!Number.isFinite(po[0])||!Number.isFinite(po[1]))continue;
   const aim=typeof aimPointFor==='function'?aimPointFor(p,po):{x:p.x,y:p.y};
   const dx=aim.x-striker.x,dy=aim.y-striker.y,dist=Math.hypot(dx,dy);
   if(!Number.isFinite(dist)||dist>760)continue;
   const pocketDist=Math.hypot(p.x-po[0],p.y-po[1]);
   let score=1500-pocketDist*1.15-dist*.55+(p.type==='queen'&&state.queen?210:0);
   score+=(cfg.depth||1)*38;
   if(typeof isBankable==='function'&&isBankable(p,po))score+=state.difficulty==='expert'?115:30;
   // Prefer cleaner, shorter approaches when scores are close.
   score-=Math.max(0,dist-420)*.12;
   if(score>bestScore){bestScore=score;best={a:Math.atan2(dy,dx),dist,target:p,pocket:po}}
  }
 }
 return best;
}
window.aiShot=function(){
 if(state.turn!==1||state.gameOver||moving()||state.aiBusy)return;
 clearAI();state.aiBusy=true;const token=aiToken;setAIStatus('CPU THINKING');
 const cfg=(difficulty[state.difficulty]||difficulty.easy);const best=plan();
 if(!best){clearAI();if(!state.gameOver)nextTurn();return}
 const error=clamp(cfg.error,.01,.22);const jitter=(Math.random()-.5)*error;
 const power=clamp((cfg.power||50)+best.dist/20+(Math.random()-.5)*10,P3.minPower,P3.maxPower);
 const delay=clamp(P3.minDelay+best.dist*1.1+(cfg.depth||1)*45,P3.minDelay,P3.maxDelay);
 aiTimer=setTimeout(()=>{aiTimer=null;if(token!==aiToken||state.turn!==1||state.gameOver||moving()){clearAI();return}state.aiBusy=false;setAIStatus('CPU TURN');shootAI(best.a+jitter,power)},delay);
};
window.cancelAI=clearAI;
window.addEventListener('pagehide',clearAI,{passive:true});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&typeof state!=='undefined'&&state.turn===1)clearAI()},{passive:true});
const originalReset=window.resetGame;
if(typeof originalReset==='function')window.resetGame=function(){clearAI();return originalReset.apply(this,arguments)};
const originalNext=window.nextTurn;
if(typeof originalNext==='function')window.nextTurn=function(){clearAI();return originalNext.apply(this,arguments)};
window.addEventListener('qhEventProgress',()=>{if(typeof state!=='undefined'&&state.turn===1&&!state.gameOver&&!moving()&&!state.aiBusy)window.aiShot()});
const badge=document.createElement('div');badge.id='p3AiBadge';badge.className='p3-ai-badge';badge.innerHTML='<i></i><span>AI ENGINE</span><b>READY</b>';
const game=document.getElementById('game');if(game&&!document.getElementById('p3AiBadge'))game.appendChild(badge);
setInterval(()=>{const b=document.getElementById('p3AiBadge');if(!b||typeof state==='undefined')return;b.classList.toggle('busy',!!state.aiBusy);b.querySelector('b').textContent=state.gameOver?'MATCH END':state.turn===1?(state.aiBusy?'THINKING':'CPU READY'):'PLAYER TURN'},500);
})();
