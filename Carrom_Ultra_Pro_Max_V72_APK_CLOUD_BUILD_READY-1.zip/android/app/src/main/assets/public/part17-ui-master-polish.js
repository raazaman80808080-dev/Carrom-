/* PART 17 — UI Master Polish runtime guard. Does not own gameplay state. */
(function(){'use strict';
  const $=s=>document.querySelector(s);
  const $$=s=>Array.from(document.querySelectorAll(s));
  const root=document.documentElement;
  function attr(el,n,v){if(el&&!el.hasAttribute(n))el.setAttribute(n,v)}
  function safeButtons(){
    $$('button:not([type])').forEach(b=>b.type='button');
    $$('button').forEach(b=>{attr(b,'aria-label',b.textContent.trim().replace(/\s+/g,' ')||'Button');});
  }
  function mobileNav(){
    $$('.nav').forEach(n=>{attr(n,'aria-current',n.classList.contains('active')?'page':null);});
  }
  function modalA11y(){
    $$('.modal').forEach(m=>{attr(m,'role','dialog');attr(m,'aria-modal','true');});
    const modal=$('#modal'); if(modal){const card=modal.querySelector('.modal-card');if(card)attr(card,'aria-label','Game dialog');}
  }
  function viewportVars(){
    const vv=window.visualViewport;
    const w=vv?vv.width:innerWidth, h=vv?vv.height:innerHeight;
    root.style.setProperty('--p17-vw',Math.round(w)+'px');root.style.setProperty('--p17-vh',Math.round(h)+'px');
    root.dataset.p17Viewport=w<620?'compact':w<900?'tablet':'desktop';
  }
    function bindPress(){
    $$('button').forEach(b=>{if(b.dataset.p17Press)return;b.dataset.p17Press='1';const on=()=>b.classList.add('p17-pressed'),off=()=>b.classList.remove('p17-pressed');b.addEventListener('pointerdown',on,{passive:true});['pointerup','pointercancel','pointerleave','blur'].forEach(x=>b.addEventListener(x,off,{passive:true}));});
  }
  function init(){
    safeButtons();mobileNav();modalA11y();viewportVars();bindPress();
    const game=$('#game'),board=$('#board');
    if(game)attr(game,'aria-label','Carrom gameplay');
    if(board){attr(board,'role','application');attr(board,'aria-roledescription','Carrom board');}
    window.CarromPart17UI={version:'17.0.0',refresh:function(){safeButtons();mobileNav();modalA11y();viewportVars();bindPress();}};
  }
  addEventListener('resize',viewportVars,{passive:true});
  addEventListener('orientationchange',()=>setTimeout(viewportVars,60),{passive:true});
  if(window.visualViewport)visualViewport.addEventListener('resize',viewportVars,{passive:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
