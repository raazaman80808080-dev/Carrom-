/* V72 Part 22 — System continuity watchdog. It observes and repairs presentation state only. */
(()=>{
 'use strict';
 const MODES=new Set(['classic','black','free','pool','practice','time','challenge']);
 const $=s=>document.querySelector(s);
 const $$=s=>Array.from(document.querySelectorAll(s));
 let lastScreen='',lastMode='',lastPlayers=0,lastHealthy=true;
 let scheduled=0;
 function validState(){
   if(typeof state==='undefined') return {ok:true,reason:'boot'};
   if(state.screen!=='game') return {ok:true,reason:'not-game'};
   if(!MODES.has(state.mode)) return {ok:false,reason:'invalid-mode'};
   if(!Number.isInteger(state.players)||state.players<2||state.players>4) return {ok:false,reason:'invalid-players'};
   if(!$('#board')) return {ok:false,reason:'board-missing'};
   if(typeof striker==='undefined'||!striker) return {ok:false,reason:'striker-missing'};
   if(typeof pieces==='undefined'||!Array.isArray(pieces)) return {ok:false,reason:'pieces-missing'};
   if(!Number.isFinite(state.turn)||state.turn<0||state.turn>=state.players) return {ok:false,reason:'turn-invalid'};
   return {ok:true,reason:'ok'};
 }
 function syncPresentation(){
   if(typeof state==='undefined')return;
   const game=$('#game');
   if(game){
     const status=state.screen==='game'?(state.gameOver?'finished':state.running?'running':'paused'):'idle';
     game.dataset.matchState=status;
     game.dataset.p22Mode=MODES.has(state.mode)?state.mode:'classic';
     game.dataset.p22Players=String(state.players||2);
   }
   if(state.screen==='game'){
     const title=$('#gameTitle');
     const badge=$('#modeBadge');
     if(title&&typeof modes!=='undefined'&&modes[state.mode])title.textContent=modes[state.mode];
     if(badge&&typeof modes!=='undefined'&&modes[state.mode])badge.textContent=modes[state.mode].toUpperCase();
   }
 }
 function safeRefresh(){
   try{if(typeof updateHUD==='function')updateHUD()}catch(_){ }
   try{if(typeof draw==='function'&&state?.screen==='game')draw()}catch(_){ }
 }
 function recoverPresentation(){
   const v=validState();
   if(!v.ok){
     lastHealthy=false;
     const game=$('#game'); if(game)game.dataset.p22Health='degraded';
     return v;
   }
   lastHealthy=true;
   const game=$('#game'); if(game)game.dataset.p22Health='ok';
   syncPresentation();
   if(state?.screen==='game')safeRefresh();
   return v;
 }
 function schedule(){cancelAnimationFrame(scheduled);scheduled=requestAnimationFrame(recoverPresentation)}
 function normalizeDynamic(){
   $$('[data-game]').forEach(b=>{
     if(b.tagName==='BUTTON'&&!b.type)b.type='button';
     if(!MODES.has(b.dataset.game))b.dataset.game='classic';
     const p=Number(b.dataset.players||2);b.dataset.players=String(Math.max(2,Math.min(4,Number.isFinite(p)?p:2)));
   });
 }
 function boot(){
   normalizeDynamic(); recoverPresentation();
   const mo=new MutationObserver(()=>normalizeDynamic());
   mo.observe(document.body,{childList:true,subtree:true});
   document.addEventListener('visibilitychange',()=>{if(!document.hidden){schedule();setTimeout(schedule,180)}},{passive:true});
   window.addEventListener('pageshow',schedule,{passive:true});
   window.addEventListener('resize',schedule,{passive:true});
   window.addEventListener('orientationchange',()=>setTimeout(schedule,100),{passive:true});
   window.addEventListener('online',()=>{document.documentElement.dataset.network='online'});
   window.addEventListener('offline',()=>{document.documentElement.dataset.network='offline'});
   document.addEventListener('click',e=>{if(e.target.closest?.('[data-game]'))setTimeout(schedule,60)},{passive:true});
   setInterval(()=>{if(!document.hidden)recoverPresentation()},2000);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.CarromPart22={version:'72.22.0',check:()=>{const v=validState();return {healthy:v.ok,reason:v.reason,screen:state?.screen||'unknown',mode:state?.mode||null,players:state?.players||null,running:!!state?.running,gameOver:!!state?.gameOver,pieces:Array.isArray(window.pieces)?window.pieces.length:0,lastHealthy}}};
})();
