/* PART 10 — Tournament & Competitive UX polish. Additive layer; authoritative state remains V37/backend. */
(()=>{
'use strict';
const q=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function decorate(){
  q('.tour-tabs button').forEach(b=>{b.type='button';b.setAttribute('aria-pressed',b.classList.contains('active')?'true':'false');});
  q('.tour-grid > div').forEach(card=>{
    const state=(card.dataset.state||'').toUpperCase();
    if(!card.dataset.part10Decorated){
      card.dataset.part10Decorated='1'; card.setAttribute('role','group');
      const badge=document.createElement('span'); badge.className='part10-status'; badge.textContent=state||'EVENT'; card.prepend(badge);
      const btn=card.querySelector('button'); if(btn){btn.type='button';btn.setAttribute('aria-label',(btn.textContent||'Open')+' '+(card.querySelector('b')?.textContent||'tournament'));}
    }
  });
  q('.bracket.panel').forEach(panel=>{
    panel.setAttribute('aria-label','Live tournament bracket');
    q('.bracket-grid > div',panel).forEach((m,i)=>{m.classList.add('part10-match');m.setAttribute('aria-label','Bracket match '+(i+1));});
  });
  q('#tourClock').forEach(el=>{el.dataset.part10Clock='1';});
  q('.v37-card').forEach(card=>{
    card.classList.add('part10-competitive-card');
    const head=card.querySelector('.v37-head'); if(head) head.setAttribute('aria-label','Tournament command center');
    q('.v37-tour',card).forEach((b,i)=>{b.type='button';b.setAttribute('aria-label','Select tournament '+(b.querySelector('b')?.textContent||('number '+(i+1))));});
    q('.v37-actions button',card).forEach(b=>{b.type='button';});
  });
}
function filters(){
  q('.tour-tabs button').forEach(btn=>{ if(btn.dataset.part10Bound)return; btn.dataset.part10Bound='1'; btn.addEventListener('click',()=>{
    const f=(btn.dataset.filter||'all').toLowerCase();
    q('.tour-tabs button').forEach(x=>{x.classList.toggle('active',x===btn);x.setAttribute('aria-pressed',x===btn?'true':'false');});
    q('.tour-grid > div').forEach(card=>{const s=(card.dataset.state||'').toLowerCase();card.hidden=f!=='all'&&s!==f;});
  });});
}
function clock(){q('#tourClock').forEach(el=>{
  if(el.dataset.part10Tick)return; el.dataset.part10Tick='1';
  const tick=()=>{const raw=String(el.textContent||'').replace(/[^0-9:]/g,'').split(':').map(Number);if(raw.length<2)return;let sec=(raw[0]||0)*3600+(raw[1]||0)*60+(raw[2]||0);if(sec>0)sec=Math.max(0,sec-1);const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=sec%60;el.textContent=[h,m,s].map((v,i)=>i===0?String(v).padStart(2,'0'):String(v).padStart(2,'0')).join(' : ');el.parentElement?.classList.toggle('part10-urgent',sec<=300&&sec>0);}; tick(); setInterval(tick,1000);
});}
function patchRender(){
  if(typeof window.v37Render!=='function'||window.v37Render.__part10)return;
  const original=window.v37Render;
  const wrapped=function(){const out=original.apply(this,arguments);decorate();return out;}; wrapped.__part10=true; window.v37Render=wrapped;
}
function boot(){patchRender();decorate();filters();clock();document.documentElement.classList.add('part10-ready');}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
const mo=new MutationObserver(()=>{decorate();filters();}); mo.observe(document.body,{childList:true,subtree:true});
window.CarromPart10Competitive={version:'10.0',decorate,filters};
})();
