/* Carrom Ultra Pro Max V65.0 — UI Master Polish 9.0 / Adaptive Visual System / Android Sharpness. */
(()=>{
'use strict';
const $=s=>document.querySelector(s), root=document.body;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const haptic=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(_) {}};
let mounted=false;
const style=`
:root{--upm-cyan:#70edff;--upm-gold:#ffd166;--upm-ink:#020712;--upm-line:rgba(255,255,255,.075);--upm-glass:rgba(7,15,30,.72)}
.v65-master{--upm-radius:14px}.v65-master *{box-sizing:border-box}.v65-master button,.v65-master [role=button]{-webkit-tap-highlight-color:transparent}
.v65-focus{outline:2px solid rgba(112,237,255,.65)!important;outline-offset:2px!important}
.v65-section{position:relative}.v65-section:after{content:"";position:absolute;left:10px;right:10px;bottom:0;height:1px;background:linear-gradient(90deg,transparent,rgba(112,237,255,.12),rgba(255,209,102,.10),transparent);pointer-events:none}
.v65-navmark{position:absolute;left:0;top:50%;width:3px;height:20px;transform:translateY(-50%);border-radius:0 4px 4px 0;background:linear-gradient(180deg,var(--upm-cyan),var(--upm-gold));box-shadow:0 0 12px rgba(112,237,255,.4);opacity:0;transition:opacity .2s ease}
.v65-active{position:relative}.v65-active .v65-navmark{opacity:1}
.v65-surface{border:1px solid var(--upm-line);background:linear-gradient(145deg,rgba(255,255,255,.035),rgba(112,237,255,.018) 45%,rgba(255,209,102,.014));box-shadow:0 12px 32px rgba(0,0,0,.16),inset 0 1px rgba(255,255,255,.025)}
.v65-surface:hover{border-color:rgba(112,237,255,.13)}
.v65-touch{transition:transform .14s ease,filter .14s ease,border-color .14s ease}.v65-touch:active{transform:translateY(1px) scale(.985);filter:brightness(1.08)}
.v65-titlebar{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:8px 0 10px}.v65-titlebar .v65-kicker{font:900 8px/1 system-ui;letter-spacing:.14em;color:#6f8992}.v65-titlebar .v65-title{font:900 14px/1.1 system-ui;color:#f3fbff;letter-spacing:.02em}
.v65-chip{display:inline-flex;align-items:center;gap:5px;min-height:25px;padding:5px 8px;border-radius:9px;border:1px solid rgba(112,237,255,.12);background:rgba(112,237,255,.035);font:900 8px/1 system-ui;letter-spacing:.08em;color:#9fc3cc;white-space:nowrap}.v65-chip b{color:var(--upm-cyan)}.v65-chip.gold{border-color:rgba(255,209,102,.14);color:#c9ad72;background:rgba(255,209,102,.035)}.v65-chip.gold b{color:var(--upm-gold)}
.v65-divider{height:1px;margin:10px 0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.08),transparent)}
.v65-safe{padding-bottom:max(8px,env(safe-area-inset-bottom));padding-left:max(0px,env(safe-area-inset-left));padding-right:max(0px,env(safe-area-inset-right))}
.v65-portrait .dashboard,.v65-portrait .main-grid,.v65-portrait .content-grid{min-width:0;max-width:100%;overflow-x:hidden}.v65-portrait img,.v65-portrait canvas,.v65-portrait video{max-width:100%}
.v65-portrait .pro-hud,.v65-portrait .quick-hub,.v65-portrait .feature-center{max-width:100%;min-width:0}.v65-portrait .pro-hud>*{min-width:0}
.v65-portrait .fc-tabs,.v65-portrait .fc-filters,.v65-portrait .shop-menu,.v65-portrait .language-grid{scrollbar-width:none;overscroll-behavior-x:contain}.v65-portrait .fc-tabs::-webkit-scrollbar,.v65-portrait .fc-filters::-webkit-scrollbar,.v65-portrait .shop-menu::-webkit-scrollbar,.v65-portrait .language-grid::-webkit-scrollbar{display:none}
.v65-mobilebar{display:none}.v65-mobilebar-inner{display:flex;align-items:center;justify-content:space-around;gap:4px}.v65-mobilebar button{flex:1;min-width:0;min-height:44px;padding:6px 4px;border:0;background:transparent;color:#718c96;font:800 8px/1.1 system-ui;letter-spacing:.04em}.v65-mobilebar button b{display:block;font-size:13px;margin-bottom:3px;color:#9bb8c0}.v65-mobilebar button.v65-selected{color:#dffaff}.v65-mobilebar button.v65-selected b{color:var(--upm-cyan);text-shadow:0 0 10px rgba(112,237,255,.35)}
.v65-toast{position:fixed;left:50%;top:12%;z-index:11000;max-width:min(92vw,380px);pointer-events:none;transform:translate(-50%,-12px) scale(.98);opacity:0;padding:10px 14px;border:1px solid rgba(112,237,255,.18);border-radius:12px;background:rgba(2,7,18,.94);box-shadow:0 18px 48px rgba(0,0,0,.42),0 0 28px rgba(112,237,255,.08);color:#e5fbff;font:900 9px/1.25 system-ui;letter-spacing:.08em;text-align:center}.v65-toast.show{animation:v65Toast 1.5s ease forwards}@keyframes v65Toast{0%{opacity:0;transform:translate(-50%,-12px) scale(.98)}14%,76%{opacity:1;transform:translate(-50%,0) scale(1)}100%{opacity:0;transform:translate(-50%,-6px) scale(1.01)}}
.v65-meter{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:8px}.v65-meter-card{min-width:0;padding:7px 8px;border-radius:10px;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.022)}.v65-meter-card span{display:block;font:800 7px/1 system-ui;color:#66818a;letter-spacing:.1em}.v65-meter-card b{display:block;margin-top:5px;font:900 12px/1 system-ui;color:#effcff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.v65-bar{height:3px;margin-top:6px;border-radius:9px;background:rgba(255,255,255,.07);overflow:hidden}.v65-bar i{display:block;height:100%;width:50%;border-radius:inherit;background:linear-gradient(90deg,var(--upm-cyan),var(--upm-gold));transition:width .28s ease}
.v65-modal-ready .modal-content,#modal.v65-modal-ready .modal-content{border-color:rgba(112,237,255,.14);box-shadow:0 24px 70px rgba(0,0,0,.46),0 0 45px rgba(112,237,255,.055)}
.v65-hidden .v65-toast,.v65-hidden .v65-mobilebar{display:none!important}.v65-lowpower *{scroll-behavior:auto!important}.v65-lowpower .v65-surface{box-shadow:inset 0 1px rgba(255,255,255,.02)}
@media(max-width:600px){.v65-titlebar{margin-top:6px}.v65-titlebar .v65-title{font-size:13px}.v65-meter{gap:5px}.v65-meter-card{padding:7px 6px}.v65-mobilebar{display:block;position:fixed;left:0;right:0;bottom:0;z-index:9000;padding:5px max(7px,env(safe-area-inset-left)) max(5px,env(safe-area-inset-bottom));border-top:1px solid rgba(112,237,255,.10);background:rgba(2,7,18,.92);backdrop-filter:blur(14px);box-shadow:0 -12px 30px rgba(0,0,0,.28)}body.v65-master{padding-bottom:58px}}
@media(max-width:430px){.v65-chip{font-size:7px;padding:5px 7px}.v65-meter-card b{font-size:11px}.v65-mobilebar button{min-height:42px}}
@media(min-width:901px){.v65-mobilebar{display:none!important}}
@media(prefers-reduced-motion:reduce){.v65-master *,.v65-master *:before,.v65-master *:after{scroll-behavior:auto!important;transition:none!important;animation-duration:.001ms!important;animation-iteration-count:1!important}.v65-toast{animation:none!important;opacity:1;transform:translate(-50%,0)}}
`;
function css(){if($('#v65Styles'))return;const s=document.createElement('style');s.id='v65Styles';s.textContent=style;document.head.appendChild(s)}
function toast(msg){if(reduced())return;let e=$('#v65Toast');if(!e){e=document.createElement('div');e.id='v65Toast';e.className='v65-toast';document.body.appendChild(e)}e.textContent=msg;e.classList.remove('show');void e.offsetWidth;e.classList.add('show');clearTimeout(window.__v65toast);window.__v65toast=setTimeout(()=>e.classList.remove('show'),1500)}
function mount(){if(mounted)return;mounted=true;css();root.classList.add('v65-master','v65-safe');
 document.querySelectorAll('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card,.quick-card,[role=button]').forEach(e=>e.classList.add('v65-touch'));
 document.querySelectorAll('.nav').forEach(n=>{if(!n.querySelector('.v65-navmark')){const m=document.createElement('i');m.className='v65-navmark';n.appendChild(m)} });
 const markNav=()=>{const current=document.querySelector('.nav.active,.nav.selected,.nav[aria-current="page"]');document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('v65-active',n===current))};markNav();
 new MutationObserver(markNav).observe(root,{subtree:true,attributes:true,attributeFilter:['class','aria-current']});
 const addTitle=(host,title,kicker)=>{if(!host||host.querySelector(':scope > .v65-titlebar'))return;const e=document.createElement('div');e.className='v65-titlebar';e.innerHTML='<div><div class="v65-kicker">'+kicker+'</div><div class="v65-title">'+title+'</div></div><span class="v65-chip"><b>UPM</b> V65</span>';host.insertBefore(e,host.firstChild)};
 const candidates=[['.dashboard','COMMAND CENTER','ULTRA PRO MAX'],['.feature-center','FEATURE CENTER','SYSTEMS'],['.quick-hub','QUICK HUB','LIVE SURFACES']];candidates.forEach(x=>addTitle($(x[0]),x[1],x[2]));
 const mobile=document.createElement('nav');mobile.id='v65MobileBar';mobile.className='v65-mobilebar';mobile.innerHTML='<div class="v65-mobilebar-inner"><button data-v65-target="home"><b>⌂</b>HOME</button><button data-v65-target="play"><b>●</b>PLAY</button><button data-v65-target="tournament"><b>◆</b>TOURNAMENT</button><button data-v65-target="shop"><b>◇</b>SHOP</button><button data-v65-target="profile"><b>◉</b>PROFILE</button></div>';if(!$('#v65MobileBar'))root.appendChild(mobile);
 const navClick=key=>{const map={home:['home','dashboard'],play:['play','game'],tournament:['tournament'],shop:['shop'],profile:['profile']};const terms=map[key]||[key];const nodes=[...document.querySelectorAll('.nav,[data-screen],[data-route],button')];const hit=nodes.find(n=>terms.some(t=>(n.dataset.screen||n.dataset.route||n.textContent||'').toLowerCase().includes(t)));if(hit){hit.click();toast(key.toUpperCase()+' · READY');haptic(7)}};
 mobile.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>navClick(b.dataset.v65Target),{passive:true}));
 const updateMobile=()=>{const active=(document.querySelector('.nav.active,.nav.selected')?.textContent||'').toLowerCase();mobile.querySelectorAll('button').forEach(b=>b.classList.toggle('v65-selected',active.includes(b.dataset.v65Target)))};updateMobile();setInterval(updateMobile,1200);
 const modal=$('#modal');if(modal)new MutationObserver(()=>{modal.classList.toggle('v65-modal-ready',modal.classList.contains('show'))}).observe(modal,{attributes:true,attributeFilter:['class']});
 root.addEventListener('focusin',e=>{if(e.target.matches('button,a,input,select,textarea,[tabindex]'))e.target.classList.add('v65-focus')});root.addEventListener('focusout',e=>e.target.classList.remove('v65-focus'));
 document.addEventListener('visibilitychange',()=>root.classList.toggle('v65-hidden',document.hidden));
 let low=false;setInterval(()=>{const n=document.hidden||innerWidth<=600;if(n!==low){low=n;root.classList.toggle('v65-lowpower',low)}},1200);
 let lastW=innerWidth;addEventListener('resize',()=>{const portrait=innerWidth<=600;root.classList.toggle('v65-portrait',portrait);if(Math.abs(innerWidth-lastW)>80)toast(portrait?'MOBILE LAYOUT · LOCKED':'DESKTOP LAYOUT · LOCKED');lastW=innerWidth},{passive:true});root.classList.toggle('v65-portrait',innerWidth<=600);
 window.CarromV65={version:'65.0.0',presentation:'ui-master-polish-9',mobile:'adaptive'};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
