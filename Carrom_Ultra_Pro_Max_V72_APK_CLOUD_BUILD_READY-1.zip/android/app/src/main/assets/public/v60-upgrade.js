/* Carrom Ultra Pro Max V60.0 — Competitive Game Presentation 4.0 / Precision Feel / Mobile Sharpness. */
(()=>{
'use strict';
const $=s=>document.querySelector(s), root=document.body;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const haptic=ms=>{try{if(localStorage.getItem('cup_setting_vibration')!=='off'&&navigator.vibrate)navigator.vibrate(ms)}catch(_) {}};
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
let mounted=false, raf=0, lastFrame=performance.now(), frames=0, fps=60, prevScore='';
function pulse(kind,d=520){if(reduced())return;root.classList.remove('v60-'+kind);void root.offsetWidth;root.classList.add('v60-'+kind);clearTimeout(root.__v60p);root.__v60p=setTimeout(()=>root.classList.remove('v60-'+kind),d)}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show','v60-toast');clearTimeout(window.__v60toast);window.__v60toast=setTimeout(()=>t.classList.remove('show','v60-toast'),1800)}
function mount(){
 if(mounted)return; mounted=true; root.classList.add('v60-engine');
 const top=$('.top');
 if(top&&!$('#v60Rail')){const r=document.createElement('div');r.id='v60Rail';r.className='v60-rail';r.innerHTML='<i></i><b>COMPETITIVE FEEL 4.0</b><span>PRECISION</span>';top.appendChild(r)}
 const wrap=$('.board-wrap');
 if(wrap&&!$('#v60Overlay')){
   const o=document.createElement('div');o.id='v60Overlay';o.className='v60-overlay';o.setAttribute('aria-hidden','true');
   o.innerHTML='<div class="v60-cross"><i></i><b></b><em></em></div><div class="v60-trajectory"></div><div class="v60-charge"><span></span></div><div class="v60-live-label">AIM LOCK</div>';
   wrap.appendChild(o); wrap.addEventListener('pointermove',aimMove,{passive:true}); wrap.addEventListener('pointerenter',()=>root.classList.add('v60-aim-active'),{passive:true}); wrap.addEventListener('pointerleave',()=>root.classList.remove('v60-aim-active'),{passive:true});
   wrap.addEventListener('pointerdown',()=>{pulse('aim',250);haptic(3)},{passive:true});
   wrap.addEventListener('pointerup',()=>{pulse('release',380);haptic(7)},{passive:true});
 }
 const hud=$('.pro-hud'); if(hud&&!$('#v60Perf')){const p=document.createElement('div');p.id='v60Perf';p.className='v60-perf';p.innerHTML='<span>FPS</span><b>60</b>';hud.appendChild(p)}
 const sync=()=>{const s=($('#gameScore')?.textContent||'').trim();if(s&&prevScore&&s!==prevScore){pulse('score',430);haptic(6)}prevScore=s};
 const score=$('#gameScore'); if(score)new MutationObserver(sync).observe(score,{subtree:true,childList:true,characterData:true}); sync();
 // Match HUD state choreography without changing gameplay values.
 ['#turnName','#turnTimer','#queenStatus','#hudStatus','#gameMessage'].forEach(sel=>{const e=$(sel);if(e)new MutationObserver(()=>pulse('hud',260)).observe(e,{subtree:true,childList:true,characterData:true,attributes:true})});
 // Existing result modal gets presentation-only stats header.
 const modal=$('#modal'); if(modal)new MutationObserver(()=>{if(!modal.classList.contains('show'))return;const c=$('#modalContent');if(!c||c.dataset.v60==='1')return;c.dataset.v60='1';const tag=document.createElement('div');tag.className='v60-result-tag';tag.textContent='MATCH PRESENTATION • ULTRA VERIFIED';c.prepend(tag);pulse('result',650);haptic(12)}).observe(modal,{subtree:true,childList:true,attributes:true});
 // Premium interaction layer, safe for mouse/touch/keyboard.
 root.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.add('v60-press')},{passive:true});
 root.addEventListener('pointerup',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.remove('v60-press')},{passive:true});
 root.addEventListener('pointercancel',e=>{const b=e.target.closest('button,.nav,.sys-card,.fc-system,.player-chip,.shop-item,.mode-card');if(b)b.classList.remove('v60-press')},{passive:true});
 document.addEventListener('keydown',e=>{if(e.key==='Enter'&&document.activeElement?.matches('button,.nav'))pulse('key',240)},{passive:true});
 document.addEventListener('visibilitychange',()=>root.classList.toggle('v60-hidden',document.hidden));
 function tick(now){frames++;if(now-lastFrame>=1000){fps=frames;frames=0;lastFrame=now;const el=$('#v60Perf b');if(el)el.textContent=String(clamp(fps,0,120));root.classList.toggle('v60-lowfps',fps<45)}raf=requestAnimationFrame(tick)}
 raf=requestAnimationFrame(tick);
 root.classList.add('v60-boot');requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.remove('v60-boot')));
 try{if(localStorage.getItem('carrom_v60_intro')!=='1'){localStorage.setItem('carrom_v60_intro','1');setTimeout(()=>toast('✦ V60 Competitive Feel ready'),850)}}catch(_){}
}
function aimMove(e){const wrap=e.currentTarget, o=$('#v60Overlay'), cross=o?.querySelector('.v60-cross'), line=o?.querySelector('.v60-trajectory'), charge=o?.querySelector('.v60-charge');if(!cross||!line||!charge)return;const r=wrap.getBoundingClientRect(),x=clamp(e.clientX-r.left,0,r.width),y=clamp(e.clientY-r.top,0,r.height),cx=r.width*.5,cy=r.height*.5,dx=x-cx,dy=y-cy,dist=Math.hypot(dx,dy),ang=Math.atan2(dy,dx)*180/Math.PI,len=clamp(dist,28,Math.min(r.width,r.height)*.44);cross.style.left=x+'px';cross.style.top=y+'px';line.style.left=cx+'px';line.style.top=cy+'px';line.style.width=len+'px';line.style.transform='rotate('+ang+'deg)';charge.style.left=x+'px';charge.style.top=y+'px';charge.style.setProperty('--charge',clamp(dist/(Math.min(r.width,r.height)*.44),.08,1));}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
window.CarromV60={version:'60.0.0',feel:'competitive-presentation-4'};
})();
