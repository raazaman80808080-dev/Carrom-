# Carrom Ultra Pro Max — Android Studio / Gradle Project

This folder is the Android wrapper for the latest Carrom Ultra Pro Max web game.

## Open
Open the `android` folder directly in Android Studio. The Android application module is `app`.

## Build
- Gradle: 8.10.2
- Android Gradle Plugin: 8.7.3
- Compile SDK: 35
- Target SDK: 35
- Minimum SDK: 23
- Application ID: `com.carrom.ultrapro.max`
- Debug application ID: `com.carrom.ultrapro.max.debug`
- Version: 72.20 (versionCode 7220)

The web game is bundled at `app/src/main/assets/public/index.html` and loads locally in a hardware-accelerated WebView. Network access is permitted for online/backend features.

### APK output
After a successful Android Studio/Gradle build:
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
- Release APK: `app/build/outputs/apk/release/app-release.apk`

The current environment does not contain an Android SDK/Gradle installation, so this conversion package is prepared for Android Studio/Gradle rather than claiming a locally built APK.


## Cloud APK build
For a phone-only build, use `.github/workflows/build-apk.yml` in GitHub Actions. See `BUILD_APK_PHONE_GITHUB.md`.
