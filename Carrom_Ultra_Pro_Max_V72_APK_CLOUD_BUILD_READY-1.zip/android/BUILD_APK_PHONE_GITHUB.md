# Phone-only APK build

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It builds the debug APK in GitHub's cloud runner, so a PC/laptop is not required.

1. Create a GitHub repository and upload the contents of this `android` folder.
2. Open the repository's **Actions** tab.
3. Select **Build Carrom APK** and tap **Run workflow** (or push to `main`/`master`).
4. Wait for the job to finish successfully.
5. Open the completed workflow run and download the artifact **Carrom-Ultra-Pro-Max-debug-apk**.
6. Extract the artifact ZIP and install the `.apk` on Android (allow installation from that source if Android asks).

Important: the repository workflow is the cloud build path. This chat environment does not contain the Android SDK, so it cannot truthfully compile and test the APK itself.
